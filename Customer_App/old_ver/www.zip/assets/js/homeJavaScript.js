//=====================================================
//=============onClickScript===========================

//click menu
$(document).ready(function(){
    $("#top-menu-front").click(function(){
        $(".top-image-menu-on").hide();
        var onButton = this.getElementsByTagName("img");
        onButton[1].style.display = 'block';
        $(".main-style").hide();
        document.getElementById("main-front").style.display = 'block';
    });
    $("#top-menu-manual").click(function(){
        $(".top-image-menu-on").hide();
        var onButton = this.getElementsByTagName("img");
        onButton[1].style.display = 'block';
        $(".main-style").hide();
        document.getElementById("main-manual").style.display = 'block';
    });
    $("#top-menu-collect").click(function(){
        $(".top-image-menu-on").hide();
        var onButton = this.getElementsByTagName("img");
        onButton[1].style.display = 'block';
        $(".main-style").hide();
        document.getElementById("main-collect").style.display = 'block';
    });
    $("#top-menu-shop").click(function(){
        $(".top-image-menu-on").hide();
        var onButton = this.getElementsByTagName("img");
        onButton[1].style.display = 'block';
        $(".main-style").hide();
        document.getElementById("main-shop").style.display = 'block';
    });
    $("#top-image-more").click(function(){
        $("#home-top-side").slideToggle();
        
        var eventClose = document.getElementById("side-event").contentWindow.document;
        eventClose.getElementById("event-list-content-detail-close").style.display = 'none';
        var eventCloseDetail = eventClose.getElementsByClassName("event-list-content-detail");
        $(eventCloseDetail).hide();
        sessionStorage.setItem("event", 0);   
        
        var noticeClose = document.getElementById("side-notice").contentWindow.document;
        var noticeCloseContent = noticeClose.getElementsByClassName("notice-list-content");
        $(noticeCloseContent).hide();
        var noticeCloseArrowRight = noticeClose.getElementsByClassName("notice-list-arrow-right");
        var noticeCloseArrowDown = noticeClose.getElementsByClassName("notice-list-arrow-down");
        $(noticeCloseArrowRight).show();
        $(noticeCloseArrowDown).hide();

    });
    $("#top-side-close").click(function(){
        $("#home-top-side").slideUp();
    });
    $("#side-list-notice").click(function(){
        $("#home-top-side").hide();
        document.getElementById("home-side").style.display = 'block';
        $(".side-style").hide();
        document.getElementById("side-notice").style.display = 'block';
        document.getElementById("top-title-sidebar").style.display = 'block';
        document.getElementById("top-title-sidebar").innerHTML = '공지사항';
        document.getElementById("top-back-home").style.display = 'block';
        document.getElementById("top-title-icon").style.display = 'none';
        document.getElementById("top-title-home").style.display = 'none';

    });
    $("#side-list-event").click(function(){
        $("#home-top-side").hide();
        document.getElementById("home-side").style.display = 'block';
        $(".side-style").hide();
        document.getElementById("side-event").style.display = 'block';
        document.getElementById("top-title-sidebar").style.display = 'block';
        document.getElementById("top-title-sidebar").innerHTML = '이벤트';
        document.getElementById("top-back-home").style.display = 'block';
        document.getElementById("top-title-icon").style.display = 'none';
        document.getElementById("top-title-home").style.display = 'none';

    });
    $("#side-list-bag").click(function(){
        $("#home-top-side").hide();
        document.getElementById("home-side").style.display = 'block';
        $(".side-style").hide();
        document.getElementById("side-bag").style.display = 'block';
        document.getElementById("top-title-sidebar").style.display = 'block';
        document.getElementById("top-title-sidebar").innerHTML = '장바구니';
        document.getElementById("top-back-home").style.display = 'block';
        document.getElementById("top-title-icon").style.display = 'none';
        document.getElementById("top-title-home").style.display = 'none';

    });
    $("#side-list-order").click(function(){
        $("#home-top-side").hide();
        document.getElementById("home-side").style.display = 'block';
        $(".side-style").hide();
        document.getElementById("side-order").style.display = 'block';
        document.getElementById("top-title-sidebar").style.display = 'block';
        document.getElementById("top-title-sidebar").innerHTML = '주문내역';
        document.getElementById("top-back-home").style.display = 'block';
        document.getElementById("top-title-icon").style.display = 'none';
        document.getElementById("top-title-home").style.display = 'none';

    });
    $("#side-list-point").click(function(){
        $("#home-top-side").hide();
        document.getElementById("home-side").style.display = 'block';
        $(".side-style").hide();
        document.getElementById("side-point").style.display = 'block';
        document.getElementById("top-title-sidebar").style.display = 'block';
        document.getElementById("top-title-sidebar").innerHTML = '포인트 관리';
        document.getElementById("top-back-home").style.display = 'block';
        document.getElementById("top-title-icon").style.display = 'none';
        document.getElementById("top-title-home").style.display = 'none';

    });
    $("#side-list-service").click(function(){
        $("#home-top-side").hide();
        document.getElementById("home-side").style.display = 'block';
        $(".side-style").hide();
        document.getElementById("side-service").style.display = 'block';
        document.getElementById("top-title-sidebar").style.display = 'block';
        document.getElementById("top-title-sidebar").innerHTML = '고객센터';
        document.getElementById("top-back-home").style.display = 'block';
        document.getElementById("top-title-icon").style.display = 'none';
        document.getElementById("top-title-home").style.display = 'none';

    });
    $("#side-list-setting").click(function(){
        $("#home-top-side").hide();
        document.getElementById("home-side").style.display = 'block';
        $(".side-style").hide();
        document.getElementById("side-setting").style.display = 'block';
        document.getElementById("top-title-sidebar").style.display = 'block';
        document.getElementById("top-title-sidebar").innerHTML = '설정';
        document.getElementById("top-back-home").style.display = 'block';
        document.getElementById("top-title-icon").style.display = 'none';
        document.getElementById("top-title-home").style.display = 'none';

    });
    $("#top-back-home").click(function(){
        document.getElementById("home-side").style.display = 'none';
        $(".side-style").hide();
        document.getElementById("top-title-sidebar").style.display = 'none';
        document.getElementById("top-back-home").style.display = 'none';
        document.getElementById("top-title-icon").style.display = 'block';
        document.getElementById("top-title-home").style.display = 'block';
    });
    $("#top-title-sidebar").click(function(){
        if(sessionStorage.getItem("event") == 1){
            var eventClose = document.getElementById("side-event").contentWindow.document;
            eventClose.getElementById("event-list-content-detail-close").style.display = 'none';
            var eventCloseDetail = eventClose.getElementsByClassName("event-list-content-detail");
            $(eventCloseDetail).hide();
            sessionStorage.setItem("event", 0);   
        }
    });
    $("#side-list-logout").click(function(){
        $("#home-logout").show();
        $("#home-logout-close").show();
    });
    $("#home-logout-close").click(function(){
        $("#home-logout").hide();
        $("#home-logout-close").hide();
    });
	$("#home-popup-close").click(function(){
		$("#home-popup").hide();
		$(".home-popup-style").hide();
		document.getElementById("main-manual").contentWindow.document.location.hash = "";
	});

});
