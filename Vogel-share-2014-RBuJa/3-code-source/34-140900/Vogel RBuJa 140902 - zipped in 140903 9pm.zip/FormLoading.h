//FormLoading.h

#ifndef _FORMLOADING_H
#define _FORMLOADING_H

#include "resource.h"

#include <afxwin.h>
#include <afxcmn.h>

class ZipcodeBook;
class FormMainSArea;

class FormLoading : public CDialog
{
public:
	enum { IDD = IDD_L3_LOADING }; // IDD_L2_LOADING };
public:
	FormLoading(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();

	virtual void OnOK();
	virtual void OnCancel();

	bool isFirst;

public:
	FormMainSArea* formMainSArea;
public:
	ZipcodeBook* zipcodeBook = 0;

public:
	CProgressCtrl* m_ctrPro;

protected:
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
};


#endif