//FormInfoRRequest.h

#ifndef _FORMINFORREQUEST_H
#define _FORMINFORREQUEST_H
#include "resource.h"
#include <afxwin.h>

class FormInfoRRequest : public CDialog
{
public:
	enum { IDD = IDD_N3_INFORREQUEST };
public:
	FormInfoRRequest(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();
	virtual void OnOK(); // EnterŰ â �ڵ����� ������ ���� �������̵�

public:
	

protected:

	// ID_BUTTON_OK
	afx_msg void OnOKButtonClicked();

	afx_msg void OnClose();


	DECLARE_MESSAGE_MAP()
};


#endif