//FormMainSArea.h

#ifndef _FORMMAINSAREA_H
#define _FORMMAINSAREA_H

#include "resource.h"
#include <afxwin.h>

#include "RBuJa.h"

class FormMainRResource;
class FormMainRValue;
class FormMainRer;
class FormMainPicker;

class FormMainSArea : public CDialog
{
public:
	enum {IDD=IDD_M1_SAREA};
public:
	FormMainSArea(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();

public: // ����� �������̵�
	virtual void OnOK(); // EnterŰ â �ڵ����� ����
	virtual void OnCancel(); // ESCŰ â �ڵ����� ����

public: // �ٸ� â��
	FormMainRResource* formMainRResource;
	FormMainRValue* formMainRValue;
	FormMainRer* formMainRer;
	FormMainPicker* formMainPicker;
	

public: // List��
	CWnd* sAreaList;
	CWnd* areaList;
	CWnd* rerList;
	CWnd* pickerList;
	CWnd* rRequestList;

public: // Display
	// Static
	void DisplayCounts();

	// List
	void SetSelectionMarks();
	void DisplaySAreaList();
	void DisplayRerList();
	void DisplayPickerList();
	void DisplayRRequestList();
	void DisplayAreaList();
	void DisplayAreaListForBinary(BinaryTree<Area>::Node* nodeLink, Long *index);

	void RefreshAllData();

private: // RadioBox
	virtual void DoDataExchange(CDataExchange* pDX);

private: // Radio Box
	UINT m_radioForGenAndElec; // �Ϲ� ��Ȱ��� ������ǰ
	UINT m_radioForDateView; // �Ϻ� ���� ��ü ���� ���

public:
	RBuJa* rBuJa;

private: // ��Ʈ�ѵ��� �ε� �Ǿ��°� flag
	bool isLoaded = false;

protected:
	// SideMenuButtons
	afx_msg void OnMainSAreaButtonClicked();
	afx_msg void OnMainRResourceButtonClicked();
	afx_msg void OnMainRValueButtonClicked();
	afx_msg void OnMainRerButtonClicked();
	afx_msg void OnMainPickerButtonClicked();
	afx_msg void OnRefreshButtonClicked();
	afx_msg void OnSettingButtonClicked();

	// Make
	afx_msg void OnMakeRerButtonClicked() ;
	afx_msg void OnMakePickerButtonClicked();
	afx_msg void OnMakeSAreaButtonClicked();

	
	afx_msg void OnAssignPickerButtonClicked();
	afx_msg void OnAssignAreaButtonClicked();

	// ListView
	afx_msg void OnRerListViewItemDoubleClicked(NMHDR *pNotifyStruct, LRESULT *result);
	afx_msg void OnPickerListViewItemDoubleClicked(NMHDR* pNotifyStruct, LRESULT* result);
	afx_msg void OnRRequestListViewItemDoubleClicked(NMHDR* pNotifyStruct, LRESULT* result);
	afx_msg void OnSAreaListViewItemSingleClicked(NMHDR* pNotifyStruct, LRESULT* result);

	// RadioBox
	afx_msg void OnRadioBoxForGenAndElec(UINT id);
	afx_msg void OnRadioBoxForDateView(UINT id);

	// ShowWindow
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);

	// Focus
	afx_msg void OnSetFocus(CWnd* cWnd);

	// Close
	afx_msg void OnClose();
	
	DECLARE_MESSAGE_MAP()
public:
	CEdit m_e_FindRer;
};


#endif