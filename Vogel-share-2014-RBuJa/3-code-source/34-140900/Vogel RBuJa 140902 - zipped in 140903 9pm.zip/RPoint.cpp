// RPoint.h
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		RPoint.h
��������:		140723
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#include "RPoint.h"

RPoint::RPoint()
{
//	this->rerLink = 0;
//	this->pickerLink= 0;
	this->rPointValue = 0;
	this->length = 0;
	this->current = 0;
}
/*
RPoint::RPoint(Rer* rerLink )
{
	this->rerLink = rerLink;
	this->pickerLink= 0;
	this->rPointValue = 0;
	this->length = 0;
	this->current = 0;
}
RPoint::RPoint(Picker* pickerLink)
{
	this->rerLink = 0;
	this->pickerLink= pickerLink;
	this->rPointValue = 0;
	this->length = 0;
	this->current = 0;
}
//*/
RPoint::RPoint(const RPoint& source)
{
//	this->rerLink = source.rerLink;
//	this->pickerLink= source.pickerLink;
	this->rPointValue = source.rPointValue;
	this->rTransactions = source.rTransactions;
	this->length = source.length;
	this->current = source.current;
	// $$ LinkedList �ű�� ��
}

RPoint::~RPoint() {}

RPoint& RPoint::operator=(const RPoint& source)
{
//	this->rerLink = source.rerLink;
//	this->pickerLink= source.pickerLink;		
	this->rPointValue = source.rPointValue;
	this->rTransactions = source.rTransactions;
	this->length = source.length;
	this->current = source.current;
	
	return *this;
}



RTransaction* RPoint::RecordRTransaction(RTransaction rTransaction)
{
	LinkedList<RTransaction>::Node* node = this->rTransactions.AppendFromTail(rTransaction);
	RTransaction *savedTransactionLink = &(node->GetObject());

	this->length = this->rTransactions.GetLength();
	this->current = &(this->rTransactions.GetCurrent()->GetObject());






	LinkedList<RTransaction>::Node* rTransactionNodeLink = this->rTransactions.GetCurrent();
	DateIndexes<LinkedList<RTransaction>::Node*>::Node* dateRTransactionIndexesNodeLink = this->currentForDateRTransactionIndexes;

	// ���� ���� �����̰ų�, ������ ������ ���ʷ� ���� ��
	if (dateRTransactionIndexesNodeLink == 0
		|| dateRTransactionIndexesNodeLink->GetDate()->IsNotEqual(Date::Today()))
	{
		// �� ���� ��带 �����
		this->dateRTransactionIndeses.AppendFromTail(rTransactionNodeLink, rTransactionNodeLink);
		this->lengthForDateRTransactionIndexes = this->dateRTransactionIndeses.GetLength();
		this->currentForDateRTransactionIndexes = this->dateRTransactionIndeses.GetCurrent();
	}
	else
	{ // ���ο� tail�� ���� ���� ġȯ��Ų��
		int length = dateRTransactionIndexesNodeLink->GetLength() + 1;
		*dateRTransactionIndexesNodeLink = DateIndexes<LinkedList<RTransaction>::Node*>::Node(dateRTransactionIndexesNodeLink->GetStartDateLink(), rTransactionNodeLink, Date::Today(), length);
	}








	return savedTransactionLink;
}
//*/

RPoint* RPoint::RTransactionAffectRPointValue(RTransaction *rTransaction)
{
	this->rPointValue += rTransaction->GetRPointValue();
	return this;
}


RTransaction* RPoint::FirstForRTransactionLink()
{
	RTransaction* rTransactionLink = 0;
	LinkedList<RTransaction>::Node* nodeLink = this->rTransactions.First();
	if (nodeLink != 0)
	{
		rTransactionLink = &(nodeLink->GetObject());
	}
	return rTransactionLink;
}
RTransaction* RPoint::NextForRTransactionLink()
{
	RTransaction* rTransactionLink = &(this->rTransactions.Next()->GetObject());
	return rTransactionLink;
}
RTransaction* RPoint::PreviousForRTransactionLink()
{
	RTransaction* rTransactionLink = &(this->rTransactions.Previous()->GetObject());
	return rTransactionLink;
}
RTransaction* RPoint::LastForRTransactionLink()
{
	RTransaction* rTransactionLink = &(this->rTransactions.Last()->GetObject());
	return rTransactionLink;
}