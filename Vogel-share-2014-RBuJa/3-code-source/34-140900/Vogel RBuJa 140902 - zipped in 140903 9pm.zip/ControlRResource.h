// ControlRResource.h
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		ControlRResource.h
��������:		140805
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#ifndef _CONTROLRRESOURCE_H
#define _CONTROLRRESOURCE_H

#include "RResource.h"
#include "LibLinkedList - added in 140725.h"


class ControlRResource
{
public:
	ControlRResource();
	ControlRResource(const ControlRResource& source);
	~ControlRResource();

	ControlRResource& operator=(const ControlRResource& source);

public:
	RResource* RecordRResource(string id, string pw, string companyName, string companyTelephone, string CEOName, string CEOPhone, string addressTotal, string addressId);
	RResource* FindRResource(string rResourceId);

	RResource* RecordRResource(
		string id,
		string pw,
		string companyName,
		string companyTelephone,
		string CEOName,
		string CEOPhone,
		string addressTotal,
		string addressId,

		Long year,
		Long month,
		Long day,
		Long weekDay,
		Long hour,
		Long min,
		Long sec,

		Long paperValueForRer,
		Long plasticValueForRer,
		Long glassBottleValueForRer,
		Long customGroupValueForRer,

		Long clothesValueForRer,
		Long steelValueForRer,
		Long wireValueForRer,

		Long stainlessValueForRer,
		Long copperValueForRer,


		Long paperValueForPicker,
		Long plasticValueForPicker,
		Long glassBottleValueForPicker,
		Long customGroupValueForPicker,

		Long clothesValueForPicker,
		Long steelValueForPicker,
		Long wireValueForPicker,

		Long stainlessValueForPicker,
		Long copperValueForPicker
		);

public:
	Long GetLength() const;
	RResource* GetCurrent() const;


public:
	RResource* First();
	RResource* Previous();
	RResource* Next();
	RResource* Last();


private:
	LinkedList<RResource> rResources;
	Long length;
	RResource* current;

};
Long CompareRResourceIds( void* one, void* other );

inline Long ControlRResource::GetLength() const
{
	return this->length;
}
//*/

inline RResource* ControlRResource::GetCurrent() const
{
	return const_cast<RResource*>(this->current);
}

//*/

#endif
