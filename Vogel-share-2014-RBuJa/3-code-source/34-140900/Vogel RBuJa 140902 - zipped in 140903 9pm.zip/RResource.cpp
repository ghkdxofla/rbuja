// RResource.h
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		RResource.h
��������:		140715
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#include "RResource.h"

RResource::RResource()
{
	this->id = "";
	this->pw = "";
	this->companyName = "";
	this->companyTelephone = "";
	this->CEOName = "";
	this->CEOPhone = "";



	this->addressTotal = "";
	this->addressId = "";

	this->joinDate = Date::Today();
	this->rerRValue = new RValue();
	this->pickerRValue = new RValue();


	this->sAreaLink = 0;

}

RResource::RResource(string id, string pw, string companyName, string companyTelephone, string CEOName, string CEOPhone)
{
	this->id = id;
	this->pw = pw;
	this->companyName = companyName;
	this->companyTelephone = companyTelephone;
	this->CEOName = CEOName;
	this->CEOPhone = CEOPhone;

	this->addressTotal = "";
	this->addressId = "";

	this->joinDate = Date::Today();
	this->rerRValue = new RValue();
	this->pickerRValue = new RValue();


	this->sAreaLink = 0;
}

RResource::RResource(string id, string pw, string companyName, string companyTelephone, string CEOName, string CEOPhone, string addressTotal, string addressId)
{
	this->id = id;
	this->pw = pw;
	this->companyName = companyName;
	this->companyTelephone = companyTelephone;
	this->CEOName = CEOName;
	this->CEOPhone = CEOPhone;

	this->addressTotal = addressTotal;
	this->addressId = addressId;

	this->joinDate = Date::Today();
	this->rerRValue = new RValue();
	this->pickerRValue = new RValue();


	this->sAreaLink = 0;
	
}

RResource::RResource(
	string id, 
	string pw, 
	string companyName, 
	string companyTelephone, 
	string CEOName, 
	string CEOPhone, 
	string addressTotal, 
	string addressId, 
	RValue* rerRValue, 
	RValue* pickerRValue)
{
	this->id = id;
	this->pw = pw;
	this->companyName = companyName;
	this->companyTelephone = companyTelephone;
	this->CEOName = CEOName;
	this->CEOPhone = CEOPhone;

	this->addressTotal = addressTotal;
	this->addressId = addressId;

	this->joinDate = Date::Today();
	this->rerRValue = rerRValue;
	this->pickerRValue = pickerRValue;

	this->sAreaLink = 0;
}













//
//
//
//
//
// ���߿� ������ǰ �ü��� �Բ� ��ϵǵ��� �߰��ؾ���
//
//
//
//
//
//
RResource::RResource( 
	string id,
	string pw,
	string companyName,
	string companyTelephone,
	string CEOName,
	string CEOPhone,
	string addressTotal,
	string addressId,

	Long year,
	Long month,
	Long day,
	Long weekDay,
	Long hour,
	Long min,
	Long sec,

	Long paperValueForRer,
	Long plasticValueForRer,
	Long glassBottleValueForRer,
	Long customGroupValueForRer,

	Long clothesValueForRer,
	Long steelValueForRer,
	Long wireValueForRer,

	Long stainlessValueForRer,
	Long copperValueForRer,


	Long paperValueForPicker,
	Long plasticValueForPicker,
	Long glassBottleValueForPicker,
	Long customGroupValueForPicker,

	Long clothesValueForPicker,
	Long steelValueForPicker,
	Long wireValueForPicker,

	Long stainlessValueForPicker,
	Long copperValueForPicker
	)
{
	this->id = id;
	this->pw = pw;
	this->companyName = companyName;
	this->companyTelephone = companyTelephone;
	this->CEOName = CEOName;
	this->CEOPhone = CEOPhone;

	this->addressTotal = addressTotal;
	this->addressId = addressId;



	Date joinDate(year, month, day, weekDay, hour, min, sec);
	this->joinDate = joinDate;



	this->rerRValue = new RValue
		(
		paperValueForRer,
		plasticValueForRer,
		glassBottleValueForRer,
		customGroupValueForRer,

		clothesValueForRer,
		steelValueForRer,
		wireValueForRer,

		stainlessValueForRer,
		copperValueForRer
		);


	this->pickerRValue = new RValue
		(
		paperValueForPicker,
		plasticValueForPicker,
		glassBottleValueForPicker,
		customGroupValueForPicker,

		clothesValueForPicker,
		steelValueForPicker,
		wireValueForPicker,

		stainlessValueForPicker,
		copperValueForPicker
		);

	this->sAreaLink = 0;
}
/*
RResource::RResource(   string id, string pw, string companyTelephone, string CEOPhone, string addressTotal, RValue rerRValue, RValue pickerRValue, SArea *sArerLink)
{
	this->id = id;
	this->pw = pw;
	this->companyTelephone = companyTelephone;
	this->CEOPhone = CEOPhone;
	


	this->addressTotal = addressTotal;
	this->addressId = addressTotal.GetSiDo() + " " + addressTotal.GetGuGun() + " " + addressTotal.GetDong();

	this->joinDate = Date::Today();
	this->rerRValue = rerRValue;
	this->pickerRValue = pickerRValue;

	this->sArerLink = sArerLink;

}
//*/
RResource::RResource(const RResource& source)
{
	this->id = source.id;
	this->pw = source.pw;
	this->companyName = source.companyName;
	this->companyTelephone = source.companyTelephone;
	this->CEOName = source.CEOName;
	this->CEOPhone = source.CEOPhone;

	this->addressTotal = source.addressTotal;
	this->addressId = source.addressId;

	this->joinDate = source.joinDate;
	this->rerRValue = source.rerRValue;
	this->pickerRValue = source.pickerRValue;

	this->sAreaLink = source.sAreaLink;
}

RResource::~RResource() {}

RResource& RResource::operator=(const RResource& source)
{
	this->id = source.id;
	this->pw = source.pw;
	this->companyName = source.companyName;
	this->companyTelephone = source.companyTelephone;
	this->CEOName = source.CEOName;
	this->CEOPhone = source.CEOPhone;

	this->addressTotal = source.addressTotal;
	this->addressId = source.addressId;

	this->joinDate = source.joinDate;
	this->rerRValue = source.rerRValue;
	this->pickerRValue = source.pickerRValue;


	this->sAreaLink = source.sAreaLink;

	return *this;
}


/*
Area* RResource::RegisterAreaLink(Area *newAreaLink)
{
	this->areaLinkList.AppendFromTail( newAreaLink );
	this->lengthForAreaList = this->areaLinkList.GetLength();
	this->currentForAreaList = this->areaLinkList.GetCurrent()->GetObject();
	
	return newAreaLink;
}//*/
/*
Picker* RResource::RecordPickerLink(Picker* pickerLink)
{
	Picker *recordedPickerLink = ( this->pickerLinks.AppendFromTail( pickerLink ) )->GetObject();
	this->lengthForPickerLinks = this->pickerLinks.GetLength();
	this->currentForPickerLinks = this->pickerLinks.GetCurrent()->GetObject();

	return recordedPickerLink ;
}

Zone* RResource::RecordZoneLink( Zone *zoneLink )
{
	this->zoneLinks.AppendFromTail( zoneLink );
	this->lengthForZoneLinks = this->zoneLinks.GetLength();
	this->currentForZoneLinks = this->zoneLinks.GetCurrent()->GetObject();
	
	return zoneLink;
}

RRequest* RResource::RecordRRequestLink(RRequest* rRequestLink)
{
	RRequest* newRRequestLink = this->controlRRequestLink.RecordRRequestLink(rRequestLink);

	return newRRequestLink;
}
//*/



RValue* RResource::RecordRerRValue(
	Long paperValue,
	Long plasticValue,
	Long glassBottleValue,
	Long customGroupValue,

	Long clothesValue,
	Long steelValue,
	Long wireValue,

	Long stainlessValue,
	Long copperValue,

	Array<string> *codes,
	Array<Long> *values)
{
	this->rerRValue = new RValue(
		paperValue,
		plasticValue,
		glassBottleValue,
		customGroupValue,

		clothesValue,
		steelValue,
		wireValue,

		stainlessValue,
		copperValue,
		
		codes,
		values
		);
	
	return this->rerRValue;
}

RValue* RResource::RecordPickerRValue(
	Long paperValue,
	Long plasticValue,
	Long glassBottleValue,
	Long customGroupValue,

	Long clothesValue,
	Long steelValue,
	Long wireValue,

	Long stainlessValue,
	Long copperValue,

	Array<string> *codes,
	Array<Long> *values)
{
	this->pickerRValue = new RValue(
		paperValue,
		plasticValue,
		glassBottleValue,
		customGroupValue,

		clothesValue,
		steelValue,
		wireValue,

		stainlessValue,
		copperValue,
		 
		codes,
		values
		);

	return this->pickerRValue;
}
