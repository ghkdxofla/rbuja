//FormLinkSAreaAndArea.h

#ifndef _FORMLINKSAREAANDAREA_H
#define _FORMLINKSAREAANDAREA_H

#include "Area.h"
#include "LibBinaryTree - added in 140725.h"
#include "resource.h"
#include <afxwin.h>

class FormLinkSAreaAndArea : public CDialog
{
public:
	enum { IDD = IDD_P2_ASSIGNAREA };
public:
	FormLinkSAreaAndArea(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();

public: // ����� �������̵�
	virtual void OnOK(); // EnterŰ â �ڵ����� ����
	virtual void OnCancel(); // ESCŰ â �ڵ����� ����


public: // Display
	void RefreshAllData();
	void DisplayAreaList();
	void DisplayAreaListForBinary(BinaryTree<Area>::Node* nodeLink, Long *index);
	void DisplayChangingList();

public:
	CWnd* areaList;
	CWnd* changingList;

protected:
	afx_msg void OnAddButtonClicked();
	afx_msg void OnDeleteButtonClicked();

	// LVC
	afx_msg void OnAreaListViewItemSingledClicked(NMHDR *pNotifyStruct, LRESULT *result);
	afx_msg void OnChangingListViewItemSingleClicked(NMHDR *pNotifyStruct, LRESULT *result);

	afx_msg void OnCloseButtonClicked();

	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
};


#endif