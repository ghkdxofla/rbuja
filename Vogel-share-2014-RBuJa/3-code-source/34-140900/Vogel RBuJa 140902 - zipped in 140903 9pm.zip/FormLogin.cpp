#include "FormLogin.h"

#include "FormLoading.h"
#include "FormLoading2.h"

#include <afxcmn.h>

BEGIN_MESSAGE_MAP( FormLogin, CDialog )
	ON_BN_CLICKED( IDC_L1B_LOGIN, OnLoginButtonClicked )
	ON_WM_CLOSE()
END_MESSAGE_MAP()

FormLogin::FormLogin( CWnd *parent )
	:CDialog( FormLogin::IDD, parent )
{

}

BOOL FormLogin::OnInitDialog() 
{
	CDialog::OnInitDialog() ;

	this->formLoading = 0;
	this->formLoading2 = 0;

	return FALSE;
}

// EnterŰ â �ڵ����� ������ ���� �������̵�
void FormLogin::OnOK()
{
	OnLoginButtonClicked();
}

void FormLogin::OnLoginButtonClicked()
{
	// ���� â�� �����.
	ShowWindow(SW_HIDE);
	
	// �ε�2 â�� ����.
	this->formLoading2 = new FormLoading2(this);
	this->formLoading2->Create(formLoading2->IDD, this); // CWnd::GetDesktopWindow());
	// this->formLoading2->SetFocus();
	this->formLoading2->ShowWindow(SW_SHOW);

	// �ε� â�� ����.
	this->formLoading = new FormLoading(this);
	this->formLoading->Create(formLoading->IDD, this);
	// this->formLoading->ShowWindow(SW_SHOWNOACTIVATE); // FormLoading2 ���� �ּ� ó��
	// ShowWindowAsync(this->formLoading->GetSafeHwnd(), SW_SHOW);

	// ShowWindowAsync(this->formLoading2->GetSafeHwnd(), SW_HIDE);
}

void FormLogin::OnClose() 
{
	EndDialog(0);
}