/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		AreaList.h
��������:		140712
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/


#ifndef _AREALIST_H
#define _AREALIST_H

#include "LibBinaryTree - added in 140725.h"
#include "Area.h"

class AreaList
{
public:
	AreaList();
	AreaList(const AreaList& source);
	~AreaList();

	AreaList& operator=(const AreaList& source);

public:
	Area* GetOrRecordArea(string addressAndAreaId);
	Area* RecordArea(string addressAndAreaId);
	Area* DeleteArea(string addressAndAreaId);
	Area* FindArea(string areaId);

public: // GetAt
	Long GetLength() const;
	BinaryTree<Area>::Node* GetRootNode() const;

public: // �ڷᱸ�� �Լ�
	void GetCopiedAreaBuffer(Area* *(areas), Long *count);
	
private:
	BinaryTree<Area> areas;
	Long length;

};


inline void AreaList::GetCopiedAreaBuffer(Area* *(areas), Long *count)
{
	this->areas.CopyToBuffer(areas, count);
}

Long CompareAddressAndAreaIds(void* one, void* other);

inline Long AreaList::GetLength() const
{
	return this->length;
}
inline BinaryTree<Area>::Node* AreaList::GetRootNode() const
{
	return const_cast<BinaryTree<Area>::Node*>(this->areas.GetRoot());
}
#endif