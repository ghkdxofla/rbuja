// R.h
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		R.h
��������:		140626
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#include "R.h"

R::R() {
	this->paperWeight = 0;
	this->plasticWeight = 0;
	this->customGroupWeight = 0;

	this->clothesWeight = 0;
	this->steelWeight = 0;
	this->wireWeight = 0;

	this->stainlessWeight = 0;
	this->copperWeight = 0;

	this->totalWeight = 0;

//	this->rerRPoint = 0;
//	this->pickerRPoint = 0;

	this->electronics = "";
	this->electronicsDescription = "";

//	this->rRequestLink = 0;

}

R::R(
		Long paperWeight,
		Long plasticWeight,
		Long glassBottleWeight,
		Long customGroupWeight,

		Long clothesWeight,
		Long steelWeight,
		Long wireWeight,

		Long stainlessWeight,
		Long copperWeight,

//		Long rerRPoint,
//		Long pickerRPoint,
		
		string electronics,
		string electronicsDescription

	): electronics( electronics ), electronicsDescription( electronicsDescription )
{

	this->paperWeight = paperWeight;
	this->plasticWeight = plasticWeight;
	this->customGroupWeight = customGroupWeight;

	this->clothesWeight = clothesWeight;
	this->steelWeight = steelWeight;
	this->wireWeight = wireWeight;

	this->stainlessWeight = stainlessWeight;
	this->copperWeight = copperWeight;


	this->totalWeight =
		paperWeight +
		plasticWeight +
		customGroupWeight +

		clothesWeight +
		steelWeight +
		wireWeight +
		
		stainlessWeight +
		copperWeight;

	this->electronics = electronics;
	this->electronicsDescription = electronicsDescription;

}




R::R(
	Long paperWeight,
	Long plasticWeight,
	Long glassBottleWeight,
	Long customGroupWeight,

	Long clothesWeight,
	Long steelWeight,
	Long wireWeight,

	Long stainlessWeight,
	Long copperWeight,

	Long totalWeight,

	//		Long rerRPoint,
	//		Long pickerRPoint,

	string electronics,
	string electronicsDescription

	) : electronics(electronics), electronicsDescription(electronicsDescription)
{

	this->paperWeight = paperWeight;
	this->plasticWeight = plasticWeight;
	this->customGroupWeight = customGroupWeight;

	this->clothesWeight = clothesWeight;
	this->steelWeight = steelWeight;
	this->wireWeight = wireWeight;

	this->stainlessWeight = stainlessWeight;
	this->copperWeight = copperWeight;


	this->totalWeight = totalWeight;

	this->electronics = electronics;
	this->electronicsDescription = electronicsDescription;

}












//*/
R::R(const R& source):electronics( source.electronics ), electronicsDescription( source.electronicsDescription )
{
	this->paperWeight = source.paperWeight;
	this->plasticWeight = source.plasticWeight;
	this->customGroupWeight = source.customGroupWeight;

	this->clothesWeight = source.clothesWeight;
	this->steelWeight = source.steelWeight;
	this->wireWeight = source.wireWeight;

	this->stainlessWeight = source.stainlessWeight;
	this->copperWeight = source.copperWeight;


	this->totalWeight = source.totalWeight;

	
//	this->rerRPoint = source.rerRPoint;
//	this->pickerRPoint = source.pickerRPoint;
	
	this->electronics = source.electronics;
	this->electronicsDescription = source.electronicsDescription;

}

R::~R() {}

R& R::operator=(const R& source)
{
	this->paperWeight = source.paperWeight;
	this->plasticWeight = source.plasticWeight;
	this->customGroupWeight = source.customGroupWeight;

	this->clothesWeight = source.clothesWeight;
	this->steelWeight = source.steelWeight;
	this->wireWeight = source.wireWeight;

	this->stainlessWeight = source.stainlessWeight;
	this->copperWeight = source.copperWeight;

	this->totalWeight = source.totalWeight;

//	this->rerRPoint = source.rerRPoint;
//	this->pickerRPoint = source.pickerRPoint;

	this->electronics = source.electronics;
	this->electronicsDescription = source.electronicsDescription;

//	this->rRequestLink = source.rRequestLink;

	return *this;
}

