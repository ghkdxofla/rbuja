//FormLoading2.h

#ifndef _FORMLOADING2_H
#define _FORMLOADING2_H

#include "resource.h"

#include <afxwin.h>
#include <afxcmn.h>

class FormLoading2 : public CDialog
{
public:
	enum { IDD = IDD_L2_LOADING };
public:
	FormLoading2(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();

	virtual void OnOK();
	virtual void OnCancel();

public:
	CProgressCtrl* m_ctrPro;

	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
};


#endif