//FormLogin.h

#ifndef _FORMLOGIN_H
#define _FORMLOGIN_H
#include "resource.h"
#include <afxwin.h>

// MakeForm�� ��� include
#include "FormMakeSArea.h"
#include "FormMakeRer.h"
#include "FormMakePicker.h"

// SideMenuForm�� ��� include
#include "FormMainSArea.h"
#include "FormMainRResource.h"
#include "FormMainRValue.h"
#include "FormMainRer.h"
#include "FormMainPicker.h"
#include "FormSetting.h"
#include "FormClosing.h"

#include "FormLinkPickerAndArea.h"
#include "FormLinkSAreaAndArea.h"

// InfoForm�� ��� include 
#include "FormInfoRer.h"
#include "FormInfoPicker.h"
#include "FormInfoRRequest.h"

#include "FormLoading.h"
#include "FormLoading2.h"

class FormLogin : public CDialog
{
public:
	enum {IDD=IDD_L1_LOGIN};
public:
	FormLogin( CWnd *parent = NULL ) ;
	virtual BOOL OnInitDialog() ;
	
	virtual void OnOK(); // EnterŰ â �ڵ����� ������ ���� �������̵�

public:
	FormLoading* formLoading;
	FormLoading2* formLoading2;

protected:
	afx_msg void OnLoginButtonClicked() ;
	afx_msg void OnClose() ;
	
	DECLARE_MESSAGE_MAP()
};


#endif