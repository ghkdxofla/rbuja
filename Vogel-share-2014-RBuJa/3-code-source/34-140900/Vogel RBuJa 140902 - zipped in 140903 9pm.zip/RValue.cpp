// RValue.cpp
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		RValue.h
��������:		140730
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
Ư�̻���:
	�ü������� ���Ȼ� �߿��ϴٰ� �����ϹǷ�
	�����ڸ� �̿��ؼ� �ü������� ��ħ
*/

#include "RValue.h"

RValue::RValue()
{
	this->paperValue = 0;
	this->plasticValue = 0;
	this->glassBottleValue = 0;
	this->customGroupValue = 0;

	this->clothesValue = 0;
	this->steelValue = 0;
	this->wireValue = 0;
	
	this->stainlessValue = 0;
	this->copperValue = 0;

	this->electronicsCode = Array<string>(40);
	this->electronicsValue = Array<Long>(40);
	this->capacityForElectronics = 0;
	this->lengthForElectronics = 0;

	SetDefaultElectronicsValueItems();
}

RValue::RValue(
	Long paperValue,
	Long plasticValue,
	Long glassBottleValue,
	Long customGroupValue,

	Long clothesValue,
	Long steelValue,
	Long wireValue,

	Long stainlessValue,
	Long copperValue,

	Array<string> *codes,
	Array<Long> *values)
{
	this->paperValue = paperValue;
	this->plasticValue = plasticValue;
	this->glassBottleValue = glassBottleValue;
	this->customGroupValue = customGroupValue;

	this->clothesValue = clothesValue;
	this->steelValue = steelValue;
	this->wireValue = wireValue;

	this->stainlessValue = stainlessValue;
	this->copperValue = copperValue;

	this->electronicsCode = *codes;
	this->electronicsValue = *values;

	if (codes != 0 && values != 0)
	{
		this->capacityForElectronics = codes->GetCapacity();
		this->lengthForElectronics = codes->GetLength();
	}
	else
	{
		this->capacityForElectronics = 0;
		this->lengthForElectronics = 0;
	}
}


RValue::RValue(const RValue& source)
{
	this->paperValue = source.paperValue;
	this->plasticValue = source.plasticValue;
	this->glassBottleValue = glassBottleValue;
	this->customGroupValue = source.customGroupValue;

	this->clothesValue = source.clothesValue;
	this->steelValue = source.steelValue;
	this->wireValue = source.wireValue;

	this->stainlessValue = source.stainlessValue;
	this->copperValue = source.copperValue;

	this->electronicsCode = source.electronicsCode;
	this->electronicsValue = source.electronicsValue;
	this->capacityForElectronics = source.capacityForElectronics;
	this->lengthForElectronics = source.lengthForElectronics;
}

RValue::~RValue() {}

RValue& RValue::operator=(const RValue& source)
{
	this->paperValue = source.paperValue;
	this->plasticValue = source.plasticValue;
	this->glassBottleValue = source.glassBottleValue;
	this->customGroupValue = source.customGroupValue;

	this->clothesValue = source.clothesValue;
	this->steelValue = source.steelValue;
	this->wireValue = source.wireValue;

	this->stainlessValue = source.stainlessValue;
	this->copperValue = source.copperValue;

	this->electronicsCode = source.electronicsCode;
	this->electronicsValue = source.electronicsValue;
	this->capacityForElectronics = source.capacityForElectronics;
	this->lengthForElectronics = source.lengthForElectronics;

	return *this;
}

void RValue::AddElectornicsValueItem(string code, Long value)
{
	if (this->lengthForElectronics <= this->capacityForElectronics) // ��뷮�� �Ҵ緮���� �۰ų� ������
	{
		this->electronicsCode.Store(this->lengthForElectronics, code);
		this->electronicsValue.Store(this->lengthForElectronics, value);
	}
	else
	{
		this->electronicsCode.AppendFromRear(code);
		this->electronicsValue.AppendFromRear(value);
	}

	this->capacityForElectronics = this->electronicsCode.GetCapacity();
	this->lengthForElectronics = this->electronicsCode.GetLength();
}

void RValue::ModifyElectronicsValueItem(string code, Long value)
{
	// Code���� ã��
	Long index = this->electronicsCode.LinearSearchUnique(&code, CompareStrings);
	// ã�� �ּҷ� Value���� �ٲ۴�.
	this->electronicsValue.Modify(index, value);
}

Long RValue::FindElectronicsValueItem(string code)
{
	Long index = this->electronicsCode.LinearSearchUnique(&code, CompareStrings);
	return index;
}

void RValue::DeleteElectronicsValueItem(string code)
{
	Long index = this->electronicsCode.LinearSearchUnique(&code, CompareStrings);

	if (index != 0) // ���� index�� ������
	{
		this->electronicsCode.Delete(index);
		this->electronicsValue.Delete(index);

		this->capacityForElectronics = this->electronicsCode.GetCapacity();
		this->lengthForElectronics = this->electronicsCode.GetLength();
	}
}

void RValue::SetDefaultElectronicsValueItems()
{
	AddElectornicsValueItem("�Ϲ� TV - ��");
	AddElectornicsValueItem("�Ϲ� TV - ��");
	AddElectornicsValueItem("�Ϲ� TV - ��");
	AddElectornicsValueItem("��� TV - ��");
	AddElectornicsValueItem("��� TV - ��");
	AddElectornicsValueItem("��� TV - ��");
	AddElectornicsValueItem("������ - ��");
	AddElectornicsValueItem("������ - ��");
	AddElectornicsValueItem("������ - ��");
	AddElectornicsValueItem("��Ź�� - ��");
	AddElectornicsValueItem("��Ź�� - ��");
	AddElectornicsValueItem("��Ź�� - ��");
	AddElectornicsValueItem("����� - ��");
	AddElectornicsValueItem("����� - ��");
	AddElectornicsValueItem("����� - ��");
	AddElectornicsValueItem("�ǿܱ� - ��");
	AddElectornicsValueItem("�ǿܱ� - ��");
}

void RValue::GetElectronicsCodeAndValue(Long index, string& code, Long& value)
{
	code = this->electronicsCode.GetAt(index);
	value = this->electronicsValue.GetAt(index);
}