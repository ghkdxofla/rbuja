// Area.h
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		Zone.cpp
��������:		140712
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/


#ifndef _AREA_H
#define _AREA_H

#include "LibLinkedList - added in 140725.h"
#include "LibDateIndexes.h"

#include <string>
using namespace std;

class Rer;
class Picker;
class RResource;
class SArea;
class RRequest;
class Date;

class Area
{
public:
	Area();
	Area(string id);
	Area(string id, Picker* pickerLink, RResource* rResourceLink);
	Area(const Area& source);
	~Area();

	Area& operator=(const Area& source);

public:
	Rer* RegisterRerLink(Rer* rerLink);
	RRequest* RecordRRequest(Rer *rer, Long RType, Long pickUpType, Date rerPickUpDate);
	RRequest* FindRRequestLink(string rRequestId);



	RRequest* Area::RecordRRequest(
		string rRequestId,

		Long RType,
		Long pickUpType,

		Long isCancelledInt,
		Long isTakenByPickerInt,

		Long yearForRerPickUpDate,
		Long monthForRerPickUpDate,
		Long dayForRerPickUpDate,
		Long weekDayForRerPickUpDate,
		Long hourForRerPickUpDate,
		Long minForRerPickUpDate,
		Long secForRerPickUpDate,

		Long yearForPickerPickUpDate,
		Long monthForPickerPickUpDate,
		Long dayForPickerPickUpDate,
		Long weekDayForPickerPickUpDate,
		Long hourForPickerPickUpDate,
		Long minForPickerPickUpDate,
		Long secForPickerPickUpDate,

		Long yearForRerRequestDate,
		Long monthForRerRequestDate,
		Long dayForRerRequestDate,
		Long weekDayForRerRequestDate,
		Long hourForRerRequestDate,
		Long minForRerRequestDate,
		Long secForRerRequestDate,

		Long rerRPointValue,
		Long pickerRPointValue,

		Long paperWeight,
		Long plasticWeight,
		Long glassBottleWeight,
		Long customGroupWeight,

		Long clothesWeight,
		Long steelWeight,
		Long wireWeight,

		Long stainlessWeight,
		Long copperWeight,

		Long totalWeight,
		string electronics,
		string electronicsDescription,

		Rer* rerLink,
		Picker* pickerLink
		);



//	LinkedList<Rer*>::Node* RegisterRerLinkNode(Rer* rerLink); // �Ҹ��� test ��
public: // GetAt
	string GetId() const;
	
	Picker* GetPickerLink() const;
	RResource* GetRResourceLink() const;

	Long GetLengthForRerLinks() const;
	Rer* GetCurrentForRerLinks() const;

	Long GetLengthForRRequests() const;
	RRequest* GetCurrentRRequests() const;

	SArea* GetSAreaLink() const;

public: // PickerLink, RResourceLink // public���� �����Ǿ�����
	Picker* pickerLink;
	RResource* rResourceLink;
	SArea* sAreaLink = 0;

public:
	Rer* RerLinkFirst();
	Rer* RerLinkPrevious();
	Rer* RerLinkNext();
	Rer* RerLinkLast();

public:
	RRequest* FirstForRRequest();
	RRequest* PreviousForRRequest();
	RRequest* NextForRRequest();
	RRequest* LastForRRequest();
	
private:
	string addressAndAreaId; // id


private: // RerLink
	LinkedList<Rer*> rerLinks;
	Long lengthForRerLinks;
	Rer* currentForRerLinks;

private: // RRequest
	LinkedList<RRequest> rRequests;
	Long lengthForRRequests;
	RRequest* currentForRRequests;

private: // DateIndexes
	DateIndexes<LinkedList<RRequest>::Node*> dateRRequestIndeses;
	Long lengthForDateRRequeseIndexes;
	DateIndexes<LinkedList<RRequest>::Node*>::Node* currentForDateRRequestIndexes;


	DateIndexes<LinkedList<Rer*>::Node*> dateRerLinkIndexes;
	Long lengthForDateRerLinkIndexes;
	DateIndexes<LinkedList<Rer*>::Node*>::Node* currentForDateRerLinkIndexes;


};

Long CompareRRequestLinkIds(void* one, void* other);

inline string Area::GetId() const
{
	return this->addressAndAreaId;
}




inline Picker* Area::GetPickerLink() const
{
	return const_cast<Picker*>(this->pickerLink);
}
inline RResource* Area::GetRResourceLink() const
{
	return const_cast<RResource*>(this->rResourceLink);
}






inline 	Long Area::GetLengthForRerLinks() const
{
	return this->lengthForRerLinks;
}
inline 	Rer* Area::GetCurrentForRerLinks() const
{
	return const_cast<Rer*>(this->currentForRerLinks);
}







inline 	Long Area::GetLengthForRRequests() const
{
	return this->lengthForRRequests;
}
inline 	RRequest* Area::GetCurrentRRequests() const
{
	return const_cast<RRequest*>(this->currentForRRequests);
}





inline SArea* Area::GetSAreaLink() const
{
	return const_cast<SArea*>(this->sAreaLink);
}

#endif