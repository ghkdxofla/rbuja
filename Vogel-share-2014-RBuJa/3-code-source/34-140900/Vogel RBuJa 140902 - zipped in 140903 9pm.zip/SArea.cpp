// SArea.cpp
/*

������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		SArea.cpp
��������:		140804
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/


#include "SArea.h"

SArea::SArea()
{
	this->lengthForAreaLinkList = 0;
	this->currentForAreaLinkList = 0;
	this->sAreaId = "";
	this->rResourceLink = 0;
//	this->name = "";
}
SArea::SArea(string sAreaId, RResource* rResourceLink)
{
	this->lengthForAreaLinkList = 0;
	this->currentForAreaLinkList = 0;
	this->sAreaId = sAreaId;
	this->rResourceLink = rResourceLink;
//	this->name = name;
}
SArea::SArea(const SArea& source)
{
	this->lengthForAreaLinkList = source.lengthForAreaLinkList;
	this->currentForAreaLinkList = source.currentForAreaLinkList;
	this->sAreaId = source.sAreaId;
	this->rResourceLink = source.rResourceLink;
//	this->name = source.name;
}

SArea::~SArea(){}
SArea& SArea::operator=(const SArea& source)
{
	this->lengthForAreaLinkList = source.lengthForAreaLinkList;
	this->currentForAreaLinkList = source.currentForAreaLinkList;
	this->sAreaId = source.sAreaId;
	this->rResourceLink = source.rResourceLink;
//	this->name = source.name;

	return *this;
}

Area* SArea::RegisterAreaLink(Area* areaLink)
{
	Area* appendedAreaLink =  this->areaLinkList.AppendFromTail(areaLink)->GetObject();
	this->lengthForAreaLinkList = areaLinkList.GetLength();
	this->currentForAreaLinkList = areaLinkList.GetCurrent()->GetObject();

	return appendedAreaLink;
}

Area* SArea::UnregisterAreaLink(Area* areaLink)
{
	// SArea�� AreaLinkList�� �ƴ϶� RBuJa�� AreaList���� ã�� areaLink�� �޾ƿͶ� ȣ��Ŀ��� �����϶�
	LinkedList<Area*>::Node* areaLinkNodeToDelete
		= this->areaLinkList.LinearSearchUniqueForLinkObj(areaLink, CompareAreaLinks);

	if (areaLinkNodeToDelete != 0) // ���� Area�� ����� ã������ �����Ѵ�. 
	{
		LinkedList<Area*>::Node* deletedNodeLink = this->areaLinkList.Delete(areaLinkNodeToDelete);
		this->lengthForAreaLinkList = areaLinkList.GetLength();
		if (areaLinkList.GetCurrent() != 0) // currentForAreaLinkList�� ������
		{
			this->currentForAreaLinkList = areaLinkList.GetCurrent()->GetObject();
		}
		else
		{
			this->currentForAreaLinkList = 0;
		}

		if (deletedNodeLink == 0)
		{
			areaLink = 0;
		}
	}


	return areaLink;
}


RResource* SArea::RegisterRResourceLink(RResource* rResourceLink)
{
	this->rResourceLink = rResourceLink;
	return rResourceLink;
}



Picker* SArea::RegisterPickerLink(Picker* pickerLink)
{
	Picker *newPickerLink = this->pickerLinkList.AppendFromTail(pickerLink)->GetObject();
	this->lengthForPickerLinkList = this->pickerLinkList.GetLength();
	this->currentForPickerLinkList = this->pickerLinkList.GetCurrent()->GetObject();
	return newPickerLink;
}




Long CompareAreaLinks(void* one, void* other)
{
	Long ret = -1;
	if ((Area*)one == (Area*)other)
	{
		ret = 0;
	}

	return ret;
}










/*

			Count

*/

Long SArea::CountPickers()
{
	Long count = 0;
	if (this->lengthForAreaLinkList > 0)
	{

		Area *areaLink = this->areaLinkList.First()->GetObject();
		for (Long i = 0; i < this->areaLinkList.GetLength(); i++)
		{
			if (areaLink->GetPickerLink() != 0)
			{
				count += 1;
			}
			areaLink = this->areaLinkList.Next()->GetObject();
		}
	}
	return count;
}

Long SArea::CountRers()
{
	Long count = 0;
	if (this->lengthForAreaLinkList > 0)
	{

		Area *areaLink = this->areaLinkList.First()->GetObject();
		for (Long i = 0; i < this->areaLinkList.GetLength(); i++)
		{
			count += areaLink->GetLengthForRerLinks();

			areaLink = this->areaLinkList.Next()->GetObject();
		}
	}
	return count;
}

Long SArea::CountRRequests()
{ 
	Long count = 0;
	if (this->lengthForAreaLinkList > 0)
	{

		Area *areaLink = this->areaLinkList.First()->GetObject();
		for (Long i = 0; i < this->areaLinkList.GetLength(); i++)
		{
			count += areaLink->GetLengthForRRequests();

			areaLink = this->areaLinkList.Next()->GetObject();
		}
	}
	return count;

}








Area* SArea::First()
{
	Area* areaLink = 0;
	LinkedList<Area*>::Node* nodeLink = this->areaLinkList.First();
	if (nodeLink != 0)
	{
		areaLink = nodeLink->GetObject();
	}
	return areaLink;
}

Area* SArea::Previous()
{
	Area* areaLink = this->areaLinkList.Previous()->GetObject();
	return areaLink;
}
Area* SArea::Next()
{
	Area* areaLink = this->areaLinkList.Next()->GetObject();
	return areaLink;
}
Area* SArea::Last()
{
	Area* areaLink = this->areaLinkList.Last()->GetObject();
	return areaLink;
}



Picker* SArea::FirstForPickerLink()
{
	Picker* pickerLink = 0;
	LinkedList<Picker*>::Node* nodeLink = this->pickerLinkList.First();
	if (nodeLink != 0)
	{
		pickerLink = nodeLink->GetObject();
	}
	return pickerLink;
}
Picker* SArea::PreviousForPickerLink()
{
	Picker* pickerLink = this->pickerLinkList.Previous()->GetObject();
	return pickerLink;
}
Picker* SArea::NextForPickerLink()
{
	Picker* pickerLink = this->pickerLinkList.Next()->GetObject();
	return pickerLink;
}
Picker* SArea::LastForPickerLink()
{
	Picker* pickerLink = this->pickerLinkList.Last()->GetObject();
	return pickerLink;
}


/*
SArea::SArea()
{	
	this->controlRResourceLink = new ControlRResource;
	this->controlRerLink = new ControlRer;
	this->controlPickerLink = new ControlPicker;
	this->controlZoneLink = new ControlZone;
	this->controlRRequestLink = new ControlRRequest;

	this->rResourceLink = 0;
}
SArea::SArea(const SArea& source)
{
		
	this->rResourceLink = source.rResourceLink;
	/* ����Ѥ�;
	this->controlRerLink = new ControlRer;
	this->controlPickerLink = new ControlPicker;
	this->controlZoneLink = new ControlZone;
	//*/
/*
}

SArea::~SArea(){}

SArea& SArea::operator=(const SArea& source)
{
	
	this->rResourceLink = source.rResourceLink;
		/* ����Ѥ�;
		this->controlRerLink = new ControlRer;
		this->controlPickerLink = new ControlPicker;
		this->controlZoneLink = new ControlZone;
		//*/
/*
	return *this;
}

Rer* SArea::RegisterNewRer(string id, string pw, string name, string phone, Address addressTotal)
{
	// Address�� ������� addressId�� ���Ѵ�.
	string addressId = addressTotal.GetSiDo() + " " + addressTotal.GetGuGun() + " " + addressTotal.GetDong();

	// NewRer�� ���� zoneLink ���Ѵ�
	Zone* zoneLink = this->controlZoneLink->GetOrRecordZone(addressId);

	// NewRer���
	Rer* rerLink = this->controlRerLink->RecordRer(id, pw, name, phone, addressTotal, addressId, zoneLink);

	// Zone�� NewRer���
	this->controlZoneLink->RegisterRerInZone(zoneLink, rerLink);

	return rerLink;
}


Picker* SArea::RegisterNewPicker(string id, string pw, string name, string phone)
{
	Picker *picker = this->controlPickerLink->RecordPicker(id, pw, name, phone);
	return picker;
}


RResource* SArea::RegisterRResource(string id, string pw, string companyTelephone, string CEOPhone, Address addressTotal ) // ���ο� RCenter�� ����Ѵ�
{
	RResource *RResourceLink = this->controlRResourceLink->RecordRResource( id, pw, companyTelephone, CEOPhone, addressTotal );

	return RResourceLink;
}//*/
/*

RValue SArea::RResourceModifyRerRValue( string rResourceId, Long paperValue,Long canValue,Long glassValue,	Long plasticValue,
		Long glassBottleValue,
 Long clothesValue,Long etcValue,	Long eletricValue) // RCenter RerRValue�ü� ����
{
	RValue rerValue;
	RResource* rResourceLink  = this->controlRResourceLink->FindRResource(rResourceId);
	if( rResourceLink != 0)
	{
		rerValue = rResourceLink->RecordRerRValue(paperValue, canValue, glassValue, plasticValue, clothesValue, etcValue,	eletricValue);
	}

	return rerValue;
}


RValue SArea::RResourceModifyPickerRValue( string rResourceId, Long paperValue,Long canValue,Long glassValue,	Long plasticValue,
		Long glassBottleValue,
 Long clothesValue,Long etcValue,	Long eletricValue) // RCenter PicerValue�ü� ����
{
	RValue pickerRValue;
	RResource *rResourceLink = this->controlRResourceLink->FindRResource( rResourceId );

	if( rResourceLink != 0)
	{
		pickerRValue = rResourceLink->RecordPickerRValue(paperValue, canValue, glassValue, plasticValue, clothesValue, etcValue,	eletricValue);
	}

	return pickerRValue;
}


void SArea::LinkPickerAndZone( string pickerId, Address addressTotal )   // Ư�� picker�� zone�� ������Ų��
{
	Picker *pickerLink = this->controlPickerLink->FindPicker( pickerId );
	
	if( pickerLink != 0)
	{
		string addressId = addressTotal.GetSiDo() + " " + addressTotal.GetGuGun() + " " + addressTotal.GetDong();
		Zone *zoneLink = this->controlZoneLink->GetOrRecordZone( addressId );
		
		pickerLink->RecordZoneLink( zoneLink ); // picker���� ��Ͻ�Ų��
		zoneLink->pickerLink = pickerLink; // zone�� ��� picker�� ��Ͻ�Ų��
	}
}


void SArea::LinkSAreaAndRResource( RResource* rResourceLink ) // Ư�� rCenter�� zone�� ������Ų��
{
	this->rResourceLink = rResourceLink;
}


RRequest* SArea::RerMakeRRequest( string rerId, Long RType, Long pickUpType )
{
	RRequest *rRequestLink = 0;
	Rer *rerLink = this->controlRerLink->FindRer( rerId );
	

	if ( rerLink != 0 ) // rerId�� ã���� ���� 
	{
		// ZoneLink�� ���Ѵ�.
		Zone *zoneLink = rerLink->GetZoneLink();

		Picker *pickerLink = zoneLink->pickerLink;


		/// RRequest�� ����Ѵ�.
			string dateId = "";
			string rRequestId = "";
			Date today = Date::Today();
			

			ostringstream convert; 
			convert <<today.GetYear();
			convert << today.GetMonth();
			convert << today.GetDay();
			dateId = convert.str();
			rRequestId = rerLink->GetId()+ " "  + dateId;
			
			// ControlRRequest�� ControlDateIndexRRequest�� �����Ѵ�.
			rRequestLink = this->controlRRequestLink->RecordRRequest(rerLink, zoneLink, zoneLink->pickerLink, RType, pickUpType, rRequestId);

			// Rer, Picker�� RRequestLink�� �����Ѵ�.
			rerLink->RegisterRRequestLink(rRequestLink);
			if( pickerLink != 0)
			{
				pickerLink->RegisterRRequestLink(rRequestLink);
			}
	}
	return rRequestLink;

}
//*/
/*
Long SArea::RerCheckRPoint(string rerId)
{
	return this->controlRerLink->FindRer(rerId)->GetRPoint().GetRPointValue();
}



R SArea::PickerReportR(string pickerId, string rRequestId, Long paperWeight,Long canWeight, Long glassWeight, Long plasticWeight,
		Long glassBottleWeight, Long clothesWeight,	Long EtcWeight, string electronics, string electronicsDescription )
{
	/*
	ó������ NewStructure
	1. R�� �����
	2. RResource�� RValue�� ���Ѵ�
	3. R�� RPoint��ġ�� ���Ѵ�

	4. RRequest�� R, RPoint�� ����Ѵ� 
	5. RRequest�� pickUp�� ����Ѵ�
	6. Rer���� RPoint�� �����Ѵ�
	
	7. ���Ÿ� �Ϸ��Ѵ�
	8. ������

	
	��ó������ oldStructure
	1. pickerId�� PickerLink�� ã�´�
	2. ã�� PickerLink�� �Ҽ� RCenter�� RCenterLink�� ���Ѵ�
	
	3. RCenterLink�� �ü�����(RValue)�� ����
		1] rerRValue
		2) pickerRValue

	5. R�� ���� ������ �ü������� ControlR::RecordR�� ���ؼ� R�� ����Ѵ�
	 
	6. Rer�� R�Ǹ� ������ ����Ѵ� ## RPoint::RecordRTransaction
	7. RPoint�� Rer���� �����Ѵ� ## RPoint::RTransactionAffectRPointValue

	8. RRequest�� ���ſϷḦ ǥ���Ѵ�
	9. ������
	*/

/*
	R newR;

	RRequest* rRequestLink = this->controlRRequestLink->FindRRequest(rRequestId); // RRequest�� ã�´�
	if( rRequestLink !=0) // ã������
	{	// R������� ���
		newR = rRequestLink->RecordR(paperWeight, canWeight, glassWeight, plasticWeight, clothesWeight, EtcWeight, electronics, electronicsDescription);
		
		// �ü��� ���Ѵ�
		RValue rerValue = this->rResourceLink->GetRerRValue();
		RValue pickerValue =this->rResourceLink->GetPickerRValue();

		// RPoint�� ����Ѵ�
		rRequestLink->RecordRerRPointValue(newR, rerValue);
		rRequestLink->RecordPickerRPointValue(newR, rerValue);

		// PickUp�ϷḦ ����Ѵ�
		Picker* pickerLink = rRequestLink->GetPickerLink();
		LinkedList<RRequest*>::Node* foudNodeLink = pickerLink->FindRRequestLinkNode(rRequestId);
		pickerLink->PickUpComplete(foudNodeLink);

		// Rer���� RPoint�� �����Ѵ�
		Rer* rerLink = rRequestLink->GetRerLink();
		RTransaction* rTransactionLink = rerLink->ReceiveRPointByRSelling(R�Ǹ�, rRequestLink->GetRerRPointValue(), "��Ȱ��ǰ �Ǹ�");
	}
	return newR;
}

//*/
