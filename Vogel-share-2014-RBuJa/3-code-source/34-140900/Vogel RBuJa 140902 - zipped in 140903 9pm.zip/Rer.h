// RER.h
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		Rer.h
��������:		140626
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#ifndef _RER_H
#define _RER_H

#include "LibDate.h"
#include "LibAddress - updated in 140726.h"
#include "LibLinkedList - added in 140725.h"
#include "LibDateIndexes.h"

#include "RPoint.h"
#include "RTransaction.h"
//#include "Zone.h"
//#include "RRequest.h"

//#include "ControlRRequestLink.h"
//#include "ControlDateIndexForRRequest.h"


#include <string>
using namespace std;

#define IdMinLength 6							// id, �ĺ����� �ּ� ���� ����
#define PwMinLength 8							// pw, ��й�ȣ�� �ּ� ���� ����
#define TNumberMinLength 10				// phone, ��ȭ��ȣ�� �ּ� ���� ����


class Area;
//class Zone;
class RRequest;

class Rer
{
public:										// �⺻ �޼ҵ�
	Rer();
	Rer(string id);
	
	Rer(
		string id,
		string pw,
		string name,
		string phone,
		string addressTotal,
		string addressId,
		Area* areaLink);
	//*/
	Rer(
		string id,
		string pw,
		string name,
		string phone,

		string addressTotal,
		string addressId,

		Long year,
		Long month,
		Long day,
		Long weekDay,
		Long hour,
		Long min,
		Long sec,

		Area* areaLink);

	Rer(const Rer& source);
	~Rer();

	Rer& operator=(const Rer& source);

public: // GetAt
	string GetId() const;
	string GetPw() const;
	string GetName() const;
	string GetPhone() const;

	string GetAddressTotal() const;
	string GetAddressId() const;
	Date GetJoinDate() const;

	RPoint* GetRPoint() const;


	Area* GetAreaLink() const;
	RPoint* GetRPointLink() const;

	Long GetLength() const;
	RRequest* GetCurrent() const;


	LinkedList<RRequest*>::Node* GetHead() const;

public:
	RRequest* RRequestLinkFirst();
	RRequest* RRequestLinkNext();
	RRequest* RRequestLinkPrevious();
	RRequest* RRequestLinkLast();


public: // GetAt - �ڷᱸ����
	/*
	Long GetLengthForRRequestLinks() const;
	Long GetLengthForDateIndexForRRequest() const;
	DateIndexForRRequest* GetCurrentForDateIndexForRRequest() const;
	DateIndexForRRequest* GetTailForDateIndexForRRequest() const;
	RRequest* GetCurrentForRRequestLinks() const;
	//*/
public:
	RRequest* RegisterRRequestLink(RRequest* rRequestLink);
	RTransaction* ReceiveRPointByRSelling(RTransactionType type, Long rPoint, string description);



public:

	RRequest* FirstForRRequestLink();
	RRequest* NextForRRequestLink();
	RRequest* PreviousForRRequestLink();
	RRequest* LastForRRequestLink();

private:
	string id;
	string pw;
	string name;
	string phone;

	string addressTotal;
	string addressId;							// Address�� �������� ������ ���� string������ ���ʿ��� ��ȯ�� �����ش�.
	Date joinDate;
	
	RPoint rPoint;

private:
	Area* areaLink;


private:
	LinkedList<RRequest*> rRequestList;
	Long length;
	RRequest* current;




private:
	DateIndexes<LinkedList<RRequest*>::Node*> dateRRequestLinkIndexes;
	Long lengthForDateRRequestLinkIndexes;
	DateIndexes<LinkedList<RRequest*>::Node*>::Node* currentForDateRRequestLinkIndexes;


private:
//	ControlRRequestLink controlRRequestLink;
//	ControlDateIndexForRRequest controlDateIndexForRRequest;
};

inline string Rer::GetId() const
{
	return this->id;
}
inline string Rer::GetPw() const
{
	return this->pw;
}
inline string Rer::GetName() const
{
	return this->name;
}
inline string Rer::GetPhone() const
{
	return this->phone;
}


inline string Rer::GetAddressTotal() const
{
	return this->addressTotal;
}
inline string Rer::GetAddressId() const
{
	return this->addressId;
}
inline Date Rer::GetJoinDate() const
{
	return this->joinDate;
}



inline RPoint* Rer::GetRPoint() const
{
	return const_cast<RPoint*>(&(this->rPoint));
}


inline Area* Rer::GetAreaLink() const
{
	return this->areaLink;
}


inline Long Rer::GetLength() const
{
	return this->length;
}
inline RRequest* Rer::GetCurrent() const
{
	return const_cast<RRequest*>(this->current);
}


inline LinkedList<RRequest*>::Node* Rer::GetHead() const
{
	return const_cast<LinkedList<RRequest*>::Node*>(this->rRequestList.GetHead());
}
/*
inline RPoint* Rer::GetRPointLink() const
{
	return this->rPointLink;
}

inline Long Rer::GetLengthForRRequestLinks() const
{
	return this->controlRRequestLink.GetLength();
}
inline RRequest* Rer::GetCurrentForRRequestLinks() const
{
	return this->controlRRequestLink.GetCurrent();
}
inline Long Rer::GetLengthForDateIndexForRRequest() const
{
	return this->controlDateIndexForRRequest.GetLength();
}
inline DateIndexForRRequest* Rer::GetCurrentForDateIndexForRRequest() const
{
	return this->controlDateIndexForRRequest.GetCurrent();
}
inline DateIndexForRRequest* Rer::GetTailForDateIndexForRRequest() const
{
	return this->controlDateIndexForRRequest.GetTail();
}	
//*/
#endif //_RER_H