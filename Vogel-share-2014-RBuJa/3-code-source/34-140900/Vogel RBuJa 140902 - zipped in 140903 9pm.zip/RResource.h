// RRESOURCE.h
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		RResource.h
��������:		140626
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#ifndef _RRESOURCE_H
#define _RRESOURCE_H

#include "LibDate.h"
#include "RValue.h"

#include "LibLinkedList - added in 140725.h"

#include <string>
using namespace std;

class Area;
class SArea;
class Rer;
class Picker;

class RResource {

public:
	RResource();
	RResource(
		string id,
		string pw,
		string companyName,
		string companyTelephone,
		string CEOName,
		string CEOPhone
		);

	RResource(string id,
		string pw,
		string companyName,
		string companyTelephone,
		string CEOName,
		string CEOPhone,
		string addressTotal,
		string addressId
		);

	RResource(string id,
		string pw,
		string companyName,
		string companyTelephone,
		string CEOName,
		string CEOPhone,
		string addressTotal,
		string addressId,
		RValue* rerRValue,
		RValue* pickerRValue
		);

	RResource(
		string id,
		string pw,
		string companyName,
		string companyTelephone,
		string CEOName,
		string CEOPhone,
		string addressTotal,
		string addressId,

		Long year,
		Long month,
		Long day,
		Long weekDay,
		Long hour,
		Long min,
		Long sec,

		Long paperValueForRer,
		Long plasticValueForRer,
		Long glassBottleValueForRer,
		Long customGroupValueForRer,

		Long clothesValueForRer,
		Long steelValueForRer,
		Long wireValueForRer,

		Long stainlessValueForRer,
		Long copperValueForRer,


		Long paperValueForPicker,
		Long plasticValueForPicker,
		Long glassBottleValueForPicker,
		Long customGroupValueForPicker,

		Long clothesValueForPicker,
		Long steelValueForPicker,
		Long wireValueForPicker,

		Long stainlessValueForPicker,
		Long copperValueForPicker
		);


	//RResource(   string id, string pw, string companyTelephone, string CEOPhone, string addressTotal, RValue rerRValue, RValue pickerRValue, SArea *sArerLink);
	RResource(const RResource& source);
	~RResource();
	
	RResource& operator=(const RResource& source);



public:
//	Area* RegisterAreaLink(Area *newAreaLink);
	/*
	Picker* RecordPickerLink( Picker* pickerLink );
	
	RRequest* RecordRRequestLink(RRequest* rRequestLink);
	//*/


	RValue* RecordRerRValue(
		Long paperValue,
		Long plasticValue,
		Long glassBottleValue,
		Long customGroupValue,

		Long clothesValue,
		Long steelValue,
		Long wireValue,

		Long stainlessValue,
		Long copperValue,

		Array<string> *codes,
		Array<Long> *values
		);

	RValue* RecordPickerRValue(
		Long paperValue,
		Long plasticValue,
		Long glassBottleValue,
		Long customGroupValue,

		Long clothesValue,
		Long steelValue,
		Long wireValue,

		Long stainlessValue,
		Long copperValue,

		Array<string> *codes,
		Array<Long> *values
		);

//	Picker* FindPickerLink(string pickerId);
//	Picker* DeletePickerLink(Picker* pickerLink);




public: // GetAt
	string GetId() const;
	string GetPw() const;
	string GetCompanyName() const;
	string GetCompanyTelephone() const;
	string GetCEOName() const;
	string GetCEOPhone() const;


	string GetAddressTotal() const;
	string GetAddressId() const;

	Date GetJoinDate() const;
	RValue* GetRerRValue() const;
	RValue* GetPickerRValue() const;

//	Long GetLengthForAreaList() const;
//	Area* GetCurrentForAreaList() const;

	SArea* GetSAreaLink() const;

public: // ��� ��������
	SArea* sAreaLink;


private:
	string id;
	string pw;
	string companyName;
	string companyTelephone;
	string CEOName;
	string CEOPhone;

	string addressTotal;
	string addressId;

	Date joinDate;
	RValue* rerRValue; // Rer�� �ü�����
	RValue* pickerRValue; // Picker�� �ü�����
/*
private:
	LinkedList<Area*> areaLinkList;
	Long lengthForAreaList;
	Area* currentForAreaList;
//*/
};


inline string RResource::GetId() const
{
	return this->id;
}
inline string RResource::GetPw() const
{
	return this->pw;
}
inline string RResource::GetCompanyName() const
{
	return this->companyName;
}
inline string RResource::GetCompanyTelephone() const
{
	return this->companyTelephone;
}
inline string RResource::GetCEOName() const
{
	return this->CEOName;
}
inline string RResource::GetCEOPhone() const
{
	return this->CEOPhone;
}




inline string RResource::GetAddressTotal() const
{
	return this->addressTotal;
}
inline string RResource::GetAddressId() const
{
	return this->addressId;
}






inline Date RResource::GetJoinDate() const
{
	return this->joinDate;
}
inline RValue* RResource::GetRerRValue() const
{
	return this->rerRValue;
}
inline RValue* RResource::GetPickerRValue() const
{
	return this->pickerRValue;
}





/*
inline Long RResource::GetLengthForAreaList() const
{
	return this->lengthForAreaList;
}
inline Area* RResource::GetCurrentForAreaList() const
{
	return const_cast<Area*>(this->currentForAreaList);
}
//*/



inline SArea* RResource::GetSAreaLink() const
{
	return const_cast<SArea*>(this->sAreaLink);
}
#endif //_RRESOURCE_H