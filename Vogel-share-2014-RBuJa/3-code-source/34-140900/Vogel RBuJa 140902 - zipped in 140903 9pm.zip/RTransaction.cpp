// RTransaction.cpp
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		RTransaction.cpp
��������:		140626
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#include "RTransaction.h"

RTransaction::RTransaction() {

	this->rTransactionType = ����;
	this->occurredDate = Date::Today();
	this->rPointValue = 0;
	this->description = "";
}

RTransaction::RTransaction(RTransactionType rTransactionType, Long rPointValue, string description) {

	this->rTransactionType = rTransactionType;
	this->occurredDate = Date::Today();
	this->rPointValue = rPointValue;
	this->description = description;
}

RTransaction::RTransaction(Long rTranstactionType, Long rPointValue, string description, Long year, Long month, Long day, Long weekDay, Long hour, Long min, Long sec)
{
	switch (rTranstactionType)
	{
	case 0: this->rTransactionType = ����; break;
	case 1: this->rTransactionType = R�Ǹ�; break;
	case 2: this->rTransactionType = ���Ǳ���; break;
	case 3: this->rTransactionType = R����Ʈ����; break;

	default: break;
	}
	Date date(year, month, day, weekDay, hour, min, sec);
	this->occurredDate = date;
	this->rPointValue = rPointValue;
	this->description = description;
}

RTransaction::RTransaction(const RTransaction& source)
{
	this->rTransactionType = source.rTransactionType;
	this->occurredDate = source.occurredDate;
	this->rPointValue = source.rPointValue;
	this->description = source.description;
}

RTransaction::~RTransaction() {}

RTransaction& RTransaction::operator=(const RTransaction& source)
{
	this->rTransactionType = source.rTransactionType;
	this->occurredDate = source.occurredDate;
	this->rPointValue = source.rPointValue;
	this->description = source.description;
	return *this;
}

