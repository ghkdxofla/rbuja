//FormMakePicker.h

#ifndef _FORMMAKEPICKER_H
#define _FORMMAKEPICKER_H
#include "resource.h"
#include <afxwin.h>

#include <iostream>
using namespace std;

class Picker;
class FormMakePicker : public CDialog
{
public:
	enum { IDD = IDD_K2_MAKEPICKER };

public: // Default Setting
	FormMakePicker(int formType, string pickerId = "", CWnd *parent = NULL);
	virtual BOOL OnInitDialog();
	virtual void OnOK(); // EnterŰ â �ڵ����� ������ ���� �������̵�
	virtual void DoDataExchange(CDataExchange* pDX);

public: // Settings
	void SettingForMakePicker();
	void SettingForModifyPicker();

private:
	int formType;
	string pickerId;
	Picker* pickerLink;

protected:
	// ID_BUTTON_OK
	afx_msg void OnOKButtonClicked();

	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeEdit6();
	afx_msg void OnEnChangeEdit8();
	CComboBox m_areaCombo;
};


#endif