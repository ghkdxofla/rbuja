// SArea.h
/*

������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		SArea.h
��������:		140804
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/



#ifndef _SAREA_H
#define _SAREA_H

#include "LibLinkedList - added in 140725.h"
#include "Area.h"
#include <string>
using namespace std;

class Area;
class RResource;

class SArea
{
public:
	SArea();
	SArea(string sAreaId, RResource* rResourceLink = 0);
	SArea(const SArea& source);
	~SArea();
	SArea& operator=(const SArea& source);

public:
	Area* RegisterAreaLink(Area* areaLink);
	Area* UnregisterAreaLink(Area* areaLink);

	RResource* RegisterRResourceLink(RResource* rResourceLink);
	Picker* RegisterPickerLink(Picker* pickerLink);

public: // Count
	Long CountPickers();
	Long CountRers();
	Long CountRRequests();

public: // GetAt
	Long GetLengthForAreaLinks() const;
	Area* GetCurrentForAreaLinks() const;

//	string GetName() const;
	string GetId() const;
	RResource* GetRResourceLink() const;


	Long GetLengthForAreaLinkList() const;
	Area* GetCurrentForAreaLinkList() const;



	Long GetLengthForPickerLinkList() const;
	Picker* GetCurrentForPickerLinkList() const;


public:
	Area* First();
	Area* Previous();
	Area* Next();
	Area* Last();

public:
	Picker* FirstForPickerLink();
	Picker* PreviousForPickerLink();
	Picker* NextForPickerLink();
	Picker* LastForPickerLink();
	
private:
//	string name;
	string sAreaId;// '����������'�� ������ id // RResourceId + " " + RResourceAddressId
	RResource* rResourceLink; // SArea ��� �ڿ���ũ



private:
	LinkedList<Area*> areaLinkList;
	Long lengthForAreaLinkList;
	Area* currentForAreaLinkList;


private:
	LinkedList<Picker*> pickerLinkList;
	Long lengthForPickerLinkList;
	Picker* currentForPickerLinkList;

	


	/*
public: // NewData

	Rer* RegisterNewRer(string id, string pw, string name, string phone, Address addressTotal);
	Picker* RegisterNewPicker(string id, string pw, string name, string phone);
	RResource* RegisterRResource(string id, string pw, string companyTelephone, string CEOPhone, Address addressTotal ); 


public: // Rer Function
	RRequest* RerMakeRRequest( string rerId, Long RType, Long pickUpType );
	Long RerCheckRPoint( string rerId );


public: // RResource Function
	RValue RResourceModifyRerRValue( string rResourceId, Long paperValue,Long canValue,Long glassValue,	Long plasticValue,
		Long glassBottleValue,
 Long clothesValue,Long etcValue,	Long eletricValue) ;	 // RCenter RerRValue�ü� ����
	RValue RResourceModifyPickerRValue( string rResourceId, Long paperValue,Long canValue,Long glassValue,	Long plasticValue,
		Long glassBottleValue,
 Long clothesValue,Long etcValue,	Long eletricValue) ;	 // RCenter PicerValue�ü� ����


public: // Picker Function
	R PickerReportR(string pickerId, string rRequestId, Long paperWeight,Long canWeight, Long glassWeight, Long plasticWeight,
		Long glassBottleWeight, Long clothesWeight,	Long EtcWeight, string electronics, string electronicsDescription );


public:
	void LinkPickerAndZone( string pickerId, Address addressTotal );   // Ư�� picker�� zone�� ������Ų��
	void LinkSAreaAndRResource( RResource* rResourceLink ); // Ư�� rCenter�� zone�� ������Ų��
	
public: // GetAt
	ControlRResource* GetControlRResourceLink() const;
	ControlRer* GetControlRerLink() const;
	ControlPicker* GetControlPickerLink() const;
	ControlZone* GetControlZoneLink() const;


private: // Control Link
	ControlRResource* controlRResourceLink;
	ControlRer* controlRerLink;	
	ControlPicker* controlPickerLink;
	ControlZone* controlZoneLink;
	ControlRRequest* controlRRequestLink;

	RResource* rResourceLink;
	//*/

};

Long CompareAreaLinks(void* one, void* other);

inline Long SArea::GetLengthForAreaLinks() const
{
	return this->lengthForAreaLinkList;
}
inline Area* SArea::GetCurrentForAreaLinks() const
{
	return const_cast<Area*>(this->currentForAreaLinkList);
}



/*
inline string SArea::GetName() const
{
	return this->name;
}//*/


inline string SArea::GetId() const
{
	return this->sAreaId;
}
inline RResource* SArea::GetRResourceLink() const
{
	return const_cast<RResource*>(this->rResourceLink);
}







inline Long SArea::GetLengthForAreaLinkList() const
{
	return this->lengthForAreaLinkList;
}
inline Area* SArea::GetCurrentForAreaLinkList() const
{
	return const_cast<Area*>(this->currentForAreaLinkList);
}










inline Long SArea::GetLengthForPickerLinkList() const
{
	return this->lengthForPickerLinkList;
}
inline Picker* SArea::GetCurrentForPickerLinkList() const
{
	return const_cast<Picker*>(this->currentForPickerLinkList);
}
/*
inline ControlRResource* SArea::GetControlRResourceLink() const
{
	return const_cast<ControlRResource*>(this->controlRResourceLink);
}
//*/
/*
inline ControlRer* SArea::GetControlRerLink() const
{
	return const_cast<ControlRer*>(this->controlRerLink);
}


inline ControlPicker* SArea::GetControlPickerLink() const
{
	return const_cast<ControlPicker*>(controlPickerLink);
}


inline ControlZone* SArea::GetControlZoneLink() const
{
	return const_cast<ControlZone*>(controlZoneLink);
}


//*/
#endif