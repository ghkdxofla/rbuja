// Picker.h
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		Picker.h
��������:		140626
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#ifndef _PICKER_H
#define _PICKER_H

#include "LibDate.h"
#include "RRequest.h"
#include "RPoint.h"

#include "LibLinkedList - added in 140725.h"
#include "LibDateIndexes.h"


#include <string>
using namespace std;

typedef signed long int Long;


class Area;
class RResource;
class SArea;

class Picker {

public:
	Picker();
	Picker( string id );

	Picker(
		string id,
		string pw,
		string name,
		string phone);

	Picker(
		string id,
		string pw,
		string name,
		string phone,

		Long year,
		Long month,
		Long day,
		Long weekDay,
		Long hour,
		Long min,
		Long sec);

	Picker(
		string id,
		string pw,
		string name,
		string phone,

		Date joinDate,
		Long likeCount,

		RPoint rPoint,

		RResource* rResourceLink,
		SArea* sAreaLink,

		LinkedList<Area*> *areaLinks,
		LinkedList<RRequest*> *rRequestsToDo,
		DateIndexes<LinkedList<RRequest*>::Node*> *dateRRequestLinkIndexes
		);

	Picker(const Picker& source);
	~Picker();

	Picker& operator=(const Picker& source);


public:
	Area* RegisterAreaLink(Area *newArea); // ���zone�� ����Ѵ�
	RRequest* RegisterRRequestLink(RRequest* rRequestLink);	// rRequestList, rRequestsToDo�� rRequestLink�����ϴ� �Լ�

	LinkedList<RRequest*>::Node* FindRRequestLinkNode(string rRequestId);

	void PickUpComplete(RRequest *rRequestLink);

	void DeleteRRequestLinkNode(LinkedList<RRequest*>::Node* nodeLink);
	/*
	RRequest* RecordRRequestLink(RRequest* rRequestLink);
	RRequest* FindRRequestLink(string rRequestId);
//	RRequest* DeleteRRequestLink(RRequest *rRequestLink); // rRequestLink�� �����ϴ� ������ Ư�� rRequestLink�� �����
	void GetZonesLinks( Zone* (*zones), Long length );
	//*/
public: // GetAt
	string GetId() const;
	string GetPw() const;
	string GetName()	const;
	string GetPhone() const;

	RResource* GetRResourceLink() const;
	SArea* GetSAreaLink() const;

	Date GetJoinDate() const;
	Long GetLikeCount() const;

	LinkedList<Area*>* GetAreaLinks() const;
	LinkedList<RRequest*>* GetRRequestsToDo() const;
	DateIndexes<LinkedList<RRequest*>::Node*>* GetDateRRequestLinkIndexes() const;

	Long GetLengthForAreaLinks() const;
	Area* GetCurrentForAreaLinks()	 const;
	
	
	Long GetLengthForToDo() const;
	RRequest* GetCurrentForToDo() const;

	RPoint* GetRPoint() const;

public:
	Area* AreaLinkFirst();
	Area* AreaLinkNext();
	Area* AreaLinkPrivious();
	Area* AreaLinkLast();

public:
	RResource* rResourceLink;
	SArea* sAreaLink;


public:
	RRequest* FirstForRRequestToDoLink();
	RRequest* NextForRRequestToDoLink();
	RRequest* PreviousForRRequestToDoLink();
	RRequest* LastForRRequestToDoLink();
	


private:
	string id;
	string pw;
	string name;
	string phone;

	Date joinDate;
	Long likeCount;	// ���ƿ� ����

	RPoint rPoint;

	// 7��

private: // ��� ���� AreaLink���� �����ϴ� LinkedList
	LinkedList<Area*> areaLinks;						
	Long lengthForAreaLinks;
	Area* currentForAreaLinks;

	// 9��

private: // ToDo
	LinkedList<RRequest*> rRequestsToDo;
	Long lengthForToDo;
	RRequest* currentForToDo; 
	
	// 11��

private: // �ڷᱸ��
	DateIndexes<LinkedList<RRequest*>::Node*> dateRRequestLinkIndexes;
	Long lengthForDateRRequestLinkIndexes;
	DateIndexes<LinkedList<RRequest*>::Node*>::Node* currentForDateRRequestLinkIndexes;


};
Long CompareRRequestLinkId( void *one, void *other );


inline string Picker::GetId() const
{
	return this->id;
}
inline string Picker::GetPw() const
{
	return this->pw;
}
inline string Picker::GetName()	 const
{
	return this->name;
}
inline string Picker::GetPhone() const
{
	return this->phone;
}











inline Date Picker::GetJoinDate() const
{
	return this->joinDate;
}
inline Long Picker::GetLikeCount() const
{
	return this->likeCount;
}




inline RResource* Picker::GetRResourceLink() const
{
	return const_cast<RResource*>(this->rResourceLink);
}

inline SArea* Picker::GetSAreaLink() const
{
	return const_cast<SArea*>(this->sAreaLink);
}






inline LinkedList<Area*>* Picker::GetAreaLinks() const
{
	return const_cast<LinkedList<Area*>*>(&this->areaLinks);
}
inline LinkedList<RRequest*>* Picker::GetRRequestsToDo() const
{
	return const_cast<LinkedList<RRequest*>*>(&this->rRequestsToDo);
}
inline DateIndexes<LinkedList<RRequest*>::Node*>* Picker::GetDateRRequestLinkIndexes() const
{
	return const_cast<DateIndexes<LinkedList<RRequest*>::Node*>*>(&this->dateRRequestLinkIndexes);
}






inline Long Picker::GetLengthForAreaLinks() const
{
	return this->lengthForAreaLinks;
}
inline Area* Picker::GetCurrentForAreaLinks() const
{
	return const_cast<Area*>(this->currentForAreaLinks);
}







inline Long Picker::GetLengthForToDo() const
{
	return this->lengthForToDo;
}
inline RRequest* Picker::GetCurrentForToDo() const
{
	return const_cast<RRequest*>(this->currentForToDo);
}






inline RPoint* Picker::GetRPoint() const
{
	return const_cast<RPoint*>(&(this->rPoint));
}


#endif //_PICKER_H