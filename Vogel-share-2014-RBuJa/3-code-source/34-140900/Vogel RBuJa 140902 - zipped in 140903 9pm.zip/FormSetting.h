//FormSetting.h

#ifndef _FORMSETTING_H
#define _FORMSETTING_H

#include "resource.h"
#include <afxwin.h>

class FormSetting : public CDialog
{
public:
	enum { IDD = IDD_S1_SETTING };
public:
	FormSetting(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();

protected:

	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
};


#endif