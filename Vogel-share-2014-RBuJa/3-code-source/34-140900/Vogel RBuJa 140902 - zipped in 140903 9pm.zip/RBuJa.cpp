// RBuJa.cpp
/*
������Ʈ��:	�˺��� ( RBuJa )
�����̸�:		SArea.cpp
��������:		140804
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#include "RBuJa.h"
#include <sstream>
using namespace std;

RBuJa::RBuJa()
{
	this->areaListLink = new AreaList;
	this->controlRerLink = new ControlRer;
	this->controlPickerLink = new ControlPicker;
	this->controlRResourceLink = new ControlRResource;

	this->length = 0;
	this->current = 0;
}
RBuJa::RBuJa(const RBuJa& source)
{	
	this->areaListLink = source.areaListLink;
	this->controlRerLink =source.controlRerLink;
	this->controlPickerLink = source.controlPickerLink;
	this->controlRResourceLink = source.controlRResourceLink;

	this->sAreas = source.sAreas;
	this->length = source.length;
	this->current = source.current;
}
RBuJa::~RBuJa() {}

RBuJa& RBuJa::operator=(const RBuJa& source)
{
	this->areaListLink = source.areaListLink;
	this->controlRerLink =source.controlRerLink;
	this->controlPickerLink = source.controlPickerLink;
	this->controlRResourceLink = source.controlRResourceLink;

	this->sAreas = source.sAreas;
	this->length = source.length;
	this->current = source.current;
	return *this;
}

SArea* RBuJa::RecordSArea(string sAreaId, RResource* rRsourceLink)
{
	SArea newSArea(sAreaId, rRsourceLink);
	SArea* newSAreaLink = &(this->sAreas.AppendFromTail(newSArea)->GetObject());
	this->length = this->sAreas.GetLength();
	this->current = &(this->sAreas.GetCurrent()->GetObject());

	if (rRsourceLink != 0 && newSAreaLink != 0)
	{
		rRsourceLink->sAreaLink = newSAreaLink;
	}

	return newSAreaLink;
}

Rer* RBuJa::RegisterNewRer(
	string id,
	string pw,
	string name,
	string phone,

	string addressTotal,
	string addressId,

	Long year,
	Long month,
	Long day,
	Long weekDay,
	Long hour,
	Long min,
	Long sec,

	Area* areaLink)
{
	Rer* newRerLink = this->controlRerLink->RecordRer(id, pw, name, phone, addressTotal, addressId, year, month, day, weekDay, hour, min, sec, areaLink);
	return newRerLink;
}


Picker* RBuJa::RegisterNewPicker(
	string id,
	string pw,
	string name,
	string phone,

	Long year,
	Long month,
	Long day,
	Long weekDay,
	Long hour,
	Long min,
	Long sec
	)
{
	Picker *newPickerLink = this->controlPickerLink->RecordPicker(id, pw, name, phone, year, month, day, weekDay, hour, min, sec);
	return newPickerLink;
}

RResource* RBuJa::RegisterNewRResource(
	string id,
	string pw,
	string companyName,
	string companyTelephone,
	string CEOName,
	string CEOPhone,
	string addressTotal,
	string addressId,

	Long year,
	Long month,
	Long day,
	Long weekDay,
	Long hour,
	Long min,
	Long sec,

	Long paperValueForRer,
	Long plasticValueForRer,
	Long glassBottleValueForRer,
	Long customGroupValueForRer,

	Long clothesValueForRer,
	Long steelValueForRer,
	Long wireValueForRer,

	Long stainlessValueForRer,
	Long copperValueForRer,


	Long paperValueForPicker,
	Long plasticValueForPicker,
	Long glassBottleValueForPicker,
	Long customGroupValueForPicker,

	Long clothesValueForPicker,
	Long steelValueForPicker,
	Long wireValueForPicker,

	Long stainlessValueForPicker,
	Long copperValueForPicker
	)
{
	RResource *rResourceLink = this->controlRResourceLink->RecordRResource
		(
		id,
		pw,
		companyName,
		companyTelephone,
		CEOName,
		CEOPhone,
		addressTotal,
		addressId,

		year,
		month,
		day,
		weekDay,
		hour,
		min,
		sec,

		paperValueForRer,
		plasticValueForRer,
		glassBottleValueForRer,
		customGroupValueForRer,

		clothesValueForRer,
		steelValueForRer,
		wireValueForRer,

		stainlessValueForRer,
		copperValueForRer,


		paperValueForPicker,
		plasticValueForPicker,
		glassBottleValueForPicker,
		customGroupValueForPicker,

		clothesValueForPicker,
		steelValueForPicker,
		wireValueForPicker,

		stainlessValueForPicker,
		copperValueForPicker
		);
	return rResourceLink;
}








/*

			Modify

*/

Picker* RBuJa::ModifyPicker(
	string id,
	string pw,
	string name,
	string phone
	)
{
	// Picker�� ã�´�.
	Picker* pickerLink = 0;

	if (id != "") // id�� ������
	{
		pickerLink = FindPicker(id);
	}

	if (pickerLink != 0) // pickerLink�� ������
	{
		Picker* oldPickerLink = pickerLink;

		pickerLink = controlPickerLink->ModifyPicker(pickerLink, pw, name, phone);
	}



	return pickerLink;
}















SArea* RBuJa::FindSArea(string sAreaId)
{
	SArea* sAreaLink = 0;
	LinkedList<SArea>::Node* nodeLink = this->sAreas.LinearSearchUnique(&sAreaId, CompareSAreaIds);
	if (nodeLink != 0)
	{
		sAreaLink = &(nodeLink->GetObject());
	}

	return sAreaLink;
}

SArea* RBuJa::FindSAreaAndCount(Long& count, string sAreaId)
{
	SArea* sAreaLink = 0;
	LinkedList<SArea>::Node* nodeLink = this->sAreas.LinearSearchUniqueAndCount(count, &sAreaId, CompareSAreaIds);
	if (nodeLink != 0)
	{
		sAreaLink = &(nodeLink->GetObject());
	}

	return sAreaLink;
}


/*
���
	1. Ư�� area�� SArea�� ��Ͻ�Ų��
	2. SArea�� ����ϰ� �ִ� �ڿ��� �ְ�
		�̹� ��򰡿� �Ҵ�� ������ �ƴϸ� area�� RResource�� ��Ͻ�Ų��
	3. Area�� sAreaLink�� ��Ͻ�Ų��.
*/
Area* RBuJa::RegisterAreaLinkToSArea(string sAreaId, string areaId)
{
	SArea *sAreaLink = this->FindSArea(sAreaId);
	Area *areaLink = 0;
	if (sAreaLink != 0)
	{
		areaLink = this->FindArea(areaId);
		if (areaLink != 0 && areaLink->sAreaLink == 0) // �ش� ���Ƿ� �� ���������� �ְ� �Ҵ�� ������ �ƴϸ�
		{	
			// 1.
			sAreaLink->RegisterAreaLink(areaLink);

			// 2.
			if (sAreaLink->GetRResourceLink() != 0) 
			{  
				areaLink->rResourceLink = sAreaLink->GetRResourceLink();
			}

			// 3.
			areaLink->sAreaLink = sAreaLink;
		}
	}
	return areaLink;
}

/*
���
0. Area�� ���� SArea�� ���Ѵ�. // ���� â�� SAreaId�� ����� ����
1. Ư�� Area�� SArea���� ����.
2. Area�� �ڿ� �ּҰ� ������ �����.
3. Area�� sAreaLink�� �����.
*/
Area* RBuJa::UnregisterAreaLinkToSArea(string areaId)
{
	Area* areaLink = 0;
	areaLink = this->FindArea(areaId);

	if (areaLink != 0) // �ش� ���Ƿ� �� ������ ������
	{
		// �ش� Area�� ���� SAreaLink�� ���Ѵ�. �߿�!!
		SArea* sAreaLink = areaLink->sAreaLink;

		if (sAreaLink != 0) // SAreaLink�� ������
		{
			// 1.
			sAreaLink->UnregisterAreaLink(areaLink);

			// 2.
			if (areaLink->GetRResourceLink() != 0)
			{
				areaLink->rResourceLink = 0;
			}

			// 3.
			areaLink->sAreaLink = 0;
		}
	}

	return areaLink;
}



Long RBuJa::CountPickersInTheSArea(string sAreaId)
{
	Long count = 0;
	SArea *sAreaLink = this->FindSArea(sAreaId);
	if (sAreaLink != 0)
	{
		count = sAreaLink->CountPickers();
	}
	return count;

}
//************************************************************************************************************************************************************************//
//************************************************************************************************************************************************************************//
//***********************************************************************SArea******************************************************************************************//
/*
�Լ��� : RecordSArea
���� : ���ο� '���� ����'�� ����Ѵ�
*/
/*
SArea* RBuJa::RecordSArea(string sAreaId)
{
	SArea newSArea(sAreaId);
	SArea* newSAreaLink = &(this->sAreas.AppendFromTail(newSArea)->GetObject());

	return newSAreaLink;
}

/*
�Լ��� : GiveZone
���� : �ش� '���� ����'�� '��� ����'�� �Ҵ����ش�
*/
/*
Zone* GiveZone(SArea* sArea, string addressId)
{
	return sArea->GetControlZoneLink()->RecordZone(addressId);
}


SArea* RBuJa::FindSArea(string sAreaId)
{
	SArea* sAreaLink = 0;
	LinkedList<SArea>::Node* nodeLink = this->sAreas.LinearSearchUnique(&sAreaId, CompareSAreaId );
	if( nodeLink != 0)
	{
		sAreaLink = &(nodeLink->GetObject());
	}
	return sAreaLink;
}
//*/
//************************************************************************************************************************************************************************//
//************************************************************************************************************************************************************************//


/*
Rer* RBuJa::RegisterNewRer(string addressId, string id, string pw, string name, string phone, string addressTotal)
{
	/*
	ó������
	0. string addressAndAreaId ,string id, string pw, string name, string phone, string addressTotal �Է�
	1. addressAndAreaId�� areaLink�� ���Ѵ�
	2. Rer�� ���Խ�Ų��
	3. area�� rerLink�� ����Ѵ�
	*/
/*
	Rer* rerLink = 0;
	// 1.
	Area* areaLink = this->areaListLink->GetOrRecordArea(addressId);
	// 2.
	if (areaLink != 0)
	{
		rerLink = this->controlRerLink->RecordRer(id, pw, name, phone, addressTotal, addressId, areaLink);
		// 3.
		areaLink->RegisterRerLink(rerLink);
	}
	return rerLink;
}
//*/


Rer* RBuJa::RegisterNewRer(string addressId, string id, string pw, string name, string phone, string addressTotal)
{
	/*
	ó������
	0. string addressAndAreaId ,string id, string pw, string name, string phone, string addressTotal �Է�
	1. addressAndAreaId�� areaLink�� ���Ѵ�
	2. Rer�� ���Խ�Ų��
	3. arae�� rerLink�� ����Ѵ�
	*/
	Rer* rerLink = 0;
	// 1.
	Area* areaLink = this->areaListLink->GetOrRecordArea(addressId);
	// 2.
	if (areaLink != 0)
	{
		rerLink = this->controlRerLink->RecordRer(id, pw, name, phone, addressTotal, addressId, areaLink);
		// 3.
		areaLink->RegisterRerLink(rerLink);
	}
	return rerLink;
}









Picker* RBuJa::RegisterNewPicker(string id, string pw, string name, string phone)
{
	Picker *newPickerLink;
	newPickerLink = this->controlPickerLink->RecordPicker(id, pw, name, phone);
	return  newPickerLink;
}

RResource* RBuJa::RegisterNewRResource(string id, string pw, string companyName, string companyTelephone, string CEOName, string CEOPhone, string addressTotal, string addressId)
{
	RResource *rResourceLink = this->controlRResourceLink->RecordRResource(id, pw, companyName, companyTelephone, CEOName, CEOPhone, addressTotal, addressId);
	return rResourceLink;
}


void RBuJa::LinkPickerAndArea(string pickerId, string areaId)
{
	/*
	0. pickerId, areaId �Է¹޴´�
	1. Picker�� ã�´�.
	2. Area�� ã�´�.
	3. ���� �Ҵ��� �ش�.
	4. ������
	*/

	// 1.
	Picker *pickerLink = this->controlPickerLink->FindPicker(pickerId);
	if( pickerLink != 0)
	{	
		// 2.
		Area *areaLink = this->areaListLink->GetOrRecordArea(areaId);

		// 3.
		pickerLink->RegisterAreaLink(areaLink);
		areaLink->pickerLink = pickerLink;
	}
}






/*
���
1. SArea�� Ư�� arae�� ��Ͻ�Ų��
2. area�� Ư�� SArea�� ��Ͻ�Ų��
3. SArea�� ����ϰ� �ִ� �ڿ��� �ִٸ� arae�� RResource�� ��Ͻ�Ų��
*/

void RBuJa::LinkSAreaAndArea(string sAreaId, string areaId)
{
	SArea *sAreaLink = this->FindSArea(sAreaId);
	Area *areaLink = 0;
	if (sAreaLink != 0)
	{

		areaLink = this->FindArea(areaId);
		if (areaLink != 0)
		{	// 1.
			sAreaLink->RegisterAreaLink(areaLink);

			// 2.
			areaLink->sAreaLink = sAreaLink;

			// 3.
			if (sAreaLink->GetRResourceLink() != 0)
			{
				areaLink->rResourceLink = sAreaLink->GetRResourceLink();
			}

		}

	}
}

void RBuJa::LinkSAreaAndRResource(string sAreaId, string RResourceId)
{
	SArea *sAreaLink = this->FindSArea(sAreaId);
	if (sAreaLink != 0)
	{
		RResource *rResourceLink = this->FindRResource(RResourceId);
		if (rResourceLink != 0)
		{
			sAreaLink->RegisterRResourceLink(rResourceLink);
			rResourceLink->sAreaLink = sAreaLink;
		}
	}
}


void RBuJa::LinkSAreaAndPicker(string sAreaId, string pickerId)
{
	SArea *sAreaLink = this->FindSArea(sAreaId);
	if (sAreaLink != 0)
	{
		Picker *pickerLink = this->FindPicker(pickerId);
		if (pickerLink != 0)
		{
			sAreaLink->RegisterPickerLink(pickerLink);
			pickerLink->sAreaLink = sAreaLink;
		}
	}
}











RRequest* RBuJa::RerMakeRRequest(string rerId, Long RType, Long pickUpType, Date rerPickUpDate)
{
	/*
	0. string rerId, Long RType, Long pickUpType �Է�
	1. Rer ã�Ƶα�
	2. Area ã�Ƶα�
	3. Area�� RRequest����ϱ�
	4. ��� Picker���� RRequest����ϱ�
	5. Rer���� RRequest ����ϱ�
	6. ������
	*/

	RRequest *rRequestLink = 0;

	// 1.
	Rer *rerLink = this->controlRerLink->FindRer(rerId);

	if (rerLink != 0)
	{
		// 2.
		Area *areaLink = rerLink->GetAreaLink();

		// 3.
		rRequestLink = areaLink->RecordRRequest(rerLink, RType, pickUpType, rerPickUpDate);

		// 4.
		Picker *pickerLink = areaLink->GetPickerLink();
		pickerLink->RegisterRRequestLink(rRequestLink);

		// 5.
		rerLink->RegisterRRequestLink(rRequestLink);
	}

	return rRequestLink;
}
R* RBuJa::PickerReportR(
	string sAreaId,
	string areaId,
	string rRequestId,

	Long paperWeight,
	Long plasticWeight,
	Long glassBottleWeight,
	Long customGroupWeight,

	Long clothesWeight,
	Long steelWeight,
	Long wireWeight,

	Long stainlessWeight,
	Long copperWeight,

	string electronics,
	string electronicsDescription)
{
	/*
	ó������
	0. Rrequest�� ã�´�
	1. Rrequest�� R�� ����Ѵ�
	2. Rer���� RPoint�� �����Ѵ�
	3. ���ſϷḦ ǥ���Ѵ�

	�� ó������
	0. Rrequest�� ã�´�
	1] Rrequest�� ���� Area�� �Ҽ� SRea�� ã�Ƽ� Rrequest�� ã�´�
	1} SArea�� ã�´�
	2} Area�� ã�´�
	3} Rrequest�� ã�´�

	###############################################
	�ð��� �����Ƿ�, �켱�� RBuJa->FindArea�� Ȱ���ϱ�� �Ѵ�
	###############################################

	1. Rrequest�� R�� ����Ѵ�
	2. Rer���� RPoint�� �����Ѵ�
	3. ���ſϷḦ ǥ���Ѵ�
	1] RRequest�� ǥ���Ѵ�
	2] Picker�� ToDo���� �ش� ��ũ �����
	*/


	/*
	// 0.
	LinkedList<SArea>::Node* nodeLink = this->sAreas.LinearSearchUnique(&sAreaId, CompareSAreaIds);
	if (nodeLink != 0)
	{
	nodeLink->GetObject().find
	}
	//*/


	R *r = 0;
	// 0.
	Area *areaLink = this->FindArea(areaId);

	if (areaLink != 0)
	{
		RRequest *rRequestLink = areaLink->FindRRequestLink(rRequestId);
		if (rRequestLink != 0)
		{
			// 1.
			r = &(rRequestLink->RecordR(
				paperWeight,
				plasticWeight,
				glassBottleWeight,

				customGroupWeight,
				clothesWeight,
				steelWeight,
				wireWeight,

				stainlessWeight,
				copperWeight,
				electronics,

				electronicsDescription));

			// 2.
			SArea *sAreaLink = this->FindSArea(sAreaId);
			if (sAreaLink != 0)
			{
				RResource *rResourceLink = sAreaLink->GetRResourceLink();
				if (rResourceLink != 0)
				{
					RValue *rerRValue = rResourceLink->GetRerRValue();
					RValue *pickerRValue = rResourceLink->GetPickerRValue();

					rRequestLink->RecordRerRPointValue(r, rerRValue);
					rRequestLink->RecordPickerRPointValue(r, pickerRValue);

					rRequestLink->GetRerLink()->ReceiveRPointByRSelling(R�Ǹ�, rRequestLink->GetRerRPointValue(), "��Ȱ���Ǹ�");

					// 3.
					areaLink->pickerLink->PickUpComplete(rRequestLink);

				}
			}

		}
	}
	return r;
}
//*/


RValue* RBuJa::ModifyRerRValue(
	string rResourceId,

	Long paperValue,
	Long plasticValue,
	Long glassBottleValue,

	Long customGroupValue,

	Long clothesValue,
	Long steelValue,
	Long wireValue,

	Long stainlessValue,
	Long copperValue
	)
{
	// �ڿ��� ã�´�.
	RValue* rValueLink = 0;
	RResource* rResourceLink = this->controlRResourceLink->FindRResource(rResourceId);
	// ������ RValue�� �ּҸ� �����Ѵ�.
	RValue* oldRValueLink = rResourceLink->GetRerRValue();

	// ���� �����.
	rValueLink = rResourceLink->RecordRerRValue(
		paperValue,
		plasticValue,
		glassBottleValue,

		customGroupValue,

		clothesValue,
		steelValue,
		wireValue,

		stainlessValue,
		copperValue,

		oldRValueLink->GetCodes(),
		oldRValueLink->GetValues()
	);

	// ������ �� �Ҵ�����
	if (oldRValueLink != 0)
	{
		delete oldRValueLink;
	}

	return rValueLink;
}

RValue* RBuJa::ModifyPickerRValue(
	string rResourceId,

	Long paperValue,
	Long plasticValue,
	Long glassBottleValue,

	Long customGroupValue,

	Long clothesValue,
	Long steelValue,
	Long wireValue,

	Long stainlessValue,
	Long copperValue
	)
{
	RValue* rValueLink = 0;
	RResource* rResourceLink = this->controlRResourceLink->FindRResource(rResourceId);
	if (rResourceLink != 0)
	{
		// ������ RValue�� �ּҸ� �����Ѵ�.
		RValue* oldRValueLink = rResourceLink->GetPickerRValue();

		// ���� �����.
		rValueLink = rResourceLink->RecordPickerRValue(
			paperValue,
			plasticValue,
			glassBottleValue,

			customGroupValue,

			clothesValue,
			steelValue,
			wireValue,

			stainlessValue,
			copperValue,

			oldRValueLink->GetCodes(),
			oldRValueLink->GetValues()
			);

		// ������ �� �Ҵ�����
		if (oldRValueLink != 0)
		{
			delete oldRValueLink;
		}
	}

	return rValueLink;
}












void RBuJa::SaveRBuJa()
{
	this->SaveRer();
	this->SavePicker();
	this->SaveRResouce();
	this->SaveArea();
	this->SaveSArea();
}
void RBuJa::LoadRBuJa()
{
	this->LoadArea();
	this->LoadRer();
	this->LoadPicker();

	this->LoadRResource();
	this->LoadSArea();
	this->LoadRRequest();
}









void RBuJa::SaveRer()
{
	FILE *RerList;
	//FILE *RerRRequestIDList;
	RerList = _fsopen("RerList.txt", "wt", _SH_DENYNO);
	//RerRRequestIDList = _fsopen("RerRRequestIDList.txt", "wt", _SH_DENYNO);
	if (RerList != 0)// && RerRRequestIDList != 0)
	{
		BinaryTree<Rer>::Node* rerRootNodeLink = this->controlRerLink->GetRoot();
		SaveRerForBinary(rerRootNodeLink, RerList); //, RerRRequestIDList);
	}
	fclose(RerList);
	//fclose(RerRRequestIDList);
}
void RBuJa::SaveRerForBinary(BinaryTree<Rer>::Node* rerNodeLink, FILE *RerList)// , FILE *RerRRequestIDList)
{
	if (rerNodeLink != 0)
	{

		this->SaveRerForBinary(rerNodeLink->GetLeft(), RerList);// , RerRRequestIDList);

		char basicInfo[512];
		char areaIdAndSAreaId[128];
		char mergeInfo[1024];


		// �ʱ�ȭ
		memset(basicInfo, 0x00, sizeof(char)* 512);
		memset(areaIdAndSAreaId, 0x00, sizeof(char)* 128);
		memset(mergeInfo, 0x00, sizeof(char)* 1024);


		// basicInfo char�迭 �Է�
		sprintf_s(basicInfo, 512, "%s\t%s\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t", //"%s\t%s\t%s\t%s\t %s\t%s\t %d\t%d\t%d\t%d\t%d\t %d\t%d\t %d\t %s\t%s\t"
			rerNodeLink->GetKey().GetId().c_str(),
			rerNodeLink->GetKey().GetPw().c_str(),
			rerNodeLink->GetKey().GetName().c_str(),
			rerNodeLink->GetKey().GetPhone().c_str(),



			rerNodeLink->GetKey().GetAddressTotal().c_str(),
			rerNodeLink->GetKey().GetAddressId().c_str(),

			rerNodeLink->GetKey().GetJoinDate().GetYear(),
			rerNodeLink->GetKey().GetJoinDate().GetMonth(),
			rerNodeLink->GetKey().GetJoinDate().GetDay(),
			rerNodeLink->GetKey().GetJoinDate().GetWeekDay(),
			rerNodeLink->GetKey().GetJoinDate().GetHour(),
			rerNodeLink->GetKey().GetJoinDate().GetMin(),
			rerNodeLink->GetKey().GetJoinDate().GetSec(),

			rerNodeLink->GetKey().GetRPoint()->GetLength(), // ForRTransactionsOfRPoint
			rerNodeLink->GetKey().GetRPoint()->GetRPointValue()
			); // ForRRequestLink //*/


		// areaIdAndSAreaId char�迭 �Է�
		if (rerNodeLink->GetKey().GetAreaLink() != 0)
		{
			sprintf_s(areaIdAndSAreaId, 128, "%s\n",
				rerNodeLink->GetKey().GetAreaLink()->GetId().c_str()); // AreaId
		}
		else
		{
			sprintf_s(areaIdAndSAreaId, 128, "%s\n",
				"default"); // AreaId
		}


		// mergeInf 
		strcat_s(mergeInfo, basicInfo);
		strcat_s(mergeInfo, areaIdAndSAreaId);

		// 1�� ��� // basicInfo, areaIdAndSAreaId ���
		fwrite(mergeInfo, strlen(mergeInfo), 1, RerList); // strlen ���ڿ� ���̸� ���ϴ� �Լ�
		//*/



		// 2�� ��� // rTransactionInfo ���
		char rTransactionInfo[128];
		RTransaction *rTransactionLink = rerNodeLink->GetKey().GetRPoint()->FirstForRTransactionLink();
		for (Long i = 0; i < rerNodeLink->GetKey().GetRPoint()->GetLength(); i++)
		{
			// �ʱ�ȭ
			memset(rTransactionInfo, 0x00, sizeof(char)* 128);
			sprintf_s(rTransactionInfo, 128, "%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\n",
				rTransactionLink->GetRTransactionType(), // @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ �̰� ���ڷ� �� ����Ǵ��� �𸣰ڴ�

				rTransactionLink->GetOccurredDate().GetYear(),
				rTransactionLink->GetOccurredDate().GetMonth(),
				rTransactionLink->GetOccurredDate().GetDay(),
				rTransactionLink->GetOccurredDate().GetWeekDay(),
				rTransactionLink->GetOccurredDate().GetHour(),
				rTransactionLink->GetOccurredDate().GetMin(),
				rTransactionLink->GetOccurredDate().GetSec(),

				rTransactionLink->GetRPointValue(),
				rTransactionLink->GetDescription().c_str()
				);
			fwrite(rTransactionInfo, strlen(rTransactionInfo), 1, RerList);
			rTransactionLink = rerNodeLink->GetKey().GetRPoint()->NextForRTransactionLink();
		}





		// 3�� ��� // rRequestId ���
		/*
		��ϸ��
		1. RerID, Length
		2. RRequest
		*/
		/*
		char rerIdAndLength[128];
		memset(rerIdAndLength, 0x00, sizeof(char)* 128);
		sprintf_s(rerIdAndLength, 128, "%s\t%d\n", rerNodeLink->GetKey().GetId().c_str(), rerNodeLink->GetKey().GetLength());
		fwrite(rerIdAndLength, strlen(rerIdAndLength), 1, RerRRequestIDList);

		char rRequestId[128];
		RRequest *rRequestLink = rerNodeLink->GetKey().FirstForRRequestLink();
		for(Long i = 0; i < rerNodeLink->GetKey().GetLength(); i++)
		{
		// �ʱ�ȭ
		memset(rRequestId, 0x00, sizeof(char)* 128);
		sprintf_s(rRequestId, 128, "%s\n", rRequestLink->GetId().c_str());

		fwrite(rRequestId, strlen(rRequestId), 1, RerRRequestIDList); // strlen ���ڿ� ���̸� ���ϴ� �Լ�
		rRequestLink = rerNodeLink->GetKey().NextForRRequestLink();
		}
		//*/


		this->SaveRerForBinary(rerNodeLink->GetRight(), RerList);// , RerRRequestIDList);
	}

}

/*
dat ����
void RBuJa::SaveRer()
{
FILE *file;
file = fopen("RerList", "wb");
if (file != 0)
{
BinaryTree<Rer>::Node* rerRootNodeLink = this->controlRerLink->GetRoot();
SaveRerForBinary(rerRootNodeLink, file);
}
fclose(file);
}
void RBuJa::SaveRerForBinary(BinaryTree<Rer>::Node* rerNodeLink, FILE *file)
{
if (rerNodeLink != 0)
{
this->SaveRerForBinary(rerNodeLink->GetLeft(), file);

char basicInfo[512] = { 0, };
char areaIdAndSAreaId[128] = { 0, };
char rTransactionInfo[128] = { 0. };
char rRequestId[128] = { 0, };
char mergeInfo[1024] = { 0, };
// basicInfo
sprintf(basicInfo, "%s\t%s\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t", //"%s\t%s\t%s\t%s\t %s\t%s\t %d\t%d\t%d\t%d\t%d\t %d\t%d\t %d\t %s\t%s\t"
rerNodeLink->GetKey().GetId(),
rerNodeLink->GetKey().GetPw(),
rerNodeLink->GetKey().GetName(),
rerNodeLink->GetKey().GetPhone(),

rerNodeLink->GetKey().GetAddressTotal(),
rerNodeLink->GetKey().GetAddressId(),

rerNodeLink->GetKey().GetJoinDate().GetYear(),
rerNodeLink->GetKey().GetJoinDate().GetMonth(),
rerNodeLink->GetKey().GetJoinDate().GetDay(),
rerNodeLink->GetKey().GetJoinDate().GetHour(),
rerNodeLink->GetKey().GetJoinDate().GetMin(),

rerNodeLink->GetKey().GetRPoint()->GetLength(), // ForRTransactionsOfRPoint
rerNodeLink->GetKey().GetRPoint()->GetRPointValue(),

rerNodeLink->GetKey().GetLength() // ForRRequestLink
);

// areaIdAndSAreaId
sprintf(areaIdAndSAreaId, "%s\t%s\t",
rerNodeLink->GetKey().GetAreaLink()->GetId(), // AreaId
rerNodeLink->GetKey().GetAreaLink()->GetSAreaLink()->GetId() // SAreaId
);

// mergeInf
strcat(mergeInfo, basicInfo);
strcat(mergeInfo, areaIdAndSAreaId);

// 1�� ��� // basicInfo, areaIdAndSAreaId ���
fwrite(mergeInfo, strlen(mergeInfo), 1, file); // strlen ���ڿ� ���̸� ���ϴ� �Լ�


LinkedList<RTransaction>::Node* rTransactionNodeLink = rerNodeLink->GetKey().GetRPoint()->GetHead();
for (Long i = 0; i<rerNodeLink->GetKey().GetRPoint()->GetLength(); i++)
{
sprintf(rTransactionInfo, "%d\\%d\\%d\\%d\\%d\\%d\\%d\\%s\\\n",
rTransactionNodeLink->GetObject().GetRTransactionType(),
rTransactionNodeLink->GetObject().GetOccurredDate().GetYear(),
rTransactionNodeLink->GetObject().GetOccurredDate().GetMonth(),
rTransactionNodeLink->GetObject().GetOccurredDate().GetDay(),
rTransactionNodeLink->GetObject().GetOccurredDate().GetHour(),
rTransactionNodeLink->GetObject().GetOccurredDate().GetMin(),
rTransactionNodeLink->GetObject().GetRPointValue(),
rTransactionNodeLink->GetObject().GetDescription()
);

}

//	rerNodeLink->GetKey().GetRPoint()->GetLength(),

this->SaveRerForBinary(rerNodeLink->GetRight(), file);
}

}
//*/

void RBuJa::SavePicker()
{
	FILE *PickerList;
	//FILE *PickerRRequestToDoIDList;
	PickerList = _fsopen("PickerList.txt", "wt", _SH_DENYNO);
	//PickerRRequestToDoIDList = _fsopen("PickerRRequestToDoIDList.txt", "wt", _SH_DENYNO);
	if (PickerList != 0)// && PickerRRequestToDoIDList != 0)
	{
		BinaryTree<Picker>::Node* pickerRootNodeLink = this->controlPickerLink->GetRoot();

		SavePickerForBinary(pickerRootNodeLink, PickerList);// , PickerRRequestToDoIDList);
	}
	fclose(PickerList);
	//fclose(PickerRRequestToDoIDList);
}

void RBuJa::SavePickerForBinary(BinaryTree<Picker>::Node* pickerNodeLink, FILE *PickerList)//, FILE *PickerRRequestToDoIDList)//, FILE *PickerRRequestIDList);
{
	if (pickerNodeLink != 0)
	{
		this->SavePickerForBinary(pickerNodeLink->GetLeft(), PickerList);// , PickerRRequestToDoIDList);

		char basicInfo[512];





		// �ʱ�ȭ
		memset(basicInfo, 0x00, sizeof(char)* 512);




		// basicInfo char�迭 �Է�
		sprintf_s(basicInfo, 512, "%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n", //"%s\t%s\t%s\t%s\t %s\t%s\t %d\t%d\t%d\t%d\t%d\t %d\t%d\t %d\t %s\t%s\t"
			pickerNodeLink->GetKey().GetId().c_str(),
			pickerNodeLink->GetKey().GetPw().c_str(),
			pickerNodeLink->GetKey().GetName().c_str(),
			pickerNodeLink->GetKey().GetPhone().c_str(),

			pickerNodeLink->GetKey().GetJoinDate().GetYear(),
			pickerNodeLink->GetKey().GetJoinDate().GetMonth(),
			pickerNodeLink->GetKey().GetJoinDate().GetDay(),
			pickerNodeLink->GetKey().GetJoinDate().GetWeekDay(),
			pickerNodeLink->GetKey().GetJoinDate().GetHour(),
			pickerNodeLink->GetKey().GetJoinDate().GetMin(),
			pickerNodeLink->GetKey().GetJoinDate().GetSec(),

			pickerNodeLink->GetKey().GetRPoint()->GetLength(), // ForRTransactionsOfRPoint
			pickerNodeLink->GetKey().GetRPoint()->GetRPointValue(),

			pickerNodeLink->GetKey().GetLengthForAreaLinks()
			); // ForRRequestLink //*/


		// 1�� ��� // basicInfo, rResourceId ���
		fwrite(basicInfo, strlen(basicInfo), 1, PickerList); // strlen ���ڿ� ���̸� ���ϴ� �Լ�
		//*/




		// 2�� ��� // rTransactionInfo ���
		char rTransactionInfo[128];
		RTransaction *rTransactionLink = pickerNodeLink->GetKey().GetRPoint()->FirstForRTransactionLink();
		for (Long i = 0; i<pickerNodeLink->GetKey().GetRPoint()->GetLength(); i++)
		{
			// �ʱ�ȭ
			memset(rTransactionInfo, 0x00, sizeof(char)* 128);
			sprintf_s(rTransactionInfo, 128, "%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\n",
				rTransactionLink->GetRTransactionType(), // @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ �̰� ���ڷ� �� ����Ǵ��� �𸣰ڴ�

				rTransactionLink->GetOccurredDate().GetYear(),
				rTransactionLink->GetOccurredDate().GetMonth(),
				rTransactionLink->GetOccurredDate().GetDay(),

				rTransactionLink->GetOccurredDate().GetWeekDay(),
				rTransactionLink->GetOccurredDate().GetHour(),
				rTransactionLink->GetOccurredDate().GetMin(),
				rTransactionLink->GetOccurredDate().GetSec(),


				rTransactionLink->GetRPointValue(),
				rTransactionLink->GetDescription().c_str()
				);
			fwrite(rTransactionInfo, strlen(rTransactionInfo), 1, PickerList);
			rTransactionLink = pickerNodeLink->GetKey().GetRPoint()->NextForRTransactionLink();
		}





		// 3�� ��� // rRequestIdForToDo ��� // PickerRRequestToDoIDList.txt
		/*
		��ϸ��
		1. PikcerID, LengthForToDo
		2. RRequest
		*/
		/*
		char pickerIdAndLengthForToDo[128];
		memset(pickerIdAndLengthForToDo, 0x00, sizeof(char)* 128);
		sprintf_s(pickerIdAndLengthForToDo, 128, "%s\t%d\n", pickerNodeLink->GetKey().GetId().c_str(), pickerNodeLink->GetKey().GetLengthForToDo());
		fwrite(pickerIdAndLengthForToDo, strlen(pickerIdAndLengthForToDo), 1, PickerRRequestToDoIDList);


		char rRequestIdForToDo[128];
		RRequest *rRequestToDoLink = pickerNodeLink->GetKey().FirstForRRequestToDoLink();
		for (Long i = 0; i < pickerNodeLink->GetKey().GetLengthForToDo(); i++)
		{
		// �ʱ�ȭ
		memset(rRequestIdForToDo, 0x00, sizeof(char)* 128);
		sprintf_s(rRequestIdForToDo, 128, "%s\n", rRequestToDoLink->GetId().c_str());

		fwrite(rRequestIdForToDo, strlen(rRequestIdForToDo), 1, PickerRRequestToDoIDList); // strlen ���ڿ� ���̸� ���ϴ� �Լ�
		rRequestToDoLink = pickerNodeLink->GetKey().NextForRRequestToDoLink();
		}

		//*/



		// 4�� ��� // ��� areaId�� ���
		char areaId[128];
		Area* areaLink = pickerNodeLink->GetKey().AreaLinkFirst();
		for (Long i = 0; i < pickerNodeLink->GetKey().GetLengthForAreaLinks(); i++)
		{
			// �ʱ�ȭ
			memset(areaId, 0x00, sizeof(char)* 128);
			sprintf_s(areaId, 128, "%s\n", areaLink->GetId().c_str());

			fwrite(areaId, strlen(areaId), 1, PickerList); // strlen ���ڿ� ���̸� ���ϴ� �Լ�
			areaLink = pickerNodeLink->GetKey().AreaLinkNext();
		}


		this->SavePickerForBinary(pickerNodeLink->GetRight(), PickerList);// , PickerRRequestToDoIDList);
	}



}//*/


void RBuJa::SaveRResouce()
{
	FILE *file;

	file = _fsopen("RResourceList.txt", "wt", _SH_DENYNO);
	if (file != 0) {
		RResource *rResource;
		Date joinDate;
		RValue *rerRValue;
		RValue *pickeRValue;
		SArea *sAreaLink;
		//		string sAreaId;

		Long lengthForRerElectronics;
		Long lengthForPickerElectronics;

		rResource = this->controlRResourceLink->First();
		for (int i = 0; i < this->controlRResourceLink->GetLength(); i++)
		{

			joinDate = rResource->GetJoinDate();
			rerRValue = rResource->GetRerRValue();
			pickeRValue = rResource->GetPickerRValue();
			sAreaLink = rResource->GetSAreaLink();

			lengthForRerElectronics = rerRValue->GetLength();
			lengthForPickerElectronics = pickeRValue->GetLength();

			/*
			if (sAreaLink != 0)
			{
			sAreaId = sAreaLink->GetId();
			}
			else
			{
			sAreaId = "";
			}
			//*/


			fprintf(file, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
				rResource->GetId().c_str(),
				rResource->GetPw().c_str(),

				rResource->GetCompanyName().c_str(),
				rResource->GetCompanyTelephone().c_str(),

				rResource->GetCEOName().c_str(),
				rResource->GetCEOPhone().c_str(), // 6

				rResource->GetAddressTotal().c_str(),
				rResource->GetAddressId().c_str(), // 8

				joinDate.GetYear(),
				joinDate.GetMonth(),
				joinDate.GetDay(),
				joinDate.GetWeekDay(),
				joinDate.GetHour(),
				joinDate.GetMin(),
				joinDate.GetSec(), // 15



				rerRValue->GetPaperValue(),
				rerRValue->GetPlasticValue(),
				rerRValue->GetGlassBottleValue(),
				rerRValue->GetCustomGroupValue(),

				rerRValue->GetClothesValue(),
				rerRValue->GetSteelValue(),
				rerRValue->GetWireValue(), // 22

				rerRValue->GetStainlessValue(),
				rerRValue->GetCopperValue(), // 24



				pickeRValue->GetPaperValue(),
				pickeRValue->GetPlasticValue(),
				pickeRValue->GetGlassBottleValue(),
				pickeRValue->GetCustomGroupValue(),

				pickeRValue->GetClothesValue(),
				pickeRValue->GetSteelValue(),
				pickeRValue->GetWireValue(), // 31

				pickeRValue->GetStainlessValue(),
				pickeRValue->GetCopperValue(), // 33

				lengthForRerElectronics,
				lengthForPickerElectronics // 35
				);
			//sAreaId.c_str());


			// ������ǰ �ü� ����

			/*
			ó������
			1. ������ǰ �ü��� ������ ���Ѵ�
			2. ������ǰ �ü��� ������ŭ �ݺ��Ѵ�
			2.1. ������ǰ �ü��� �����Ѵ�
			3. ������
			*/

			string code;
			Long value;

			// ȸ���� ������ǰ �ü� ����
			for (Long j = 0; j < lengthForRerElectronics; j++)
			{
				rerRValue->GetElectronicsCodeAndValue(j, code, value);
				fprintf(file, "%s\t%d\n",
					code.c_str(),
					value
					);
			}


			for (Long k = 0; k < lengthForPickerElectronics; k++)
			{

				pickeRValue->GetElectronicsCodeAndValue(k, code, value);
				fprintf(file, "%s\t%d\n",
					code.c_str(),
					value
					);
			}




			rResource = this->controlRResourceLink->Next();
		}

		fclose(file);
	}
}

void RBuJa::SaveArea()
{
	FILE *AreaList;
	FILE *RRequestList;
	AreaList = _fsopen("AreaList.txt", "wt", _SH_DENYNO);
	RRequestList = _fsopen("RRequestList.txt", "wt", _SH_DENYNO);
	if (AreaList != 0 && RRequestList != 0)
	{
		BinaryTree<Area>::Node* areaRootNodeLink = this->areaListLink->GetRootNode();
		SaveAreaForBinary(areaRootNodeLink, AreaList, RRequestList);
	}
	fclose(AreaList);
	fclose(RRequestList);
}

void RBuJa::SaveAreaForBinary(BinaryTree<Area>::Node* areaNodeLink, FILE *AreaList, FILE *RRequestList)
{
	if (areaNodeLink != 0)
	{
		this->SaveAreaForBinary(areaNodeLink->GetLeft(), AreaList, RRequestList);


		// 1�� ��� // areaId
		char areaId[128];
		memset(areaId, 0x00, sizeof(char)* 128); // �ʱ�ȭ
		sprintf_s(areaId, 128, "%s\n", areaNodeLink->GetKey().GetId().c_str());
		fwrite(areaId, strlen(areaId), 1, AreaList); // strlen ���ڿ� ���̸� ���ϴ� �Լ�

		// 2�� ��� // RRequest
		this->SaveRRequest(areaNodeLink, RRequestList);

		this->SaveAreaForBinary(areaNodeLink->GetRight(), AreaList, RRequestList);
	}
}

void RBuJa::SaveRRequest(BinaryTree<Area>::Node* areaNodeLink, FILE *RRequestList)
{
	// 2�� ��� // RRequest
	char areaIdAndLength[128];
	memset(areaIdAndLength, 0x00, sizeof(char)* 128); // �ʱ�ȭ
	sprintf_s(areaIdAndLength, 128, "%s\t%d\n", areaNodeLink->GetKey().GetId().c_str(), areaNodeLink->GetKey().GetLengthForRRequests());
	fwrite(areaIdAndLength, strlen(areaIdAndLength), 1, RRequestList); // strlen ���ڿ� ���̸� ���ϴ� �Լ�

	char rRequestInfo[1024];
	Long isCancelledInt;
	Long isTakenByPickerInt;


	string rerId;
	string pickerId;

	RRequest *rRequestLink = areaNodeLink->GetKey().FirstForRRequest();
	for (Long i = 0; i < areaNodeLink->GetKey().GetLengthForRRequests(); i++)
	{
		/*
		string rRequestId // 40

		Long RType  // 10
		Long PickUpType

		bool isCanceled -> int  // 10
		bool isTakenByPicker -> int

		Date rerPickUpDate  // 20
		Date pickerPickUpDate
		Date rerRequestDate

		Long rerRPointValue // 30
		Long pickerRPointValue // 30 -----

		//R����
		Long paperWeight; // 10
		Long canWeight;  // 10
		Long glassWeight; // 10

		Long plasticWeight; // 10
		Long clothesWeight; // 10
		Long etcWeight; // ����	  // 10

		Long totalWeight; // 10
		Long rerRPoint;  // 10
		Long pickerRPoint; // 10

		string electronics; // 64
		string electronicsDescription; // 256
		*/
		memset(rRequestInfo, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
		if (rRequestLink->GetIsCancelled() == true)
		{
			isCancelledInt = 1;
		}
		else
		{
			isCancelledInt = 0;
		}

		if (rRequestLink->GetIsTakenByPicker() == true)
		{
			isTakenByPickerInt = 1;
		}
		else
		{
			isTakenByPickerInt = 0;
		}



		if (rRequestLink->rerLink != 0)
		{
			rerId = rRequestLink->rerLink->GetId();
		}
		else
		{
			rerId = "";
		}



		if (rRequestLink->pickerLink != 0)
		{
			pickerId = rRequestLink->pickerLink->GetId();
		}
		else
		{
			pickerId = "";
		}


		sprintf_s(rRequestInfo, 1024,
			"%s\t%d\t%d\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%s\n",
			rRequestLink->GetId().c_str(),

			rRequestLink->GetRType(),
			rRequestLink->GetPickUpType(), // 3

			rerId.c_str(),
			pickerId.c_str(), // 5


			isCancelledInt,
			isTakenByPickerInt, // 7

			rRequestLink->GetRerPickUpDate().GetYear(),
			rRequestLink->GetRerPickUpDate().GetMonth(),
			rRequestLink->GetRerPickUpDate().GetDay(),
			rRequestLink->GetRerPickUpDate().GetWeekDay(),
			rRequestLink->GetRerPickUpDate().GetHour(),
			rRequestLink->GetRerPickUpDate().GetMin(),
			rRequestLink->GetRerPickUpDate().GetSec(), // 14

			rRequestLink->GetPickerPickUpDate().GetYear(),
			rRequestLink->GetPickerPickUpDate().GetMonth(),
			rRequestLink->GetPickerPickUpDate().GetDay(),
			rRequestLink->GetPickerPickUpDate().GetWeekDay(),
			rRequestLink->GetPickerPickUpDate().GetHour(),
			rRequestLink->GetPickerPickUpDate().GetMin(),
			rRequestLink->GetPickerPickUpDate().GetSec(), // 21

			rRequestLink->GetRerRequestDate().GetYear(),
			rRequestLink->GetRerRequestDate().GetMonth(),
			rRequestLink->GetRerRequestDate().GetDay(),
			rRequestLink->GetRerRequestDate().GetWeekDay(),
			rRequestLink->GetRerRequestDate().GetHour(),
			rRequestLink->GetRerRequestDate().GetMin(),
			rRequestLink->GetRerRequestDate().GetSec(), // 28

			rRequestLink->GetRerRPointValue(),
			rRequestLink->GetPickerRPointValue(), // 30

			rRequestLink->GetR().GetPaperWeight(),
			rRequestLink->GetR().GetPlasticWeight(),
			rRequestLink->GetR().GetGlassBottleWeight(),
			rRequestLink->GetR().GetCustomGroupWeight(), // 34

			rRequestLink->GetR().GetClothesWeight(),
			rRequestLink->GetR().GetSteelWeight(),
			rRequestLink->GetR().GetWireWeight(), // 37

			rRequestLink->GetR().GetStainlessWeight(),
			rRequestLink->GetR().GetCopperWeight(), // 39


			rRequestLink->GetR().GetTotalWeight(), // 40


			rRequestLink->GetR().GetElectronics().c_str(),
			rRequestLink->GetR().GetElectronicsDescription().c_str()); // 42

		fwrite(rRequestInfo, strlen(rRequestInfo), 1, RRequestList); // strlen ���ڿ� ���̸� ���ϴ� �Լ�
		rRequestLink = areaNodeLink->GetKey().NextForRRequest();

	}
}


void RBuJa::SaveSArea()
{
	FILE *SAreaList;
	Long count = 0;

	SAreaList = _fsopen("SAreaList.txt", "wt", _SH_DENYNO);
	if (SAreaList != 0)
	{
		SArea *sAreaLink = this->SAreaFirst();
		for (int i = 0; i < this->length; i++)
		{
			/*
			��� ���
			sAreaLink->GetId().c_str()
			sAreaLink->GetRResourceLink()->GetId().c_str()
			sAreaLink->GetLengthForPickerLinkList()
			sAreaLink->GetLength()
			*/

			// 1�� ��� // sAreaId, rResourceId
			char basicInfo[256];
			memset(basicInfo, 0x00, sizeof(char)* 256); // �ʱ�ȭ
			if (sAreaLink->GetRResourceLink() != 0)
			{
				sprintf_s(basicInfo, 256, "%s\t%s\t%d\t%d\n", sAreaLink->GetId().c_str(), sAreaLink->GetRResourceLink()->GetId().c_str(), sAreaLink->GetLengthForPickerLinkList(), sAreaLink->GetLengthForAreaLinkList());
			}
			else
			{
				sprintf_s(basicInfo, 256, "%s\t%s\t%d\t%d\n", sAreaLink->GetId().c_str(), "default", sAreaLink->GetLengthForPickerLinkList(), sAreaLink->GetLengthForAreaLinkList());

			}
			fwrite(basicInfo, strlen(basicInfo), 1, SAreaList); // strlen ���ڿ� ���̸� ���ϴ� �Լ�


			// 2�� ��� // PickerIdList



			Picker *pickerLink = sAreaLink->FirstForPickerLink();
			char pickerId[64];
			for (int i = 0; i < sAreaLink->GetLengthForPickerLinkList(); i++)
			{
				memset(pickerId, 0x00, sizeof(char)* 64);
				sprintf_s(pickerId, 64, "%s\n", pickerLink->GetId().c_str());
				fwrite(pickerId, strlen(pickerId), 1, SAreaList); // strlen ���ڿ� ���̸� ���ϴ� �Լ�

				pickerLink = sAreaLink->NextForPickerLink();
			}

			// 3�� ��� // AreaList

			Area *areaLink = sAreaLink->First();

			char areaId[64];
			for (int i = 0; i < sAreaLink->GetLengthForAreaLinkList(); i++)
			{
				memset(areaId, 0x00, sizeof(char)* 64);
				sprintf_s(areaId, 64, "%s\n", areaLink->GetId().c_str());
				fwrite(areaId, strlen(areaId), 1, SAreaList); // strlen ���ڿ� ���̸� ���ϴ� �Լ�

				areaLink = sAreaLink->Next();
			}

			sAreaLink = this->SAreaNext();
		}
		fclose(SAreaList);
	}
}


/*
AreaList�� ��ϵ�
areaId�� �о
AreaList�� �ܴ�
*/
void RBuJa::LoadArea()
{
	FILE *AreaList;
	Long count = 0;

	AreaList = _fsopen("AreaList.txt", "rt", _SH_DENYNO);
	if (AreaList != 0)
	{
		char line[128];
		char temp[128];
		memset(line, 0x00, sizeof(char)* 128); // �ʱ�ȭ
		fgets(line, 1024, AreaList); // ���� �б�

		while (!feof(AreaList))
		{
			memset(temp, 0x00, sizeof(char)* 128);
			Long i = 0;
			while (line[i] != '\n')
			{
				temp[i] = line[i];
				i++;
			}

			string areaId(temp);
			this->areaListLink->RecordArea(areaId);

			memset(line, 0x00, sizeof(char)* 128); // �ʱ�ȭ
			fgets(line, 1024, AreaList);
		}
	}
}

void RBuJa::LoadRer()
{
	/*
	ó������
	1. ������ ���� �ƴϸ� ��� �ݺ��Ѵ�
	1.1. �� ���� �д´�
	1.2. Rer�� ����Ѵ�
	1.3. Rer�� rTransaction's Length��ŭ �ݺ��Ѵ�
	1.3.1. �� ���� �д´�
	1.3.2. rTransaction�� ����Ѵ�
	2. ������
	*/


	FILE *RerList;
	Long count = 0;

	RerList = _fsopen("RerList.txt", "rt", _SH_DENYNO);
	if (RerList != 0)
	{
		string id;
		string pw;
		string name;
		string phone;

		string addressTotal;
		string addressId;

		Long year;
		Long month;
		Long day;
		Long weekDay;
		Long hour;
		Long min;
		Long sec;

		Long LengthForRPointTransaction;
		Long rPointValue;

		string areaId;

		stringstream str; // chart to int �� ���� �ڵ�����
		Long i;
		Long j;

		char line[1024];
		memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
		fgets(line, 1024, RerList); // ���� �б�

		char temp[1024];
		Long count;

		while (!feof(RerList))
		{
			i = 0;
			count = 1;
			while (count <= 16)
			{
				memset(temp, 0x00, sizeof(char)* 1024);

				j = 0;

				while (line[i] != '\t' && line[i] != '\n')
				{
					temp[j] = line[i];
					j++;
					i++;
				}
				i++;
				switch (count)
				{
				case 1: id = temp; break;
				case 2: pw = temp; break;
				case 3: name = temp; break;
				case 4: phone = temp; break;


				case 5: addressTotal = temp; break;
				case 6: addressId = temp; break;



				case 7:
					str.clear();
					str << temp;
					str >> year; break;
				case 8:
					str.clear();
					str << temp;
					str >> month; break;
				case 9:
					str.clear();
					str << temp;
					str >> day; break;
				case 10:
					str.clear();
					str << temp;
					str >> weekDay; break;
				case 11:
					str.clear();
					str << temp;
					str >> hour; break;
				case 12:
					str.clear();
					str << temp;
					str >> min; break;
				case 13:
					str.clear();
					str << temp;
					str >> sec; break;



				case 14:
					str.clear();
					str << temp;
					str >> LengthForRPointTransaction; break;
				case 15:
					str.clear();
					str << temp;
					str >> rPointValue; break;



				case 16: areaId = temp; break;

				default: break;
				}
				count++;
			}


			// Rer ���
			Area* areaLink = this->FindArea(areaId);
			Rer* rerLink = this->RegisterNewRer(id, pw, name, phone, addressTotal, addressId, year, month, day, weekDay, hour, min, sec, areaLink);
			if (areaLink != 0 && rerLink != 0)
			{
				areaLink->RegisterRerLink(rerLink);
			}






			// rTransaction ���

			Long rTransactionType;
			Long rPointValue;
			string description;

			Long m;
			for (Long k = 0; k < LengthForRPointTransaction; k++)
			{
				memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
				fgets(line, 1024, RerList); // ���� �б�


				m = 0;
				Long count = 1;
				while (count <= 10)
				{
					memset(temp, 0x00, sizeof(char)* 1024);
					Long n = 0;
					while (line[m] != '\t' && line[m] != '\n')
					{
						temp[n] = line[m];
						n++;
						m++;
					}
					m++;
					switch (count)
					{
					case 1:
						str.clear();
						str << temp;
						str >> rTransactionType; break;

					case 2:
						str.clear();
						str << temp;
						str >> year; break;
					case 3:
						str.clear();
						str << temp;
						str >> month; break;
					case 4:
						str.clear();
						str << temp;
						str >> day; break;
					case 5:
						str.clear();
						str << temp;
						str >> weekDay; break;
					case 6:
						str.clear();
						str << temp;
						str >> hour; break;
					case 7:
						str.clear();
						str << temp;
						str >> min; break;
					case 8:
						str.clear();
						str << temp;
						str >> sec; break;
					case 9:
						str.clear();
						str << temp;
						str >> rPointValue; break;

					case 10: description = temp; break;

					default: break;

					}
					count++;
				}
				RTransaction rTransaction(rTransactionType, rPointValue, description, year, month, day, weekDay, hour, min, sec);
				rerLink->GetRPoint()->RecordRTransaction(rTransaction);
			}

			memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
			fgets(line, 1024, RerList);
		}


	}

}
//*/

void RBuJa::LoadPicker()
{
	FILE *PickerList;
	Long count = 0;

	PickerList = _fsopen("PickerList.txt", "rt", _SH_DENYNO);
	if (PickerList != 0)
	{
		string id;
		string pw;
		string name;
		string phone;

		Long year;
		Long month;
		Long day;
		Long weekDay;
		Long hour;
		Long min;
		Long sec;

		Long LengthForRPointTransaction;
		Long rPointValue;

		Long LengthForAreas;


		stringstream str; // chart to int �� ���� �ڵ�����
		Long i;
		Long j;

		char line[1024];
		memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
		fgets(line, 1024, PickerList); // ���� �б�

		char temp[1024];
		Long count;

		while (!feof(PickerList))
		{
			i = 0;
			count = 1;
			while (count <= 14)
			{
				memset(temp, 0x00, sizeof(char)* 1024);

				j = 0;

				while (line[i] != '\t' && line[i] != '\n')
				{
					temp[j] = line[i];
					j++;
					i++;
				}
				i++;
				switch (count)
				{
				case 1: id = temp; break;
				case 2: pw = temp; break;
				case 3: name = temp; break;
				case 4: phone = temp; break;



				case 5:
					str.clear();
					str << temp;
					str >> year; break;
				case 6:
					str.clear();
					str << temp;
					str >> month; break;
				case 7:
					str.clear();
					str << temp;
					str >> day; break;
				case 8:
					str.clear();
					str << temp;
					str >> weekDay; break;
				case 9:
					str.clear();
					str << temp;
					str >> hour; break;
				case 10:
					str.clear();
					str << temp;
					str >> min; break;
				case 11:
					str.clear();
					str << temp;
					str >> sec; break;



				case 12:
					str.clear();
					str << temp;
					str >> LengthForRPointTransaction; break;
				case 13:
					str.clear();
					str << temp;
					str >> rPointValue; break;

				case 14:
					str.clear();
					str << temp;
					str >> LengthForAreas; break;

				default: break;
				}
				count++;
			}


			// Picker ���
			Picker *picker = this->RegisterNewPicker(id, pw, name, phone, year, month, day, weekDay, hour, min, sec);







			// rTransaction ���

			Long rTransactionType;
			Long rPointValue;
			string description;

			Long m;
			for (Long k = 0; k < LengthForRPointTransaction; k++)
			{
				memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
				fgets(line, 1024, PickerList); // ���� �б�


				m = 0;
				Long count = 1;
				while (count <= 10)
				{
					memset(temp, 0x00, sizeof(char)* 1024);
					Long n = 0;
					while (line[m] != '\t' && line[m] != '\n')
					{
						temp[n] = line[m];
						n++;
						m++;
					}
					m++;
					switch (count)
					{
					case 1:
						str.clear();
						str << temp;
						str >> rTransactionType; break;

					case 2:
						str.clear();
						str << temp;
						str >> year; break;
					case 3:
						str.clear();
						str << temp;
						str >> month; break;
					case 4:
						str.clear();
						str << temp;
						str >> day; break;
					case 5:
						str.clear();
						str << temp;
						str >> weekDay; break;
					case 6:
						str.clear();
						str << temp;
						str >> hour; break;
					case 7:
						str.clear();
						str << temp;
						str >> min; break;
					case 8:
						str.clear();
						str << temp;
						str >> sec; break;
					case 9:
						str.clear();
						str << temp;
						str >> rPointValue; break;

					case 10: description = temp; break;

					default: break;

					}
					count++;
				}
				RTransaction rTransaction(rTransactionType, rPointValue, description, year, month, day, weekDay, hour, min, sec);
				picker->GetRPoint()->RecordRTransaction(rTransaction);
			}





			// ��� areas ���

			string areaId;
			Long o;
			for (Long k = 0; k < LengthForAreas; k++)
			{
				memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
				fgets(line, 1024, PickerList); // ���� �б�

				o = 0;
				Long count = 1;
				while (count <= 1)
				{
					memset(temp, 0x00, sizeof(char)* 1024);
					Long p = 0;
					while (line[o] != '\n')
					{
						temp[p] = line[o];
						p++;
						o++;
					}
					o++;
					switch (count)
					{
					case 1:
						areaId = temp; break;

					default: break;
					}
					count++;
				}
				this->LinkPickerAndArea(picker->GetId(), areaId);
			}

			memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
			fgets(line, 1024, PickerList);
		}
	}

}

void RBuJa::LoadRResource()
{
	FILE *RResourceList;
	Long count = 0;

	RResourceList = _fsopen("RResourceList.txt", "rt", _SH_DENYNO);
	if (RResourceList != 0)
	{
		string id;
		string pw;

		string companyName;
		string companyTelephone;

		string CEOName;
		string CEOPhone;


		string addressTotal;
		string addressId;

		Long year;
		Long month;
		Long day;
		Long weekDay;
		Long hour;
		Long min;
		Long sec;

		Long paperValueForRer;
		Long plasticValueForRer;
		Long glassBottleValueForRer;
		Long customGroupValueForRer;

		Long clothesValueForRer;
		Long steelValueForRer;
		Long wireValueForRer;

		Long stainlessValueForRer;
		Long copperValueForRer;


		Long paperValueForPicker;
		Long plasticValueForPicker;
		Long glassBottleValueForPicker;
		Long customGroupValueForPicker;

		Long clothesValueForPicker;
		Long steelValueForPicker;
		Long wireValueForPicker;

		Long stainlessValueForPicker;
		Long copperValueForPicker;

		Long lengthForRerElectronics;
		Long lengthForPickerElectronics;

		stringstream str; // chart to int �� ���� �ڵ�����
		Long i;
		Long j;

		char line[1024];
		memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
		fgets(line, 1024, RResourceList); // ���� �б�

		char temp[1024];
		Long count;

		while (!feof(RResourceList))
		{
			i = 0;
			count = 1;
			while (count <= 35)
			{
				memset(temp, 0x00, sizeof(char)* 1024);

				j = 0;

				while (line[i] != '\t' && line[i] != '\n')
				{
					temp[j] = line[i];
					j++;
					i++;
				}
				i++;
				switch (count)
				{
				case 1: id = temp; break;
				case 2: pw = temp; break;

				case 3: companyName = temp; break;
				case 4: companyTelephone = temp; break;


				case 5: CEOName = temp; break;
				case 6: CEOPhone = temp; break;

				case 7: addressTotal = temp; break;
				case 8: addressId = temp; break;




				case 9:
					str.clear();
					str << temp;
					str >> year; break;
				case 10:
					str.clear();
					str << temp;
					str >> month; break;
				case 11:
					str.clear();
					str << temp;
					str >> day; break;
				case 12:
					str.clear();
					str << temp;
					str >> weekDay; break;
				case 13:
					str.clear();
					str << temp;
					str >> hour; break;
				case 14:
					str.clear();
					str << temp;
					str >> min; break;
				case 15:
					str.clear();
					str << temp;
					str >> sec; break;






				case 16:
					str.clear();
					str << temp;
					str >> paperValueForRer; break;
				case 17:
					str.clear();
					str << temp;
					str >> plasticValueForRer; break;
				case 18:
					str.clear();
					str << temp;
					str >> glassBottleValueForRer; break;
				case 19:
					str.clear();
					str << temp;
					str >> customGroupValueForRer; break;


				case 20:
					str.clear();
					str << temp;
					str >> clothesValueForRer; break;
				case 21:
					str.clear();
					str << temp;
					str >> steelValueForRer; break;
				case 22:
					str.clear();
					str << temp;
					str >> wireValueForRer; break;




				case 23:
					str.clear();
					str << temp;
					str >> stainlessValueForRer; break;
				case 24:
					str.clear();
					str << temp;
					str >> copperValueForRer; break;








				case 25:
					str.clear();
					str << temp;
					str >> paperValueForPicker; break;
				case 26:
					str.clear();
					str << temp;
					str >> plasticValueForPicker; break;
				case 27:
					str.clear();
					str << temp;
					str >> glassBottleValueForPicker; break;
				case 28:
					str.clear();
					str << temp;
					str >> customGroupValueForPicker; break;



				case 29:
					str.clear();
					str << temp;
					str >> clothesValueForPicker; break;
				case 30:
					str.clear();
					str << temp;
					str >> steelValueForPicker; break;
				case 31:
					str.clear();
					str << temp;
					str >> wireValueForPicker; break;



				case 32:
					str.clear();
					str << temp;
					str >> stainlessValueForPicker; break;
				case 33:
					str.clear();
					str << temp;
					str >> copperValueForPicker; break;


				case 34:
					str.clear();
					str << temp;
					str >> lengthForRerElectronics; break;
				case 35:
					str.clear();
					str << temp;
					str >> lengthForPickerElectronics; break;

				default: break;

				}
				count++;
			}


			// RResource ���
			RResource* rResourceLink = this->RegisterNewRResource
				(
				id,
				pw,
				companyName,
				companyTelephone,
				CEOName,
				CEOPhone,
				addressTotal,
				addressId,

				year,
				month,
				day,
				weekDay,
				hour,
				min,
				sec,

				paperValueForRer,
				plasticValueForRer,
				glassBottleValueForRer,
				customGroupValueForRer,

				clothesValueForRer,
				steelValueForRer,
				wireValueForRer,

				stainlessValueForRer,
				copperValueForRer,


				paperValueForPicker,
				plasticValueForPicker,
				glassBottleValueForPicker,
				customGroupValueForPicker,

				clothesValueForPicker,
				steelValueForPicker,
				wireValueForPicker,

				stainlessValueForPicker,
				copperValueForPicker
				);



			RValue *rerRValueLink = rResourceLink->GetRerRValue();
			RValue *pickerRValueLink = rResourceLink->GetPickerRValue();

			char rValueLine[256];
			char tempCode[128];
			char tempValue[128];

			string electronicsCode;
			Long electronicsValue;

			Long k;
			Long m;
			Long n;
			for (Long j = 0; j < lengthForRerElectronics; j++)
			{
				memset(rValueLine, 0x00, sizeof(char)* 256); // �ʱ�ȭ
				fgets(rValueLine, 256, RResourceList); // ���� �б�

				memset(tempCode, 0x00, sizeof(char)* 128);
				memset(tempValue, 0x00, sizeof(char)* 128);

				k = 0;
				m = 0;
				while (rValueLine[k] != '\t')
				{
					tempCode[m] = rValueLine[k];
					m++;
					k++;
				}
				k++;

				n = 0;
				while (rValueLine[k] != '\n')
				{
					tempValue[n] = rValueLine[k];
					n++;
					k++;
				}

				electronicsCode = tempCode;

				str.clear();
				str << tempValue;
				str >> electronicsValue;


				rerRValueLink->AddElectornicsValueItem(electronicsCode, electronicsValue);

			}

			Long o;
			Long p;
			Long q;
			for (Long r = 0; r < lengthForRerElectronics; r++)
			{
				memset(rValueLine, 0x00, sizeof(char)* 256); // �ʱ�ȭ
				fgets(rValueLine, 256, RResourceList); // ���� �б�

				memset(tempCode, 0x00, sizeof(char)* 128);
				memset(tempValue, 0x00, sizeof(char)* 128);

				o = 0;
				p = 0;
				while (rValueLine[o] != '\t')
				{
					tempCode[p] = rValueLine[o];
					p++;
					o++;
				}
				o++;

				q = 0;
				while (rValueLine[o] != '\n')
				{
					tempValue[q] = rValueLine[o];
					q++;
					o++;
				}

				electronicsCode = tempCode;

				str.clear();
				str << tempValue;
				str >> electronicsValue;


				rerRValueLink->AddElectornicsValueItem(electronicsCode, electronicsValue);

			}


			memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
			fgets(line, 1024, RResourceList);
		}
	}
}

void RBuJa::LoadSArea()
{
	FILE *SAreaList;
	Long count = 0;

	SAreaList = _fsopen("SAreaList.txt", "rt", _SH_DENYNO);
	if (SAreaList != 0)
	{
		string sAreaId;
		string rResourceId;

		Long LengthForPicker;
		Long LengthForArea;

		stringstream str; // chart to int �� ���� �ڵ�����
		Long i;
		Long j;

		char line[1024];
		memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
		fgets(line, 1024, SAreaList); // ���� �б�

		char temp[1024];
		Long count;

		while (!feof(SAreaList))
		{


			// 1�� ��� // sAreaId, rResourceId

			i = 0;
			count = 1;
			while (count <= 4)
			{
				memset(temp, 0x00, sizeof(char)* 1024);

				j = 0;

				while (line[i] != '\t' && line[i] != '\n')
				{
					temp[j] = line[i];
					j++;
					i++;
				}
				i++;
				switch (count)
				{
				case 1: sAreaId = temp; break;
				case 2: rResourceId = temp; break;

				case 3:
					str.clear();
					str << temp;
					str >> LengthForPicker; break;

				case 4:
					str.clear();
					str << temp;
					str >> LengthForArea; break;

				default: break;
				}
				count++;
			}

			RResource *rResourceLink = this->FindRResource(rResourceId);
			this->RecordSArea(sAreaId, rResourceLink);




			// PickerIdList ���

			string pickerId;


			Long n;
			Long m;
			for (Long k = 0; k < LengthForPicker; k++)
			{
				memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
				fgets(line, 1024, SAreaList); // ���� �б�

				memset(temp, 0x00, sizeof(char)* 1024);

				n = 0;
				m = 0;
				while (line[m] != '\n')
				{
					temp[n] = line[m];
					n++;
					m++;
				}

				pickerId = temp;

				this->LinkSAreaAndPicker(sAreaId, pickerId);
			}




			// AreaList ���

			string areaId;


			Long o;
			Long p;
			for (Long q = 0; q < LengthForArea; q++)
			{
				memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
				fgets(line, 1024, SAreaList); // ���� �б�

				memset(temp, 0x00, sizeof(char)* 1024);

				o = 0;
				p = 0;
				while (line[p] != '\n')
				{
					temp[o] = line[p];
					o++;
					p++;
				}

				areaId = temp;

				this->LinkSAreaAndArea(sAreaId, areaId);
			}




			memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
			fgets(line, 1024, SAreaList);
		}
	}

}

void RBuJa::LoadRRequest()
{
	FILE *RRequestList;
	Long count = 0;

	RRequestList = _fsopen("RRequestList.txt", "rt", _SH_DENYNO);
	if (RRequestList != 0)
	{
		string areaId;
		Long LengthForRRequests;

		stringstream str; // chart to int �� ���� �ڵ�����
		Long i;
		Long j;

		char line[1024];
		memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
		fgets(line, 1024, RRequestList); // ���� �б�

		char temp[1024];
		Long count;

		while (!feof(RRequestList))
		{
			// 1�� �б� // areaId, LengthForRRequests

			i = 0;
			count = 1;
			while (count <= 2)
			{
				memset(temp, 0x00, sizeof(char)* 1024);

				j = 0;

				while (line[i] != '\t' && line[i] != '\n')
				{
					temp[j] = line[i];
					j++;
					i++;
				}
				i++;
				switch (count)
				{
				case 1: areaId = temp; break;

				case 2:
					str.clear();
					str << temp;
					str >> LengthForRRequests; break;

				default: break;
				}
				count++;
			}
			Area *areaLink = this->FindArea(areaId);


			if (areaLink != 0)
			{


				// 2�� �б�    // RRequest �б�

				string rRequestId;

				Long RType;
				Long pickUpType;

				string rerId;
				string pickerId;

				Long isCancelledInt;
				Long isTakenByPickerInt;

				Long yearForRerPickUpDate;
				Long monthForRerPickUpDate;
				Long dayForRerPickUpDate;
				Long weekDayForRerPickUpDate;
				Long hourForRerPickUpDate;
				Long minForRerPickUpDate;
				Long secForRerPickUpDate;

				Long yearForPickerPickUpDate;
				Long monthForPickerPickUpDate;
				Long dayForPickerPickUpDate;
				Long weekDayForPickerPickUpDate;
				Long hourForPickerPickUpDate;
				Long minForPickerPickUpDate;
				Long secForPickerPickUpDate;

				Long yearForRerRequestDate;
				Long monthForRerRequestDate;
				Long dayForRerRequestDate;
				Long weekDayForRerRequestDate;
				Long hourForRerRequestDate;
				Long minForRerRequestDate;
				Long secForRerRequestDate;

				Long rerRPointValue;
				Long pickerRPointValue; // 30

				Long paperWeight; // ����
				Long plasticWeight; // �ö�ƽ
				Long glassBottleWeight; // ��
				Long customGroupWeight; // ���� = �⵿���  =   ĵ, ö ���

				Long clothesWeight; // ��
				Long steelWeight; // ö
				Long wireWeight; // ��

				Long stainlessWeight; // �����θ��� = ����
				Long copperWeight; // ���� = ��

				Long totalWeight;
				

				string electronics;
				string electronicsDescription;



				Long m;
				for (Long k = 0; k < LengthForRRequests; k++)
				{
					memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
					fgets(line, 1024, RRequestList); // ���� �б�


					m = 0;
					Long count = 1;
					while (count <= 42)
					{
						memset(temp, 0x00, sizeof(char)* 1024);
						Long n = 0;
						while (line[m] != '\t' && line[m] != '\n')
						{
							temp[n] = line[m];
							n++;
							m++;
						}
						m++;
						switch (count)
						{
						case 1:
							rRequestId = temp; break;





						case 2:
							str.clear();
							str << temp;
							str >> RType; break;
						case 3:
							str.clear();
							str << temp;
							str >> pickUpType; break;

						case 4:
							rerId = temp; break;
						case 5:
							pickerId = temp; break;





						case 6:
							str.clear();
							str << temp;
							str >> isCancelledInt; break;
						case 7:
							str.clear();
							str << temp;
							str >> isTakenByPickerInt; break;





						case 8:
							str.clear();
							str << temp;
							str >> yearForRerPickUpDate; break;
						case 9:
							str.clear();
							str << temp;
							str >> monthForRerPickUpDate; break;
						case 10:
							str.clear();
							str << temp;
							str >> dayForRerPickUpDate; break;
						case 11:
							str.clear();
							str << temp;
							str >> weekDayForRerPickUpDate; break;
						case 12:
							str.clear();
							str << temp;
							str >> hourForRerPickUpDate; break;
						case 13:
							str.clear();
							str << temp;
							str >> minForRerPickUpDate; break;
						case 14:
							str.clear();
							str << temp;
							str >> secForRerPickUpDate; break;





						case 15:
							str.clear();
							str << temp;
							str >> yearForPickerPickUpDate; break;
						case 16:
							str.clear();
							str << temp;
							str >> monthForPickerPickUpDate; break;
						case 17:
							str.clear();
							str << temp;
							str >> dayForPickerPickUpDate; break;
						case 18:
							str.clear();
							str << temp;
							str >> weekDayForPickerPickUpDate; break;
						case 19:
							str.clear();
							str << temp;
							str >> hourForPickerPickUpDate; break;
						case 20:
							str.clear();
							str << temp;
							str >> minForPickerPickUpDate; break;
						case 21:
							str.clear();
							str << temp;
							str >> secForPickerPickUpDate;  break;





						case 22:
							str.clear();
							str << temp;
							str >> yearForRerRequestDate; break;
						case 23:
							str.clear();
							str << temp;
							str >> monthForRerRequestDate; break;
						case 24:
							str.clear();
							str << temp;
							str >> dayForRerRequestDate; break;
						case 25:
							str.clear();
							str << temp;
							str >> weekDayForRerRequestDate; break;
						case 26:
							str.clear();
							str << temp;
							str >> hourForRerRequestDate; break;
						case 27:
							str.clear();
							str << temp;
							str >> minForRerRequestDate; break;
						case 28:
							str.clear();
							str << temp;
							str >> secForRerRequestDate; break;






						case 29:
							str.clear();
							str << temp;
							str >> rerRPointValue; break;
						case 30:
							str.clear();
							str << temp;
							str >> pickerRPointValue; break;




						case 31:
							str.clear();
							str << temp;
							str >> paperWeight; break;
						case 32:
							str.clear();
							str << temp;
							str >> plasticWeight;;; break;
						case 33:
							str.clear();
							str << temp;
							str >> glassBottleWeight;;; break;
						case 34:
							str.clear();
							str << temp;
							str >> customGroupWeight;; break;




						case 35:
							str.clear();
							str << temp;
							str >> clothesWeight;; break;
						case 36:
							str.clear();
							str << temp;
							str >> steelWeight;; break;
						case 37:
							str.clear();
							str << temp;
							str >> wireWeight;; break;





						case 38:
							str.clear();
							str << temp;
							str >> stainlessWeight;; break;
						case 39:
							str.clear();
							str << temp;
							str >> copperWeight;;; break;
						case 40: 
							str.clear();
							str << temp;
							str >> totalWeight;;;; break;



						case 41: electronics = temp; break;
						case 42: electronicsDescription = temp; break;


						default: break;

						}
						count++;
					}
					/*


					1.
					rerId,
					picerId�� ��ũ�� ã�Ƶα�

					2.
					���� ���������ֱ�

					*/

					// 1.

					Rer *rerLink = this->FindRer(rerId);
					Picker *pickerLink = this->FindPicker(pickerId);


					// 2.
					RRequest *rRequestLink = areaLink->RecordRRequest(

						rRequestId,

						RType,
						pickUpType,

						isCancelledInt,
						isTakenByPickerInt, // 5

						yearForRerPickUpDate,
						monthForRerPickUpDate,
						dayForRerPickUpDate,
						weekDayForRerPickUpDate,
						hourForRerPickUpDate,
						minForRerPickUpDate,
						secForRerPickUpDate, // 12

						yearForPickerPickUpDate,
						monthForPickerPickUpDate,
						dayForPickerPickUpDate,
						weekDayForPickerPickUpDate,
						hourForPickerPickUpDate,
						minForPickerPickUpDate,
						secForPickerPickUpDate, //  19

						yearForRerRequestDate,
						monthForRerRequestDate,
						dayForRerRequestDate,
						weekDayForRerRequestDate,
						hourForRerRequestDate,
						minForRerRequestDate,
						secForRerRequestDate, // 26

						rerRPointValue,
						pickerRPointValue, // 28

						paperWeight, // ����
						plasticWeight, // �ö�ƽ
						glassBottleWeight, // ��
						customGroupWeight, // ���� = �⵿���  =   ĵ, ö ��� // 32

						clothesWeight, // ��
						steelWeight, // ö
						wireWeight, // ��	// 35

						stainlessWeight, // �����θ��� = ����
						copperWeight, // ���� = ��				// 37

						totalWeight, // 38

						electronics,
						electronicsDescription, // 40

						rerLink,
						pickerLink // 42
						);

					if (rerLink != 0)
					{
						rerLink->RegisterRRequestLink(rRequestLink);
					}
					if (pickerLink != 0)
					{
						if (rRequestLink->GetIsTakenByPicker() == false)
						{
							pickerLink->RegisterRRequestLink(rRequestLink);
						}
					}

				}

			}

			memset(line, 0x00, sizeof(char)* 1024); // �ʱ�ȭ
			fgets(line, 1024, RRequestList);
		}
	}


}
















void RBuJa::GetCopiedRerBuffer(Rer* *(rers), Long *count)
{
	this->controlRerLink->GetCopiedRerBuffer(rers, count);
}

void RBuJa::GetCopiedPickerBuffer(Picker* *(pickers), Long *count)
{
	this->controlPickerLink->GetCopiedPickerBuffer(pickers, count);
}

void RBuJa::GetCopiedAreaBuffer(Area* *(areas), Long *count)
{
	this->areaListLink->GetCopiedAreaBuffer(areas, count);
}



//************************************************************************************************************************************************************************//
//************************************************************************************************************************************************************************//

// Find



SArea* RBuJa::SAreaFirst()
{
	SArea* sAreaLink = &(this->sAreas.First()->GetObject());
	return sAreaLink;
}

SArea* RBuJa::SAreaPrevious()
{
	SArea* sAreaLink = &(this->sAreas.Previous()->GetObject());
	return sAreaLink;
}

SArea* RBuJa::SAreaNext()
{
	SArea* sAreaLink = &(this->sAreas.Next()->GetObject());
	return sAreaLink;
	
}

SArea* RBuJa::SAreaLast()
{
	SArea* sAreaLink = &(this->sAreas.Last()->GetObject());
	return sAreaLink;
	
}


RResource* RBuJa::RResourceFirst()
{
	RResource* rResourceLink = this->controlRResourceLink->First();
	return rResourceLink;
}
RResource* RBuJa::RResourcePrevious()
{
	RResource* rResourceLink = this->controlRResourceLink->Previous();
	return rResourceLink;
}
RResource* RBuJa::RResourceNext()
{
	RResource* rResourceLink = this->controlRResourceLink->Next();
	return rResourceLink;
}
RResource* RBuJa::RResourceLast()
{
	RResource* rResourceLink = this->controlRResourceLink->Last();
	return rResourceLink;
}




Area* RBuJa::RegisterArea(string araeId)
{
	Area* areaLink = this->areaListLink->RecordArea(araeId);
	return areaLink;
}

Area* RBuJa::FindArea(string areaId)
{
	Area* areaLink = this->areaListLink->FindArea(areaId);
	return areaLink;
}

Rer* RBuJa::FindRer(string id)
{
	Rer* rerLink = this->controlRerLink->FindRer(id);
	return rerLink;
}
Picker* RBuJa::FindPicker(string id)
{
	Picker* pickerLink = this->controlPickerLink->FindPicker(id);
	return pickerLink;
}
RResource* RBuJa::FindRResource(string id)
{
	RResource* rResourceLink = this->controlRResourceLink->FindRResource(id);
	return rResourceLink;
}










//*/


Long CompareSAreaIds( void *one, void *other)
{
	 int ret; 
	ret =  static_cast<SArea*>(one)->GetId().compare(  *(static_cast<string*>(other)) );
	return ret; 
}//*/