#include "FormMakeRResource.h"
#include "FormFindingAddress.h"
#include "FormMainRResource.h"
#include "FormMainSArea.h"


#include <afxcmn.h>

BEGIN_MESSAGE_MAP(FormMakeRResource, CDialog)
	ON_BN_CLICKED(IDC_K4B_OK, OnOKButtonClicked)
//	ON_BN_CLICKED(IDC_E1B_NOSAVE, OnNoSaveButtonClicked)

	ON_WM_CLOSE()
END_MESSAGE_MAP()

FormMakeRResource::FormMakeRResource(CWnd *parent)
:CDialog(FormMakeRResource::IDD, parent)
{

}

BOOL FormMakeRResource::OnInitDialog()
{
	CDialog::OnInitDialog();

	return FALSE;
}

void FormMakeRResource::OnOK()
{
	OnOKButtonClicked();
}

void FormMakeRResource::OnCancel()
{
	EndDialog(0);
}

void FormMakeRResource::OnOKButtonClicked()
{
	// ȸ������ ���� �����ͼ� ControlRer�� �����ϱ�
	CString id = "";
	CString pw = "";

	CString companyName = "";
	CString companyTelephoneFirst = "";
	CString companyTelephoneMiddle = "";
	CString companyTelephoneLast = "";

	CString CEOName = "";
	CString CEOPhoneFirst = "";
	CString CEOPhoneMiddle = "";
	CString CEOPhoneLast = "";

	CString addressId = "";
	CString addressDetail = "";

	this->GetDlgItem(IDC_K4E_ID)->GetWindowText(id);
	this->GetDlgItem(IDC_K4E_PW)->GetWindowText(pw);

	this->GetDlgItem(IDC_K4E_COMPANYNAME)->GetWindowText(companyName);
	this->GetDlgItem(IDC_K4E_COMPANYFIRST)->GetWindowText(companyTelephoneFirst);
	this->GetDlgItem(IDC_K4E_COMPANYMIDDLE)->GetWindowText(companyTelephoneMiddle);
	this->GetDlgItem(IDC_K4E_COMPANYLAST)->GetWindowText(companyTelephoneLast);

	this->GetDlgItem(IDC_K4E_CEONAME)->GetWindowText(CEOName);
	this->GetDlgItem(IDC_K4E_PHONEFIRST)->GetWindowText(CEOPhoneFirst);
	this->GetDlgItem(IDC_K4E_PHONEMIDDLE)->GetWindowText(CEOPhoneMiddle);
	this->GetDlgItem(IDC_K4E_PHONELAST)->GetWindowText(CEOPhoneLast);

	this->GetDlgItem(IDC_K4E_ADDRESSID)->GetWindowText(addressId);
	this->GetDlgItem(IDC_K4E_ADDRESSSPECIFIC)->GetWindowText(addressDetail);

	
	FormMainRResource *formMainRResource = (FormMainRResource*)GetParent();
	FormMainSArea *formMainSArea = (FormMainSArea*)CWnd::FindWindow((LPCTSTR) "#32770", (LPCTSTR) "�˺��� ���������ڿ� ���α׷� - ��������");


	CString companyTelephoneTotal = companyTelephoneFirst + companyTelephoneMiddle + companyTelephoneLast;
	CString CEOPhoneTotal = CEOPhoneFirst + CEOPhoneMiddle + CEOPhoneLast;
	
	string temp = " ";
	CString addressTotal = addressId + temp.c_str() + addressDetail;

	// RResource ���� ���� �����ͼ� ControlRResource�� �����ϱ� �Ϸ�
	formMainSArea->rBuJa->RegisterNewRResource(id.GetBuffer(0), pw.GetBuffer(0), companyName.GetBuffer(0), companyTelephoneTotal.GetBuffer(0), CEOName.GetBuffer(0), CEOPhoneTotal.GetBuffer(0), addressTotal.GetBuffer(0), addressId.GetBuffer(0));
	
	// ������ RResource�� FormMainRResource�� ��Ʈ�Ѻ信 �׸����� �߰��ϱ�
	formMainRResource->DisplayRResourceList();

	EndDialog(0);
}

void FormMakeRResource::OnFindingAddressButtonclicked()
{
	FormFindingAddress formFindingAddress(this);
	formFindingAddress.DoModal();
}


void FormMakeRResource::OnClose()
{
	OnOK();
}