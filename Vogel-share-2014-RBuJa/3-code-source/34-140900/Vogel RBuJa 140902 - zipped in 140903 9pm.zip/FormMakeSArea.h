//FormMakeSArea.h

#ifndef _FORMMAKESAREA_H
#define _FORMMAKESAREA_H
#include "RResource.h"
#include "resource.h"
#include <afxwin.h>

class FormMakeSArea : public CDialog
{
public:
	enum { IDD = IDD_K3_MAKESAREA };
public:
	FormMakeSArea(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();
	virtual void OnOK(); // EnterŰ â �ڵ����� ������ ���� �������̵�

public:
	CWnd* rResourceList;
	CWnd* rResourceDetailList;


public: // Display
	void DisplayRResourceList();
	void DisplayRResourceDetailList(RResource* rResourceLink);

protected:

	// ID_BUTTON_OK
	afx_msg void OnOKButtonClicked();

	// Notify
	afx_msg void OnMouseLButtonOneClicked(NMHDR* pNotifyStruct, LRESULT* result);


	afx_msg void OnClose();


	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeEdit6();
	afx_msg void OnEnChangeEdit8();
};


#endif