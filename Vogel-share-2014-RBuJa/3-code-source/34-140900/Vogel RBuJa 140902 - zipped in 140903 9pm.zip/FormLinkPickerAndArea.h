//FormLinkPickerAndArea.h

#ifndef _FORMLINKPICKERANDAREA_H
#define _FORMLINKPICKERANDAREA_H

#include "FormMainSArea.h"
#include "resource.h"
#include <afxwin.h>

class FormLinkPickerAndArea : public CDialog
{
public:
	enum { IDD = IDD_P1_ASSINGPICKER };
public:
	FormLinkPickerAndArea(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();

public: // ����� �������̵�
	virtual void OnOK(); // EnterŰ â �ڵ����� ����
	virtual void OnCancel(); // ESCŰ â �ڵ����� ����

public:
	CWnd* areaList;
	CWnd* chargingList;


public: // Display
	void DisplayAreaList();
	void DisplayAreaListForBinary(BinaryTree<Area>::Node* nodeLink, Long *index);
	void DisplayChangingList();


protected:

	// ID_BUTTON_OK
	afx_msg void OnAddButtonClicked();
	afx_msg void OnDeleteButtonClicked();
	
	afx_msg void OnCloseButtonClicked();

	afx_msg void OnClose();


	DECLARE_MESSAGE_MAP()
};


#endif