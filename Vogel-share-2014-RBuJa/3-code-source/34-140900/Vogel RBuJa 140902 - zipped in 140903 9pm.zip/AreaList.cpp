/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		AreaList.cpp
��������:		140712
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/
#include "AreaList.h"

AreaList::AreaList()
{
	this->length = 0;
}

AreaList::AreaList(const AreaList& source)
{
	this->areas = source.areas;
	this->length = source.length;
}

AreaList::~AreaList(){}

AreaList& AreaList::operator=(const AreaList& source)
{
	this->areas = source.areas;
	this->length = source.length;

	return *this;
}
	
Area* AreaList::GetOrRecordArea(string addressAndAreaId)
{
	// zone�� �ִ��� Ȯ���Ѵ�.
	BinaryTree<Area>::Node* nodeLink = this->areas.Search(Area(addressAndAreaId, 0 , 0), CompareAddressAndAreaIds);
	// zone�� ������
	if (nodeLink == 0)
	{
		// zone�� ���� ����� ControlZone�� �߰��Ѵ�.
		nodeLink = this->areas.Insert(Area(addressAndAreaId), CompareAddressAndAreaIds);
		this->length = this->areas.GetLength();
	}
	// Node* �� Zone*�� �ٲ۴�.
	Area* areaLink = &(nodeLink->GetKey());

	return areaLink;
}

Area* AreaList::RecordArea(string addressAndAreaId)
{
	Area* newAreaLink = &(this->areas.Insert(Area(addressAndAreaId), CompareAddressAndAreaIds)->GetKey());
	this->length = this->areas.GetLength();
	return newAreaLink;
}

Area* AreaList::FindArea(string areaId)
{
	Area* areaLink = 0;
	BinaryTree<Area>::Node* nodeLink = this->areas.Search(Area(areaId, 0 , 0), CompareAddressAndAreaIds);
	if( nodeLink !=0 )
	{
		areaLink = &(nodeLink->GetKey());
	}
	return areaLink;
}

Area* AreaList::DeleteArea(string addressAndAreaId)
{
	Area* areaLink = 0;
	BinaryTree<Area>::Node* nodeLink = this->areas.Delete(Area(addressAndAreaId, 0, 0), CompareAddressAndAreaIds);
	if (nodeLink != 0)
	{
		areaLink = &(nodeLink->GetKey());
	}
	return areaLink;
}

Long CompareAddressAndAreaIds(void* one, void* other)
{
	Long ret;
	ret = (((Area*)one)->GetId()).compare(((Area*)other)->GetId());
	return ret;
}