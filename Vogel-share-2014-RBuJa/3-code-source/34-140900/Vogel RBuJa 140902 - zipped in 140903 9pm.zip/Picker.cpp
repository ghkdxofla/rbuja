// Picker.cpp
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		Picker.cpp
��������:		140627
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#include "Picker.h"

Picker::Picker() {

	this->id = "";
	this->pw = "";
	this->name = "";
	this->phone = "";

	Date joinDate = Date::Today();			// Picker�� ����Ʈ �����ڰ� ����� ��¥�� �ִ´�.
	this->likeCount = 0;

	this->rPoint = RPoint();

	this->lengthForAreaLinks = 0;
	this->currentForAreaLinks = 0;

	this->lengthForToDo = 0;
	this->currentForToDo = 0;

	this->rResourceLink = 0;

	this->lengthForDateRRequestLinkIndexes = 0;
	this->currentForDateRRequestLinkIndexes = 0;
}


Picker::Picker( string id ) 
{
	this->id = id;
	this->pw = "";
	this->name = "";
	this->phone = "";

	Date joinDate = Date::Today();			// Picker�� ����Ʈ �����ڰ� ����� ��¥�� �ִ´�.
	this->likeCount = 0;

	this->rPoint = RPoint();



	this->lengthForAreaLinks = 0;
	this->currentForAreaLinks = 0;

	this->lengthForToDo = 0;
	this->currentForToDo = 0;
	
	this->rResourceLink = 0;

	this->lengthForDateRRequestLinkIndexes = 0;
	this->currentForDateRRequestLinkIndexes = 0;
}


Picker::Picker(string id, string pw, string name, string phone)
{
	this->id = id;
	this->pw = pw;
	this->name = name;
	this->phone = phone;

	this->joinDate = Date::Today();
	this->likeCount = 0;

	this->rPoint = RPoint();




	this->lengthForAreaLinks = 0;
	this->currentForAreaLinks = 0;

	this->lengthForToDo = 0;
	this->currentForToDo = 0;

	this->rResourceLink = 0;

	this->lengthForDateRRequestLinkIndexes = 0;
	this->currentForDateRRequestLinkIndexes = 0;
}//*/



Picker::Picker(
	string id,
	string pw,
	string name,
	string phone,

	Long year,
	Long month,
	Long day,
	Long weekDay,
	Long hour,
	Long min,
	Long sec)
{
	this->id = id;
	this->pw = pw;
	this->name = name;
	this->phone = phone;

	Date joinDate(year, month, day, weekDay, hour, min, sec);
	this->joinDate = joinDate;
	this->likeCount = 0;

	this->rPoint = RPoint();

	this->lengthForAreaLinks = 0;
	this->currentForAreaLinks = 0;

	this->lengthForToDo = 0;
	this->currentForToDo = 0;

	this->sAreaLink = 0;

	this->lengthForDateRRequestLinkIndexes = 0;
	this->currentForDateRRequestLinkIndexes = 0;
}

Picker::Picker(
	string id,
	string pw,
	string name,
	string phone,

	Date joinDate,
	Long likeCount,

	RPoint rPoint,

	RResource* rResourceLink,
	SArea* sAreaLink,

	LinkedList<Area*> *areaLinks,
	LinkedList<RRequest*> *rRequestsToDo,
	DateIndexes<LinkedList<RRequest*>::Node*> *dateRRequestLinkIndexes
	)
{
	this->id = id;
	this->pw = pw;
	this->name = name;
	this->phone = phone;

	this->joinDate = joinDate;
	this->likeCount = likeCount;

	this->rPoint = rPoint;

	this->rResourceLink = rResourceLink;
	this->sAreaLink = sAreaLink;

	this->areaLinks = *areaLinks;
	this->rRequestsToDo = *rRequestsToDo;
	this->dateRRequestLinkIndexes = *dateRRequestLinkIndexes;

	this->lengthForAreaLinks = areaLinks->GetLength();
	this->lengthForToDo = rRequestsToDo->GetLength();
	this->lengthForDateRRequestLinkIndexes = dateRRequestLinkIndexes->GetLength();

	if (areaLinks->GetCurrent() != 0)
	{
		currentForAreaLinks = areaLinks->GetCurrent()->GetObject();
	}
	else
	{
		currentForAreaLinks = 0;
	}

	if (rRequestsToDo->GetCurrent() != 0)
	{
		currentForToDo = rRequestsToDo->GetCurrent()->GetObject();
	}
	else
	{
		currentForToDo = 0;
	}

	if (dateRRequestLinkIndexes->GetCurrent() != 0)
	{
		currentForDateRRequestLinkIndexes = dateRRequestLinkIndexes->GetCurrent();
	}
	else
	{
		currentForDateRRequestLinkIndexes = 0;
	}
}


Picker::Picker(const Picker& source)
{
	this->id = source.id;
	this->pw = source.pw;
	this->name = source.name;
	this->phone = source.phone;

	this->joinDate = source.joinDate;
	this->likeCount = source.likeCount;

	this->rPoint = source.rPoint;




	this->lengthForAreaLinks = source.lengthForAreaLinks;
	this->currentForAreaLinks = source.currentForAreaLinks;

	this->lengthForToDo = source.lengthForToDo;
	this->currentForToDo = source.currentForToDo;

	this->rResourceLink = source.rResourceLink;

	this->lengthForDateRRequestLinkIndexes = source.lengthForDateRRequestLinkIndexes;
	this->currentForDateRRequestLinkIndexes = source.currentForDateRRequestLinkIndexes;

}

Picker::~Picker() {}

Picker& Picker::operator=(const Picker& source)
{
	this->id = source.id;
	this->pw = source.pw;
	this->name = source.name;
	this->phone = source.phone;

	this->joinDate = source.joinDate;
	this->likeCount = source.likeCount;

	this->rPoint = source.rPoint;




	this->lengthForAreaLinks = source.lengthForAreaLinks;
	this->currentForAreaLinks = source.currentForAreaLinks;

	this->lengthForToDo = source.lengthForToDo;
	this->currentForToDo = source.currentForToDo;
	
	this->rResourceLink = source.rResourceLink;


	this->lengthForDateRRequestLinkIndexes = source.lengthForDateRRequestLinkIndexes;
	this->currentForDateRRequestLinkIndexes = source.currentForDateRRequestLinkIndexes;



	return *this;
}




// RecordAreaLink

Area* Picker::RegisterAreaLink(Area *newArea)
{
	Area *areaLink =  this->areaLinks.AppendFromTail( newArea )->GetObject();
	this->lengthForAreaLinks = this->areaLinks.GetLength();
	this->currentForAreaLinks = this->areaLinks.GetCurrent()->GetObject();
	return areaLink;
}
//*/

RRequest* Picker::RegisterRRequestLink(RRequest* rRequestLink)
{
	RRequest* newRRequestLink = this->rRequestsToDo.AppendFromTail(rRequestLink)->GetObject();
	this->lengthForToDo = this->rRequestsToDo.GetLength();
	this->currentForToDo = this->rRequestsToDo.GetCurrent()->GetObject();





	LinkedList<RRequest*>::Node* rRequestLinksNodeLink = this->rRequestsToDo.GetCurrent();
	DateIndexes<LinkedList<RRequest*>::Node*>::Node* dateRRequestLinkIndexesNodeLink = this->currentForDateRRequestLinkIndexes;


	// ���� ���� �����̰ų�, ������ ������ ���ʷ� ���� ��
	if (dateRRequestLinkIndexesNodeLink == 0
		|| dateRRequestLinkIndexesNodeLink->GetDate()->IsNotEqual(Date::Today()))
	{
		// �� ���� ��带 �����
		this->dateRRequestLinkIndexes.AppendFromTail(rRequestLinksNodeLink, rRequestLinksNodeLink);
		this->lengthForDateRRequestLinkIndexes = this->dateRRequestLinkIndexes.GetLength();
		this->currentForDateRRequestLinkIndexes = this->dateRRequestLinkIndexes.GetCurrent();
	}
	else
	{ // ���ο� tail�� ���� ���� ġȯ��Ų��
		int length = dateRRequestLinkIndexesNodeLink->GetLength() + 1;
		*dateRRequestLinkIndexesNodeLink = DateIndexes<LinkedList<RRequest*>::Node*>::Node(dateRRequestLinkIndexesNodeLink->GetStartDateLink(), rRequestLinksNodeLink, Date::Today(), length);
	}//*/


	return newRRequestLink;
}
//*/




Area* Picker::AreaLinkFirst()
{
	Area* areaLink = 0;
	LinkedList<Area*>::Node* nodeLink = this->areaLinks.First();
	if (nodeLink != 0)
	{
		areaLink = nodeLink->GetObject();
	}
	return areaLink;
}

Area* Picker::AreaLinkNext()
{
	Area* areaLink = this->areaLinks.First()->GetObject();
	return areaLink;
}
Area* Picker::AreaLinkPrivious()
{
	Area* areaLink = this->areaLinks.First()->GetObject();
	return areaLink;
}
Area* Picker::AreaLinkLast()
{
	Area* areaLink = this->areaLinks.First()->GetObject();
	return areaLink;
}


RRequest* Picker::FirstForRRequestToDoLink()
{
	RRequest* rRequestLink = 0;
	LinkedList<RRequest*>::Node* nodeLink = this->rRequestsToDo.First();
	if (nodeLink != 0)
	{
		rRequestLink = nodeLink->GetObject();
	}
	return rRequestLink;
}
RRequest* Picker::NextForRRequestToDoLink()
{
	RRequest* rRequestLink = this->rRequestsToDo.Next()->GetObject();
	return rRequestLink;
}
RRequest* Picker::PreviousForRRequestToDoLink()
{
	RRequest* rRequestLink = this->rRequestsToDo.Previous()->GetObject();
	return rRequestLink;
}
RRequest* Picker::LastForRRequestToDoLink()
{
	RRequest* rRequestLink = this->rRequestsToDo.Last()->GetObject();
	return rRequestLink;
}



LinkedList<RRequest*>::Node* Picker::FindRRequestLinkNode(string rRequestId)
{
	LinkedList<RRequest*>::Node* nodeLink = this->rRequestsToDo.LinearSearchUniqueForLinkObj(&rRequestId, CompareRRequestLinkId);
	return nodeLink;
}//*/



void Picker::PickUpComplete(RRequest *rRequestLink)
{
	rRequestLink->PickUpComplete();
	LinkedList<RRequest*>::Node* nodeLink = this->FindRRequestLinkNode(rRequestLink->GetId());
	if (nodeLink != 0)
	{

		/*
		this->DeleteRRequestLinkNode(nodeLink);�� ����
		DateIndexes ���� ������
		ó������
		1. ����� RRequestToDo�� ��尡 ���� DateIndexes�� ��带 ���Ѵ�
		2. Length�� ����,
		����� RRequestToDo�� ��忡 ����,
		DateIndexes�� �����Ѵ�

		�� ó������
		1.
		1.1. ����� RRequestToDo�� ��尡 ���� Date�� ���Ѵ�
		1.2. �� Date�� DateIndexes�� �ش� ��带 ã�´�
		2.
		2.1. DateIndexes�� �ش� ��尡 length ���� 1�϶�
		2.1.1. DateIndexes�� �ش� ��带 �����
		2.2.  DateIndexes�� �ش� ��尡 length ���� 1���� ũ��
		2.2.1. DateIndexes�� �ش� ��尡 ����  startIndex�� endIndex ����
		����� RRequestToDo�� ��带 ����Ű��
		2.2.1.1. startIndex�� endIndex�� �ű��, length--
		2.2.2. DateIndexes�� �ش� ��尡 ����  startIndex�� endIndex ����
		����� RRequestToDo�� ��带 ����Ű�°� �ƴ϶��
		2.2.2.1. length--
		*/

		//	1.1.
		Date date = nodeLink->GetObject()->GetRerPickUpDate();

		// 1.2.
		DateIndexes<LinkedList<RRequest*>::Node*>::Node* datNodeLink = this->dateRRequestLinkIndexes.LinearSearchUnique(&date);


		if (datNodeLink != 0)
		{
			// 2.1.
			if (datNodeLink->GetLength() == 1)
			{
				// 2.1.1.
				this->dateRRequestLinkIndexes.Delete(datNodeLink);
			}

			// 2.2.
			else
			{
				// 2.2.1.
				// startIndex�� ����� RRequestToDo�� ����
				if (datNodeLink->GetStartDateLink() == nodeLink)
				{	// 2.2.1.1.
					*datNodeLink = DateIndexes<LinkedList<RRequest*>::Node*>::Node(datNodeLink->GetStartDateLink()->GetNext(), datNodeLink->GetEndDateLink(), *(datNodeLink->GetDate()), datNodeLink->GetLength() - 1);
				}
				else if (datNodeLink->GetEndDateLink() == nodeLink)
				{	// 2.2.1.1.
					*datNodeLink = DateIndexes<LinkedList<RRequest*>::Node*>::Node(datNodeLink->GetStartDateLink(), datNodeLink->GetEndDateLink()->GetPrevious(), *(datNodeLink->GetDate()), datNodeLink->GetLength() - 1);
				}
				// 2.2.2.
				else if (datNodeLink->GetStartDateLink() != nodeLink && datNodeLink->GetEndDateLink() != nodeLink)
				{
					// 2.2.2.1.
					*datNodeLink = DateIndexes<LinkedList<RRequest*>::Node*>::Node(datNodeLink->GetStartDateLink(), datNodeLink->GetEndDateLink(), *(datNodeLink->GetDate()), datNodeLink->GetLength() - 1);
				}
			}
		}



		this->DeleteRRequestLinkNode(nodeLink);
		this->lengthForToDo = this->rRequestsToDo.GetLength();
		if (this->rRequestsToDo.GetCurrent() == 0)
		{
			this->currentForToDo = 0;
		}
		else
		{
			this->currentForToDo = this->rRequestsToDo.GetCurrent()->GetObject();
		}
	}

}
//*/


void Picker::DeleteRRequestLinkNode(LinkedList<RRequest*>::Node* nodeLink)
{
	this->rRequestsToDo.Delete(nodeLink);
}


Long CompareRRequestLinkId(void *one, void *other)
{
	int ret;
	ret = static_cast<RRequest*>(one)->GetId().compare(*(static_cast<string*>(other)));
	return ret;
}//*/




/*
LinkedList<RRequest*>::Node* Picker::FindRRequestLinkNode(string rRequestId)
{
//	RRequest* rRequestLink = this->rRequestsToDo.LinearSearchUniqueForLinkObj(&rRequestId, CompareRRequestLinkId)->GetObject();
	return  this->rRequestsToDo.LinearSearchUniqueForLinkObj(&rRequestId, CompareRRequestLinkId);
}//*/

/*
void Picker::PickUpComplete(LinkedList<RRequest*>::Node* nodeLink)
{
	nodeLink->GetObject()->PickUpComplete();
	this->rRequestsToDo.Delete(nodeLink); 
	this->lengthForToDo = this->rRequestsToDo.GetLength();
	if( this->rRequestsToDo.GetCurrent() == 0 )
	{
		this->currentForToDo =0;
	}
	else
	{
		this->currentForToDo = this->rRequestsToDo.GetCurrent()->GetObject();
	}
}
//*/



/*
Long CompareRRequestLinkId( void *one, void *other ) 
{
	 int ret; 
	ret =  static_cast<RRequest*>(one)->GetId().compare(  *(static_cast<string*>(other)) );
	return ret; 
}//*/



/*
RRequest* Picker::RecordRRequestLink(RRequest* rRequestLink)
{ 
	RRequest* newRRequestLink = this->controlRRequestLink.RecordRRequestLink(rRequestLink);
	
	return newRRequestLink;
}



RRequest* Picker::FindRRequestLink(string rRequestId)
{
	RRequest *rRequestLink = 0;																			
	LinkedList<RRequest*>::Node* node = this->rRequestsToDo.LinearSearchUniqueForLinkObj( &rRequestId, CompareRRequestLinkId);// keyLink =rRequestId
	if( node !=0 )
	{
		rRequestLink = node->GetObject();
	}
	return rRequestLink;
}

///////////////////////
///////////////////////
///////////////////////
///////////////////////
///////////////////////
///////////////////////
///////////////////////
void Picker::GetAreasLinks( Area* (*zones), Long length )
{
	LinkedList<Area*>::Node* nodeLink = this->zoneLinks.First();
	for(Long i = 0; i < this->lengthForAreaLinks; i++ )
	{
		zones[i] = nodeLink->GetObject();
		nodeLink = this->zoneLinks.Next();
	}

}


//*/
