// Area.cpp
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		Area.cpp
��������:		140712
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#include "Area.h"
#include "RRequest.h"

Area::Area()
{
	this->addressAndAreaId = "";
	
	this->pickerLink = 0;
	this->rResourceLink = 0;

	this->lengthForRerLinks = 0;
	this->currentForRerLinks = 0;

	this->lengthForRRequests = 0;
	this->currentForRRequests =0;

	this->lengthForDateRerLinkIndexes = 0;
	this->currentForDateRerLinkIndexes = 0;

	this->lengthForDateRRequeseIndexes = 0;
	this->currentForDateRRequestIndexes = 0;
}

Area::Area(string id)
{
	this->addressAndAreaId = id;
	
	this->pickerLink = 0;
	this->rResourceLink = 0;

	this->lengthForRerLinks = 0;
	this->currentForRerLinks = 0;

	this->lengthForRRequests = 0;
	this->currentForRRequests =0;

	this->lengthForDateRerLinkIndexes = 0;
	this->currentForDateRerLinkIndexes = 0;

	this->lengthForDateRRequeseIndexes = 0;
	this->currentForDateRRequestIndexes = 0;
}

Area::Area(string id, Picker* pickerLink, RResource* rResourceLink)
{
	this->addressAndAreaId = id;
	
	this->pickerLink = pickerLink;
	this->rResourceLink = rResourceLink;

	this->lengthForRerLinks = 0;
	this->currentForRerLinks = 0;

	this->lengthForRRequests = 0;
	this->currentForRRequests =0;

	this->lengthForDateRerLinkIndexes = 0;
	this->currentForDateRerLinkIndexes = 0;

	this->lengthForDateRRequeseIndexes = 0;
	this->currentForDateRRequestIndexes = 0;
}

Area::Area(const Area& source)
{
	this->addressAndAreaId = source.addressAndAreaId;
	
	this->pickerLink = source.pickerLink;
	this->rResourceLink = source.rResourceLink;

	this->lengthForRerLinks = source.lengthForRerLinks;
	this->currentForRerLinks = source.currentForRerLinks;

	this->lengthForRRequests = source.lengthForRRequests;
	this->currentForRRequests = source.currentForRRequests;

	this->lengthForDateRerLinkIndexes = source.lengthForDateRerLinkIndexes;
	this->currentForDateRerLinkIndexes = source.currentForDateRerLinkIndexes;

	this->lengthForDateRRequeseIndexes = source.lengthForDateRRequeseIndexes;
	this->currentForDateRRequestIndexes = source.currentForDateRRequestIndexes;
}

Area::~Area(){}

Area& Area::operator=(const Area& source)
{
	this->addressAndAreaId = source.addressAndAreaId;
	
	this->pickerLink = source.pickerLink;
	this->rResourceLink = source.rResourceLink;

	this->lengthForRerLinks = source.lengthForRerLinks;
	this->currentForRerLinks = source.currentForRerLinks;

	this->lengthForRRequests = source.lengthForRRequests;
	this->currentForRRequests = source.currentForRRequests;


	this->lengthForDateRerLinkIndexes = source.lengthForDateRerLinkIndexes;
	this->currentForDateRerLinkIndexes = source.currentForDateRerLinkIndexes;

	this->lengthForDateRRequeseIndexes = source.lengthForDateRRequeseIndexes;
	this->currentForDateRRequestIndexes = source.currentForDateRRequestIndexes;

	return *this;
}

Rer* Area::RegisterRerLink(Rer* rerLink)
{
	Rer* newRerLink = this->rerLinks.AppendFromTail(rerLink)->GetObject();
	this->lengthForRerLinks = rerLinks.GetLength();
	this->currentForRerLinks = rerLinks.GetCurrent()->GetObject();






	LinkedList<Rer*>::Node* rerLinksNodeLink = this->rerLinks.GetCurrent();
	DateIndexes<LinkedList<Rer*>::Node*>::Node* dateRerLinkIndexesNodeLink = this->currentForDateRerLinkIndexes;


	// ���� ���� �����̰ų�, ������ ������ ���ʷ� ���� ��
	if (dateRerLinkIndexesNodeLink == 0
		|| dateRerLinkIndexesNodeLink->GetDate()->IsNotEqual(Date::Today()))
	{
		// �� ���� ��带 �����
		this->dateRerLinkIndexes.AppendFromTail(rerLinksNodeLink, rerLinksNodeLink);
		this->lengthForDateRerLinkIndexes = this->dateRerLinkIndexes.GetLength();
		this->currentForDateRerLinkIndexes = this->dateRerLinkIndexes.GetCurrent();
	}
	else
	{ // ���ο� tail�� ���� ���� ġȯ��Ų��
		int length = dateRerLinkIndexesNodeLink->GetLength() + 1;
		*dateRerLinkIndexesNodeLink = DateIndexes<LinkedList<Rer*>::Node*>::Node(dateRerLinkIndexesNodeLink->GetStartDateLink(), rerLinksNodeLink, Date::Today(), length);
	}




	return newRerLink;
}

RRequest* Area::RecordRRequest(Rer *rer, Long RType, Long pickUpType, Date rerPickUpDate)
{
	RRequest newRRequest(rer, this, this->pickerLink, RType, pickUpType, rerPickUpDate);
	RRequest* rRequestLink = &(this->rRequests.AppendFromTail(newRRequest)->GetObject());
	this->lengthForRRequests = this->rRequests.GetLength();
	this->currentForRRequests = &(this->rRequests.GetCurrent()->GetObject());









	LinkedList<RRequest>::Node* rRequestNodeLink = this->rRequests.GetCurrent();
	DateIndexes<LinkedList<RRequest>::Node*>::Node* dateRRequestIndexesNodeLink = this->currentForDateRRequestIndexes;


	// ���� ���� �����̰ų�, ������ ������ ���ʷ� ���� ��
	if (dateRRequestIndexesNodeLink == 0
		|| dateRRequestIndexesNodeLink->GetDate()->IsNotEqual(Date::Today()))
	{
		// �� ���� ��带 �����
		this->dateRRequestIndeses.AppendFromTail(rRequestNodeLink, rRequestNodeLink);
		this->lengthForDateRRequeseIndexes = this->dateRRequestIndeses.GetLength();
		this->currentForDateRRequestIndexes = this->dateRRequestIndeses.GetCurrent();
	}
	else
	{ // ���ο� tail�� ���� ���� ġȯ��Ų��
		int length = dateRRequestIndexesNodeLink->GetLength() + 1;
		*dateRRequestIndexesNodeLink = DateIndexes<LinkedList<RRequest>::Node*>::Node(dateRRequestIndexesNodeLink->GetStartDateLink(), rRequestNodeLink, Date::Today(), length);
	}








	return rRequestLink;
}

RRequest* Area::FindRRequestLink(string rRequestId)
{
	RRequest *rRequestLink = 0;
	LinkedList<RRequest>::Node* nodeLink = this->rRequests.LinearSearchUnique(&rRequestId, CompareRRequestLinkIds);
	if (nodeLink != 0)
	{
		rRequestLink = &(nodeLink->GetObject());
	}
	return rRequestLink;
}




RRequest* Area::RecordRRequest(
	string rRequestId,

	Long RType,
	Long pickUpType,

	Long isCancelledInt,
	Long isTakenByPickerInt,

	Long yearForRerPickUpDate,
	Long monthForRerPickUpDate,
	Long dayForRerPickUpDate,
	Long weekDayForRerPickUpDate,
	Long hourForRerPickUpDate,
	Long minForRerPickUpDate,
	Long secForRerPickUpDate,

	Long yearForPickerPickUpDate,
	Long monthForPickerPickUpDate,
	Long dayForPickerPickUpDate,
	Long weekDayForPickerPickUpDate,
	Long hourForPickerPickUpDate,
	Long minForPickerPickUpDate,
	Long secForPickerPickUpDate,

	Long yearForRerRequestDate,
	Long monthForRerRequestDate,
	Long dayForRerRequestDate,
	Long weekDayForRerRequestDate,
	Long hourForRerRequestDate,
	Long minForRerRequestDate,
	Long secForRerRequestDate,

	Long rerRPointValue,
	Long pickerRPointValue,

	Long paperWeight,
	Long plasticWeight,
	Long glassBottleWeight,
	Long customGroupWeight,

	Long clothesWeight,
	Long steelWeight,
	Long wireWeight,

	Long stainlessWeight,
	Long copperWeight,

	Long totalWeight,

	string electronics,
	string electronicsDescription,

	Rer* rerLink,
	Picker* pickerLink
	)
{
	RRequest newRRequest(
			rerLink,
			pickerLink,
			this,

			rRequestId,

			RType,
			pickUpType,

			isCancelledInt,
			isTakenByPickerInt,

			yearForRerPickUpDate,
			monthForRerPickUpDate,
			dayForRerPickUpDate,
			weekDayForRerPickUpDate,
			hourForRerPickUpDate,
			minForRerPickUpDate,
			secForRerPickUpDate,

			yearForPickerPickUpDate,
			monthForPickerPickUpDate,
			dayForPickerPickUpDate,
			weekDayForPickerPickUpDate,
			hourForPickerPickUpDate,
			minForPickerPickUpDate,
			secForPickerPickUpDate,

			yearForRerRequestDate,
			monthForRerRequestDate,
			dayForRerRequestDate,
			weekDayForRerRequestDate,
			hourForRerRequestDate,
			minForRerRequestDate,
			secForRerRequestDate,

			rerRPointValue,
			pickerRPointValue,

			paperWeight, // ����
			plasticWeight, // �ö�ƽ
			glassBottleWeight, // ��
			customGroupWeight, // ���� = �⵿���  =   ĵ, ö ���

			clothesWeight, // ��
			steelWeight, // ö
			wireWeight, // ��

			stainlessWeight, // �����θ��� = ����
			copperWeight, // ���� = ��

			totalWeight,

			electronics,
			electronicsDescription
		);

	RRequest* rRequestLink = &(this->rRequests.AppendFromTail(newRRequest)->GetObject());
	this->lengthForRRequests = this->rRequests.GetLength();
	this->currentForRRequests = &(this->rRequests.GetCurrent()->GetObject());

	return rRequestLink;

}




















Rer* Area::RerLinkFirst()
{
	Rer* rerLink = this->rerLinks.First()->GetObject();
	return rerLink;
}
Rer* Area::RerLinkPrevious()
{
	Rer* rerLink = this->rerLinks.Previous()->GetObject();
	return rerLink;
}
Rer* Area::RerLinkNext()
{
	Rer* rerLink = this->rerLinks.Next()->GetObject();
	return rerLink;
}
Rer* Area::RerLinkLast()
{
	Rer* rerLink = this->rerLinks.Last()->GetObject();
	return rerLink;
}






RRequest* Area::FirstForRRequest()
{
	RRequest* rRequest = 0;
	LinkedList<RRequest>::Node* nodeLink = this->rRequests.First();
	if (nodeLink != 0)
	{
		rRequest = &(nodeLink->GetObject());
	}
	return rRequest;
}
RRequest* Area::PreviousForRRequest()
{
	RRequest* rRequest = &(this->rRequests.Previous()->GetObject());
	return rRequest;
}
RRequest* Area::NextForRRequest()
{
	RRequest* rRequest = &(this->rRequests.Next()->GetObject());
	return rRequest;
}
RRequest* Area::LastForRRequest()
{
	RRequest* rRequest = &(this->rRequests.Last()->GetObject());
	return rRequest;
}

Long CompareRRequestLinkIds(void* one, void* other)
{
	Long ret;
	ret = (((RRequest*)one)->GetId()).compare(*((string*)(other)));
	return ret;
}









/*
LinkedList<Rer*>::Node* Area::RegisterRerLinkNode(Rer* rerLink)
{
	return this->rerLinks.AppendFromTail(rerLink);
}//*/