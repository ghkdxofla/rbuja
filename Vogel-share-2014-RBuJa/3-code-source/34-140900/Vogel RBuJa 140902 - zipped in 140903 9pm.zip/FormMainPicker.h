//FormMainPicker.h

#ifndef _FORMMAINPICKER_H
#define _FORMMAINPICKER_H

#include "resource.h"
#include "LibBinaryTree - added in 140725.h"
#include <afxwin.h>
#include "afxcmn.h"

class Picker;
class RBuJa;

class FormMainPicker : public CDialog
{
public:
	enum { IDD = IDD_M5_PICKER};
public:
	FormMainPicker(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();
	virtual void DoDataExchange(CDataExchange* pDX);

public: // ����� �������̵�
	virtual void OnOK(); // EnterŰ â �ڵ����� ����
	virtual void OnCancel(); // ESCŰ â �ڵ����� ����

public: // List��
	CWnd* pickerList;
	RBuJa* rBuJa;

public: // Display
	void RefreshAllData();
	void DisplayStatics();
	void DisplayPickerList();
	void DisplayPickerAreaList();
	void DisplayAreaList();
	// void DisplayPickerListForBinary(BinaryTree<Picker>::Node* nodeLink, Long *index);

public: // Hide
	void HideGroups();
	void HideFindGroup();
	void HideAssignGroup();
	void HideWageGroup();

protected:

	// SideMenuButtons
	afx_msg void OnMainSAreaButtonClicked();
	afx_msg void OnMainRResourceButtonClicked();
	afx_msg void OnMainRValueButtonClicked();
	afx_msg void OnMainRerButtonClicked();
	afx_msg void OnMainPickerButtonClicked();
	afx_msg void OnRefreshButtonClicked();
	afx_msg void OnSettingButtonClicked();

	// Buttons
	afx_msg void OnMakePickerButtonClicked();
	afx_msg void OnFindPickerButtonClicked();
	afx_msg void OnModifyPickerButtonClicked();
	afx_msg void OnAssignPickerButtonClicked();
	afx_msg void OnPickerWageButtonClicked();

	// LVC
	afx_msg void OnPickerListViewItemDoubleClicked(NMHDR* pNotifyStruct, LRESULT* result);

	// ShowWindow
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);

	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
public:
	CStatic ms_functionName;
	CEdit me_findPicker;
	CButton mb_findPickerfind;
	CButton mb_findPickerCancel;
	CListCtrl ml_findPicker;
	CStatic mp_functionDefault;
	afx_msg void OnBnClickedM5bFindpickerfind();
	afx_msg void OnNMDblclkM5lPicker2(NMHDR *pNMHDR, LRESULT *pResult);
	CListCtrl ml_areaList;
	CListCtrl ml_pickerAreaList;
	CButton mb_addArea;
	CButton mb_deleteArea;
	CStatic ms_pickerName;
	CStatic ms_pickerID;
	afx_msg void OnBnClickedM5bAdd();
	afx_msg void OnBnClickedM5bDelete();
	CStatic ms_name;
	CStatic ms_id;
	CStatic mg_pickerinfo;
	CStatic mg_areaList;
	CStatic mg_pickerAreaList;
	afx_msg void OnNMClickM5lPicker(NMHDR *pNMHDR, LRESULT *pResult);
};


#endif