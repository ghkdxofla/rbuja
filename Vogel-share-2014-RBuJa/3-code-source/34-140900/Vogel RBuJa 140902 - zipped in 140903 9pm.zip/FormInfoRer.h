//FormInfoRer.h

#ifndef _FORMINFORER_H
#define _FORMINFORER_H
#include "Rer.h"
#include "resource.h"
#include <afxwin.h>

class FormInfoRer : public CDialog
{
public:
	enum { IDD = IDD_N1_INFORER};
public:
	FormInfoRer(CWnd* rerList, CWnd *parent = NULL);
	virtual BOOL OnInitDialog();
	virtual void OnOK(); // EnterŰ â �ڵ����� ������ ���� �������̵�

public: // List
	CWnd* parentRerList;
	CWnd* rRequestList;

public: // Display
	void DisplayRRequestList(Rer* rerLink);

protected:

	// ID_BUTTON_OK
	afx_msg void OnOKButtonClicked();

	afx_msg void OnModifyButtonClicked();
	afx_msg void OnMakeRRequestButtonClicked();

	afx_msg void OnClose();


	DECLARE_MESSAGE_MAP()
};


#endif