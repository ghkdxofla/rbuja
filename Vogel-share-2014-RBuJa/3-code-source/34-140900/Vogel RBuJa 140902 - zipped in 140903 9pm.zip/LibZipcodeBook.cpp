// ZipcodeBook.cpp

#include "LibZipcodeBook.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


ZipcodeBook::ZipcodeBook(Long capacity)
{
	this->addresses = Array<Address>(capacity);
	this->capacity = capacity;
	this->length = 0;
}

ZipcodeBook::ZipcodeBook(const ZipcodeBook& source)
{
	this->addresses = Array<Address>(source.capacity);
	this->capacity = source.capacity;
	this->length = source.length;
}

ZipcodeBook::~ZipcodeBook() {}

ZipcodeBook& ZipcodeBook::operator=(const ZipcodeBook& source)
{
	this->addresses = source.addresses;
	this->capacity = source.capacity;
	this->length = source.length;
	return *this;
}

Long ZipcodeBook::Load() {
	Address address;
	char line[256];
	char temp[9][64];
	Long count = 0;
	Long i = 0;
	Long j;
	Long k;
	Long l;
	FILE *file;

	fopen_s(&file, "ZipcodeBook.txt", "rt");
	if (file != NULL) {

		fgets(line, 256, file);
		fgets(line, 256, file);

		while (!feof(file)) {

			j = 0;
			k = 0;
			l = 0;
			while (line[j] != '\0') {
				if (line[j] != '\t' && line[j] != '\n') {
					temp[k][l] = line[j];
					l++;
				}
				else {
					temp[k][l] = '\0';
					k++;
					l = 0;
				}

				j++;
			}
			// $$
			address = Address(
				string(temp[0]),
				string(temp[1]),
				string(temp[2]),
				string(temp[3]),
				string(temp[4]),
				string(temp[5]),
				string(temp[6]),
				string(temp[7]),
				string(temp[8]),
				"");

			if (this->length < this->capacity) {
				this->addresses.Store(i, address);
			}
			else {
				this->addresses.AppendFromRear(address);
				this->capacity++;
			}
			this->length++;
			count++;

			i++;

			fgets(line, 256, file);
		}

		fclose(file);
	}

	return count;
}


Long ZipcodeBook::Load(CProgressCtrl* m_ctrPro) {
	Address address;
	char line[256];
	char temp[9][64];
	Long count = 0;
	Long i = 0;
	Long j;
	Long k;
	Long l;
	FILE *file;

	fopen_s(&file, "ZipcodeBook.txt", "rt");
	if (file != NULL) {


		/// ProgressBar ó��

		// CtrPro ����
		m_ctrPro->SetRange(0, 100); //�������� ����
		m_ctrPro->SetStep(1); //�󸶾� ������ �������� ����
		Long percentage = 10;
		m_ctrPro->SetPos(percentage);
		Sleep(2000); //��������(1000�� ������ 1�� delay)



		fgets(line, 256, file);
		fgets(line, 256, file);

		while (!feof(file)) {

			// CtrProǥ��
			percentage = this->length / this->capacity * 100;
			m_ctrPro->SetPos(percentage);

			j = 0;
			k = 0;
			l = 0;
			while (line[j] != '\0') {
				if (line[j] != '\t' && line[j] != '\n') {
					temp[k][l] = line[j];
					l++;
				}
				else {
					temp[k][l] = '\0';
					k++;
					l = 0;
				}

				j++;
			}
			// $$
			address = Address(
				string(temp[0]),
				string(temp[1]),
				string(temp[2]),
				string(temp[3]),
				string(temp[4]),
				string(temp[5]),
				string(temp[6]),
				string(temp[7]),
				string(temp[8]),
				"");

			if (this->length < this->capacity) {
				this->addresses.Store(i, address);
			}
			else {
				this->addresses.AppendFromRear(address);
				this->capacity++;
			}
			this->length++;
			count++;

			i++;

			fgets(line, 256, file);
		}

		fclose(file);
	}
	else
	{
		// ������ȣ�� ������ �����ϴ�
	}

	return count;
}

void ZipcodeBook::Find(string dong, Long *(*indexes), Long *count)
{
	this->addresses.LinearSearchDuplicate(&dong, indexes, count, CompareDongs);
}
