#include "FormMakeRer.h"
#include "FormLogin.h"
#include "FormFindingAddress.h"

#include <afxcmn.h>

BEGIN_MESSAGE_MAP( FormMakeRer, CDialog )
	
	ON_WM_CHAR()
	
	ON_BN_CLICKED(IDC_K1B_OK, OnOKButtonClicked)
	ON_BN_CLICKED(IDC_K1B_CANCEL, OnClose)
	ON_BN_CLICKED(IDC_K1B_FINDADDRESS, OnFindingAddressButtonclicked)


	ON_WM_CLOSE()
END_MESSAGE_MAP()

FormMakeRer::FormMakeRer( CWnd *parent )
	:CDialog( FormMakeRer::IDD, parent )
{
	
}

BOOL FormMakeRer::OnInitDialog() 
{
	CDialog::OnInitDialog() ;
	return FALSE;
}

void FormMakeRer::OnOK()
{
	OnOKButtonClicked();
}



void FormMakeRer::OnOKButtonClicked()
{
	// ȸ������ ���� �����ͼ� ControlRer�� �����ϱ�
	CString id = "";
	CString pw = "";
	
	CString name = "";
	CString phoneFirst = "";
	CString phoneMiddle = "";
	CString phoneLast = "";

	CString addressId = "";
	CString addressDetail = "";
	
	this->GetDlgItem( IDC_K1E_ID )->GetWindowText( id );
	this->GetDlgItem( IDC_K1E_PW)->GetWindowText( pw );
	
	this->GetDlgItem(IDC_K1E_NAME)->GetWindowText(name);
	this->GetDlgItem( IDC_K1E_PHONEFIRST)->GetWindowText( phoneFirst );
	this->GetDlgItem( IDC_K1E_PHONEMIDDLE)->GetWindowText( phoneMiddle );
	this->GetDlgItem( IDC_K1E_PHONELAST)->GetWindowText( phoneLast );

	this->GetDlgItem( IDC_K1E_ADDRESSID)->GetWindowText( addressId );
	this->GetDlgItem( IDC_K1E_ADDRESSSPECIFIC)->GetWindowText( addressDetail );

	
	FormMainSArea *formMainSArea = (FormMainSArea*)GetParent();

	CString phoneTotal = phoneFirst + phoneMiddle + phoneLast;
	string temp = " ";
	CString addressTotal = addressId+ temp.c_str() + addressDetail;

	// ȸ������ ���� �����ͼ� ControlRer�� �����ϱ� �Ϸ�
	formMainSArea->rBuJa->RegisterNewRer(addressId.GetBuffer(0), id.GetBuffer(0), pw.GetBuffer(0), name.GetBuffer(0), phoneTotal.GetBuffer(0), addressTotal.GetBuffer(0));
		
	EndDialog(0);
}

//*/

void FormMakeRer::OnFindingAddressButtonclicked()
{
	FormFindingAddress formFindingAddress(this);
	formFindingAddress.DoModal();
}


/*
void FormMakeRer::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	switch (nChar)	
	{
	case VK_RETURN:

	}

}//*/


void FormMakeRer::OnClose() 
{
	EndDialog(0);
}