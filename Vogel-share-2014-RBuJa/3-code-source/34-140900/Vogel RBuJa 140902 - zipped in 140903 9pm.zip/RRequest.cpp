// RRequest.cpp
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		RRequest.cpp
��������:		140627
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#include "RRequest.h"
 
#include <sstream> 

RRequest::RRequest()
{
	
	
	this->rerLink = 0;
	this->pickerLink = 0;
	this->areaLink = 0;

	this->rerPickUpDate = Date();
	this->pickerPickUpDate = Date();
	this->RerRequestDate = Date::Today();
	





	this->RType = -1;
	this->pickUpType = -1;

	this->isCancelled = false;
	this->isTakenByPicker = false;
	



	this->r = R();
	this->rRequestId = "";

	this->rerRPointValue = 0;
	this->pickerRPointValue = 0;
}

RRequest::RRequest(Rer *rer, Area *area, Picker *picker, Long RType, Long pickUpType, Date rerPickUpDate)
{
	this->rerLink = rer;
	this->pickerLink = picker;
	this->areaLink = area;

	this->rerPickUpDate = rerPickUpDate;
	this->pickerPickUpDate = Date();
	this->RerRequestDate = Date::Today();




	this->RType = RType;
	this->pickUpType = pickUpType;

	this->isCancelled = false;
	this->isTakenByPicker = false;



	this->r = R();

	string temp = "";
	ostringstream convert;
	convert << this->RerRequestDate.GetYear();
	convert << this->RerRequestDate.GetMonth();
	convert << this->RerRequestDate.GetDay();
	convert << this->RerRequestDate.GetHour();
	convert << this->RerRequestDate.GetMin();
	convert << this->RerRequestDate.GetSec();

	temp = convert.str(); // int i -> string temp
	this->rRequestId = rer->GetId() + " " + temp;


	this->rerRPointValue = 0;
	this->pickerRPointValue = 0;
}

/*
RRequest::RRequest(Date idAndRerRequestDate)
{
	

	this->rerLink = 0;
	this->pickerLink = 0;
	this->zoneLink = 0;
	this->rCenterLink = 0;
	this->rLink = 0;

	this->RType = -1;
	this->pickUpType = -1;

	this->RerRequestDate = idAndRerRequestDate;
	this->rerPickUpDate = Date();
	this->pickerPickUpDate = Date();

	this->isCancelled = false;
	this->isTakenByPicker = false;

	this->rRequestId = "";
}

RRequest::RRequest(Rer* rerLink, Date rerPickUpDate)
{
	
	this->rerLink = rerLink;
	this->pickerLink = 0;
	this->zoneLink = 0;
	this->rCenterLink = 0;
	this->rLink = 0;

	this->RType = -1;
	this->pickUpType = -1;

	this->RerRequestDate = Date::Today();
	this->rerPickUpDate = rerPickUpDate;
	this->pickerPickUpDate = Date();

	this->isCancelled = false;
	this->isTakenByPicker = false;

	this->rRequestId = "";

}
//*/








RRequest::RRequest(
	Rer* rerLink,
	Picker* pickerLink,
	Area* areaLink,

	string rRequestId,

	Long RType,
	Long pickUpType,

	Long isCancelledInt,
	Long isTakenByPickerInt,

	Long yearForRerPickUpDate,
	Long monthForRerPickUpDate,
	Long dayForRerPickUpDate,
	Long weekDayForRerPickUpDate,
	Long hourForRerPickUpDate,
	Long minForRerPickUpDate,
	Long secForRerPickUpDate,

	Long yearForPickerPickUpDate,
	Long monthForPickerPickUpDate,
	Long dayForPickerPickUpDate,
	Long weekDayForPickerPickUpDate,
	Long hourForPickerPickUpDate,
	Long minForPickerPickUpDate,
	Long secForPickerPickUpDate,

	Long yearForRerRequestDate,
	Long monthForRerRequestDate,
	Long dayForRerRequestDate,
	Long weekDayForRerRequestDate,
	Long hourForRerRequestDate,
	Long minForRerRequestDate,
	Long secForRerRequestDate,

	Long rerRPointValue,
	Long pickerRPointValue,

	Long paperWeight, // ����
	Long plasticWeight, // �ö�ƽ
	Long glassBottleWeight, // ��
	Long customGroupWeight, // ���� = �⵿���  =   ĵ, ö ���

	Long clothesWeight, // ��
	Long steelWeight, // ö
	Long wireWeight, // ��

	Long stainlessWeight, // �����θ��� = ����
	Long copperWeight, // ���� = ��

	Long totalWeight,

	string electronics,
	string electronicsDescription
	)
{
	this->rerLink = rerLink;
	this->pickerLink = pickerLink;
	this->areaLink = areaLink;


	Date rerPickUpDate(yearForRerPickUpDate, monthForRerPickUpDate, dayForRerPickUpDate, weekDayForRerPickUpDate, hourForRerPickUpDate, minForRerPickUpDate, secForRerPickUpDate);
	this->rerPickUpDate = rerPickUpDate;


	Date pickerPickUpDate(yearForPickerPickUpDate, monthForPickerPickUpDate, dayForPickerPickUpDate, weekDayForPickerPickUpDate, hourForPickerPickUpDate, minForPickerPickUpDate, secForPickerPickUpDate);
	this->pickerPickUpDate = pickerPickUpDate;



	Date RerRequestDate(yearForRerRequestDate, monthForRerRequestDate, dayForRerRequestDate, weekDayForRerRequestDate, hourForRerRequestDate, minForRerRequestDate, secForRerRequestDate);
	this->RerRequestDate = RerRequestDate;




	this->RType = RType;
	this->pickUpType = pickUpType;




	if (isCancelledInt == 1)
	{
		this->isCancelled = true;
	}
	else
	{
		this->isCancelled = false;
	}


	if (isTakenByPickerInt == 1)
	{
		this->isTakenByPicker = true;
	}
	else
	{
		this->isTakenByPicker = false;
	}




	this->r = R(
		paperWeight, // ����
		plasticWeight, // �ö�ƽ
		glassBottleWeight, // ��
		customGroupWeight, // ���� = �⵿���  =   ĵ, ö ���

		clothesWeight, // ��
		steelWeight, // ö
		wireWeight, // ��

		stainlessWeight, // �����θ��� = ����
		copperWeight, // ���� = ��

		totalWeight,

		electronics,
		electronicsDescription
		);


	this->rRequestId = rRequestId;


	this->rerRPointValue = rerRPointValue;
	this->pickerRPointValue = pickerRPointValue;

}


RRequest::RRequest(const RRequest& source)
{
	
	this->rerLink = source.rerLink;
	this->pickerLink = source.pickerLink;
	this->areaLink = source.areaLink;
	
	this->rerPickUpDate = source.rerPickUpDate;
	this->pickerPickUpDate = source.pickerPickUpDate;
	this->RerRequestDate = source.RerRequestDate;




	this->RType = source.RType;
	this->pickUpType = source.pickUpType;

	this->isCancelled = source.isCancelled;
	this->isTakenByPicker = source.isTakenByPicker;




	this->r = source.r;
	this->rRequestId = source.rRequestId;

	this->rerRPointValue = source.rerRPointValue;
	this->pickerRPointValue = source.pickerRPointValue;
}

RRequest::~RRequest() {}

RRequest& RRequest::operator=(const RRequest& source)
{
	
	this->rerLink = source.rerLink;
	this->pickerLink = source.pickerLink;
	this->areaLink = source.areaLink;

	this->rerPickUpDate = source.rerPickUpDate;
	this->pickerPickUpDate = source.pickerPickUpDate;
	this->RerRequestDate = source.RerRequestDate;





	this->RType = source.RType;
	this->pickUpType = source.pickUpType;

	this->isCancelled = source.isCancelled;
	this->isTakenByPicker = source.isTakenByPicker;





	this->r = source.r;
	this->rRequestId = source.rRequestId;


	this->rerRPointValue = source.rerRPointValue;
	this->pickerRPointValue = source.pickerRPointValue;
	
	return *this;
}





R RRequest::RecordR(
	Long paperWeight,
	Long plasticWeight,
	Long glassBottleWeight,
	Long customGroupWeight,

	Long clothesWeight,
	Long steelWeight,
	Long wireWeight,

	Long stainlessWeight,
	Long copperWeight,

	string electronics,
	string electronicsDescription)
{
	R newR(
		paperWeight,
		plasticWeight,
		glassBottleWeight,

		customGroupWeight, 
		clothesWeight,
		steelWeight,
		wireWeight,

		stainlessWeight,
		copperWeight,
		electronics,

		electronicsDescription
		);
		
		
	this->r = newR;

	this->isTakenByPicker = true;

	return this->r;
}

Long RRequest::RecordRerRPointValue(R* r, RValue* rerRValue)
{
	Long rerRPointValue =
		(r->GetPaperWeight() * rerRValue->GetPaperValue()) +
		(r->GetPlasticWeight() * rerRValue->GetPlasticValue()) +
		(r->GetCustomGroupWeight() * rerRValue->GetCustomGroupValue()) +

		(r->GetClothesWeight() * rerRValue->GetClothesValue()) +
		(r->GetSteelWeight() * rerRValue->GetSteelValue()) +
		(r->GetWireWeight() * rerRValue->GetWireValue()) +

		(r->GetStainlessWeight() * rerRValue->GetStainlessValue()) +
		(r->GetCopperWeight() * rerRValue->GetCopperValue());

	this->rerRPointValue = rerRPointValue;
	return 	this->rerRPointValue;
}

Long RRequest::RecordPickerRPointValue(R* r, RValue* pickerRValue)
{
	Long pickerRPointValue =
		(r->GetPaperWeight() * pickerRValue->GetPaperValue()) +
		(r->GetPlasticWeight() * pickerRValue->GetPlasticValue()) +
		(r->GetCustomGroupWeight() * pickerRValue->GetCustomGroupValue()) +

		(r->GetClothesWeight() * pickerRValue->GetClothesValue()) +
		(r->GetSteelWeight() * pickerRValue->GetSteelValue()) +
		(r->GetWireWeight() * pickerRValue->GetWireValue()) +

		(r->GetStainlessWeight() * pickerRValue->GetStainlessValue()) +
		(r->GetCopperWeight() * pickerRValue->GetCopperValue());

	this->pickerRPointValue = pickerRPointValue;

	return this->pickerRPointValue;
}


RRequest* RRequest::PickUpComplete()
{
	this->pickerPickUpDate = Date::Today();
	this->isTakenByPicker = true;

	return this;
}

/*
void RRequest::RerCancelledRRequest()
{
	// RRequest�� Rer ���� ��� flag�� true�� �ٲ۴�,
	this->isCancelled = true;
}



RRequest* RRequest::PickUpComplete(R* rLink)
{
	this->pickerPickUpDate = Date::Today();
	this->rLink = rLink;
	this->isTakenByPicker = true;

	return this;
}
//*/