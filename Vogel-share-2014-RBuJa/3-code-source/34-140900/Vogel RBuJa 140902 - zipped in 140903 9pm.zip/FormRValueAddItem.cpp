#include "FormRValueAddItem.h"
#include "FormLogin.h"

#include "FormMainRValue.h"

#include <afxcmn.h>

BEGIN_MESSAGE_MAP(FormRValueAddItem, CDialog)

	ON_BN_CLICKED(IDC_V1B_SET, OnOKButtonClicked)
	ON_BN_CLICKED(IDC_V1B_CANCEL, OnClose)

	ON_WM_CLOSE()
END_MESSAGE_MAP()

FormRValueAddItem::FormRValueAddItem(int formType, CWnd *parent, RValue* rerRValueLink, RValue* pickerRValueLink)
:CDialog(FormRValueAddItem::IDD, parent)
{
	this->formType = formType;
	this->rerRValueLink = rerRValueLink;
	this->pickerRValueLink = pickerRValueLink;
}

BOOL FormRValueAddItem::OnInitDialog()
{
	CDialog::OnInitDialog();

	/// Setting - SetTextLimit ///
	((CEdit*)GetDlgItem(IDC_V1E_CODE))->SetLimitText(7);
	((CEdit*)GetDlgItem(IDC_V1E_VALUE))->SetLimitText(7);
	((CEdit*)GetDlgItem(IDC_V1E_VALUE2))->SetLimitText(7);

	// �θ� â�� LVC �ּҸ� �Ӽ����� �����Ѵ�.
	this->generalList = ((FormMainRValue*)GetParent())->GetDlgItem(IDC_M3L_GENERAULRVALUE);
	this->electronicsList = ((FormMainRValue*)GetParent())->GetDlgItem(IDC_M3L_ELECTRONICSRVALUE);

	switch (this->formType)
	{
	case 1: // Set General
		// SettingForSetGeneralValues();
		break;

	case 2: // Set Electronics
		SettingForSetElectronicsValues();
		break;

	case 3: // Add Electronics Item
		SettingForAddElectronicsItem();
		break;

	default:
		break;
	}

	return FALSE;
}

void FormRValueAddItem::OnOK()
{
	OnOKButtonClicked();
}

BOOL FormRValueAddItem::PreTranslateMessage(MSG* pMsg)
{
	// TODO: Add your specialized code here and/or call the base class

	CEdit* edit = ((CEdit*)GetDlgItem(IDC_V1E_CODE));

	if (pMsg->message == WM_LBUTTONDOWN
		&& pMsg->hwnd == edit->m_hWnd
		&& GetFocus()->m_hWnd != edit->m_hWnd)
	{
		edit->SetFocus();
		edit->SetSel(0, -1, true);
		return true;
	}

	edit = ((CEdit*)GetDlgItem(IDC_V1E_VALUE));

	if (pMsg->message == WM_LBUTTONDOWN
		&& pMsg->hwnd == edit->m_hWnd
		&& GetFocus()->m_hWnd != edit->m_hWnd)
	{
		edit->SetFocus();
		edit->SetSel(0, -1, true);
		return true;
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}








/*

			Setting

*/

void FormRValueAddItem::SettingForSetGeneralValues()
{
	/*
	// �θ� â���� ���õ� �׸��� �о� ���� â�� ����Ѵ�.
	int selectedIndex = ((CListCtrl*)this->generalList)->GetSelectionMark();

	// Code
	CString code = ((CListCtrl*)this->generalList)->GetItemText(selectedIndex, 1);
	GetDlgItem(IDC_V1E_CODE)->SetWindowTextA(code);
	// �б� �������� Edit Control�� �����Ѵ�.
	((CEdit*)GetDlgItem(IDC_V1E_CODE))->SetReadOnly();

	// Value
	CString value = ((CListCtrl*)this->generalList)->GetItemText(selectedIndex, 2);
	GetDlgItem(IDC_V1E_VALUE)->SetWindowTextA(value);
	CString value2 = ((CListCtrl*)this->generalList)->GetItemText(selectedIndex, 3);
	GetDlgItem(IDC_V1E_VALUE2)->SetWindowTextA(value2);
	
	// ��Ŀ�� ����
	GetDlgItem(IDC_V1E_VALUE)->SetFocus();
	*/
}

void FormRValueAddItem::SettingForSetElectronicsValues()
{
	// Static�� �ٲ۴�
	GetDlgItem(IDC_V1S_FIRST)->SetWindowTextA("�ü�");
	GetDlgItem(IDC_V1S_SECOND)->SetWindowTextA("");
	// �ι�° Edit â�� �����.
	GetDlgItem(IDC_V1E_VALUE2)->ShowWindow(SW_HIDE);

	// �θ� â���� ���õ� �׸��� �о� ���� â�� ����Ѵ�.
	int selectedIndex = ((CListCtrl*)this->electronicsList)->GetSelectionMark();

	// Code
	CString code = ((CListCtrl*)this->electronicsList)->GetItemText(selectedIndex, 1);
	GetDlgItem(IDC_V1E_CODE)->SetWindowTextA(code);
	// �б� �������� Edit Control�� �����Ѵ�.
	((CEdit*)GetDlgItem(IDC_V1E_CODE))->SetReadOnly();

	// Value
	CString value = ((CListCtrl*)this->electronicsList)->GetItemText(selectedIndex, 2);
	GetDlgItem(IDC_V1E_VALUE)->SetWindowTextA(value);

	// ��Ŀ�� ����
	GetDlgItem(IDC_V1E_VALUE)->SetFocus();
	((CEdit*)GetDlgItem(IDC_V1E_VALUE))->SetSel(0, -1);
	
} 

void FormRValueAddItem::SettingForAddElectronicsItem()
{
	// Static�� �ٲ۴�
	GetDlgItem(IDC_V1S_FIRST)->SetWindowTextA("�ü�");
	GetDlgItem(IDC_V1S_SECOND)->SetWindowTextA("");
	// �ι�° Edit â�� �����.
	GetDlgItem(IDC_V1E_VALUE2)->ShowWindow(SW_HIDE);

	// ��Ŀ�� ����
	GetDlgItem(IDC_V1E_CODE)->SetFocus();
}






void FormRValueAddItem::OnOKButtonClicked()
{
	CString code = "";
	CString value = "";
	CString value2 = "";
	switch (this->formType)
	{
	case 1: // Set Generals
		// Do Nothing
		break;

	case 2: // Set Electronics
		GetDlgItem(IDC_V1E_CODE)->GetWindowTextA(code);
		GetDlgItem(IDC_V1E_VALUE)->GetWindowTextA(value);
		rerRValueLink->ModifyElectronicsValueItem(code.GetBuffer(0), _ttoi(value));
		break;

	case 3: // Add Electronics Item
		GetDlgItem(IDC_V1E_CODE)->GetWindowTextA(code);
		GetDlgItem(IDC_V1E_VALUE)->GetWindowTextA(value);
		rerRValueLink->AddElectornicsValueItem(code.GetBuffer(0), _ttoi(value));
		break;

	default:
		break;
	}

	EndDialog(0);
}

void FormRValueAddItem::OnClose()
{
	EndDialog(0);
}