//FormMainRer.h

#ifndef _FORMMAINRER_H
#define _FORMMAINRER_H

#include "resource.h"
#include "LibBinaryTree - added in 140725.h"
#include <afxwin.h>

class Rer;

class FormMainRer : public CDialog
{
public:
	enum { IDD = IDD_M4_RER };
public:
	FormMainRer(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();

public: // ����� �������̵�
	virtual void OnOK(); // EnterŰ â �ڵ����� ����
	virtual void OnCancel(); // ESCŰ â �ڵ����� ����

public: // List��
	CWnd* rerList;

public: // Display
	void RefreshAllData();
	void DisplayRerList();
	// void DisplayRerListForBinary(BinaryTree<Rer>::Node* nodeLink, Long *index);
	void DisplayStatics();

protected:

	// SideMenuButtons
	afx_msg void OnMainSAreaButtonClicked();
	afx_msg void OnMainRResourceButtonClicked();
	afx_msg void OnMainRValueButtonClicked();
	afx_msg void OnMainRerButtonClicked();
	afx_msg void OnMainPickerButtonClicked();
	afx_msg void OnRefreshButtonClicked();
	afx_msg void OnSettingButtonClicked();

	// Buttons
	afx_msg void OnMakeRerButtonClicked();

	// LVC
	afx_msg void OnRerListViewItemDoubleClicked(NMHDR *pNotifyStruct, LRESULT *result);

	// ShowWindow
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);

	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
};


#endif