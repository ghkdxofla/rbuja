//FormMainPicker.h

#ifndef _FORMMAINPICKER_H
#define _FORMMAINPICKER_H

#include "resource.h"
#include "LibBinaryTree - added in 140725.h"
#include <afxwin.h>

class Picker;

class FormMainPicker : public CDialog
{
public:
	enum { IDD = IDD_M5_PICKER};
public:
	FormMainPicker(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();

public: // ����� �������̵�
	virtual void OnOK(); // EnterŰ â �ڵ����� ����
	virtual void OnCancel(); // ESCŰ â �ڵ����� ����

public: // List��
	CWnd* pickerList;

public: // Display
	void RefreshAllData();
	void DisplayStatics();
	void DisplayPickerList();
	// void DisplayPickerListForBinary(BinaryTree<Picker>::Node* nodeLink, Long *index);

protected:

	// SideMenuButtons
	afx_msg void OnMainSAreaButtonClicked();
	afx_msg void OnMainRResourceButtonClicked();
	afx_msg void OnMainRValueButtonClicked();
	afx_msg void OnMainRerButtonClicked();
	afx_msg void OnMainPickerButtonClicked();
	afx_msg void OnRefreshButtonClicked();
	afx_msg void OnSettingButtonClicked();

	// Buttons
	afx_msg void OnMakePickerButtonClicked();

	// LVC
	afx_msg void OnPickerListViewItemDoubleClicked(NMHDR* pNotifyStruct, LRESULT* result);

	// ShowWindow
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);

	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
};


#endif