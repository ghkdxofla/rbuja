//BinaryTree.h
/*
*/
#ifndef	_BINARYTREE_H
#define	_BINARYTREE_H

typedef	signed long int Long;
template <typename T>

class BinaryTree {

	public : class Node {
			friend class BinaryTree;

			public :
				//Constructor
				Node () { // ������ // left, right = 0
					this->left = 0;
					this->right = 0;
				}

				//ParameterConstructor
				Node ( T key) { // ������ // left, right = 0
					this->left = 0;
					this->right = 0;
					this->key = key;
				}

				//CopyConstructor
				Node ( const Node& source ) { // CopyConstructor. left, right Copy!!! // �ڽĵ鵵 ����
					this->key = source.key;
					
					if ( source.left != 0 ) {
						this->left = new Node ( *(source.left) );
					}
					else {
						this->left = 0;
					}
					if ( source.right != 0 ) {
						this->right = new Node ( *(source.right) );
					}
					else {
						this->right = 0;
					}
				}
				
				// Destructor
				~Node () { // Destructor // �ڽĵ鵵 �Բ� �ı�
					/*if( this != 0 )	{
						if( this->left != 0 )	{
							delete this->left;
						}
						if( this->right != 0 )	{
							delete this->right;
						}
					}//*/
				}

				//Operator ==
				Node&	operator = ( const Node& source ) { // �ڽĵ鵵 �Բ� ġȯ
					this->key = source.key;
					if ( source.left != 0 ) {
						this->left = new Node ( *(source.left) );
					}
					else {
						this->left = 0;
					}
					if ( source.right != 0 ) {
						this->right = new Node ( *(source.right) );
					}
					else {
						this->rigtht = 0;
					}
				}


void CopyToBuffer(T (*keys), Long *count){

	if(this != 0){

		this->left->CopyToBuffer(keys, count);

		keys[*count] = this->key;

		*count+=1;

		this->right->CopyToBuffer(keys, count);

	}

}

void DeleteAllItems(){

	if(this != 0){

		this->left->DeleteAllItems();

		this->right->DeleteAllItems();

		delete this;

	}

}

				static Node* MakeTree(T (*keys), Long first, Long last){

					Long middle;

					Node* node = 0;

					if(first<=last){

						middle = (first+last)/2;

						node = new Node(keys[middle]);

						node->left = MakeTree(keys, first, middle-1);

						node->right = MakeTree(keys, middle+1, last);

					}

					return node;

				}

				T&	GetKey () const
				{
					return	const_cast<T&> (this->key);
				}

				// GetLeft
				Node* GetLeft() const
				{
					return const_cast<Node*>(this->left);
				}

				// GetRight
				Node* GetRight() const
				{
					return const_cast<Node*>(this->right) ;
				}
				private :
					Node	*left;
					Node	*right;
					T		key;
			 };
	
	public :
		BinaryTree () ;
		BinaryTree ( const BinaryTree&	source ) ;
		~BinaryTree () ;
		
		Node*	Insert ( T key, Long (*compare)( void *, void * ) ) ;
		Node*	Search ( T key, Long (*compare)( void *, void * ) ) ;
		Node*	Delete ( T key, Long (*compare)( void *, void * ) ) ;

		void MakeBalance ( ) ; // Change OK  ==
		void CopyToBuffer(T *(*keys), Long *count); // Change OK
		void DeleteAllItems () ; // Change OK




		void MakeTree(T (*keys), Long count); // Chang OK
		
		BinaryTree&	operator = ( const BinaryTree&	source ) ;
		Node*	GetRoot () const ;
		Long	GetLength () const ;
		Long	GetBalance () const ;
	
	private :
		Node	*root ;
		Long	length ;
		Long	balance ;
} ;

template <typename T>
inline	Long	BinaryTree<T>::GetLength () const {
	return	this->length ;
}

template <typename T>
inline	Long	BinaryTree<T>::GetBalance () const {
	return	this->balance ;
}

template <typename T>
typename inline	BinaryTree<T>::Node*	BinaryTree<T>::GetRoot () const {
	return	const_cast<Node*>(this->root) ;
}

template <typename T>
BinaryTree<T>::BinaryTree() 
{
	this->root = 0 ;
	this->length =0 ;
	this->balance = 0 ;
}
//Constructor
template <typename T>
BinaryTree<T>::BinaryTree( const BinaryTree&	source ) 
{
	this->root = new Node ( *(source.root) ) ;
	this->length = source.length ;
	this->balance = source.balance ;
}

//Destructor
template <typename T>
BinaryTree<T>::~BinaryTree() 
{
	if ( this->root != 0 )  {
		delete this->root;
	}
}

//operator = 
template <typename T>
typename BinaryTree<T>&	BinaryTree<T>::operator = ( const BinaryTree& source )	{ 
	if ( this->root != 0 )	{
		delete this->root;
	}
	this->root = new Node ( *(source.root) );
	this->length = source.length;
	this->balance = source.balance;

	return *this;
}

//Insert
template <typename T>
typename BinaryTree<T>::Node*	BinaryTree<T>::Insert ( T key, Long (*compare)( void *, void * ) )
{
	Node *temp = this->root;
	Node *parent = 0;

	while ( temp != 0 ) {
		parent = temp;
		
		if ( compare ( &(temp->key), &key ) > 0 ) {
			temp = temp->left;
		}
		else {
			temp = temp->right;
		}
	}
	Node* current = new Node ( key );
	
	if ( this->root != 0 ) {
		if ( compare ( &(parent->key), &key ) > 0 ) {
			parent->left = current;
		}
		else {
			parent->right = current;
		}
		if ( compare ( &(this->root->key), &key ) > 0 ) {
			this->balance--;
		}
		else {
			this->balance++;
		}
	}
	else {
		this->root = current;
	}
	this->length++;
	
	return current;
}

//Delete
template <typename T>

typename BinaryTree<T>::Node* BinaryTree<T>::Delete(T key, Long (*compare)(void*, void *)){

    Node* keyIndex = 0;

    Node* keyParent = 0;

    Node* replaceIndex;

    Node* replaceParent;

    T root;

    
	if( this->root != 0 )
	{

		root = this->root->key;

		keyIndex = this->root;

		//Delete Index Search(keyIndex, KeyParent)

		while(compare(&(keyIndex->key), &key)!=0){

			keyParent = keyIndex;

			if(compare(&(keyIndex->key), &key)>0){

				keyIndex = keyIndex->left;

			}else{

				keyIndex = keyIndex->right;

			}

		}

		//Replace Index Search(replaceIndex, replaceParent)

		if(keyIndex->right != 0){

			replaceIndex = keyIndex->right;

			replaceParent = keyIndex;

			while (replaceIndex != 0 && replaceIndex->left != 0) {

				replaceParent = replaceIndex;

				replaceIndex = replaceIndex->left;

			}

		}else{

			replaceIndex = keyIndex->left;

			replaceParent = keyIndex;

			while (replaceIndex !=0 && replaceIndex->right != 0) {

				replaceParent = replaceIndex;

				replaceIndex = replaceIndex->right;

			}

		}

		//Node Connection

		if(replaceIndex != 0){

			if(keyIndex != replaceParent){

				if(compare(&(replaceIndex->key), &replaceParent->key)<0){

					replaceParent->left = replaceIndex->right;

				}else{

					replaceParent->right = replaceIndex->left;

				}

			}else{

				if(compare(&(replaceIndex->key), &replaceParent->key)<0){

					replaceParent->left = replaceIndex->left;

				}else{

					replaceParent->right = replaceIndex->right;

				}

			}

			replaceIndex->right = keyIndex->right;

			replaceIndex->left = keyIndex->left;

        

			if(keyParent != 0){

				if(compare(&(replaceIndex->key), &keyParent->key)<0){

					keyParent->left = replaceIndex;

				}else{

					keyParent->right = replaceIndex;

				}

			}else{

				this->root = replaceIndex;

			}

		}else{

			if(keyParent!=0){

				if(compare(&(keyIndex->key), &(keyParent->key))<0){

					keyParent->left = 0;

				}else{

					keyParent->right = 0;

				}

			}else{

				this->root = 0;

			}

		}

		//Key Index Delete

		if(keyIndex!=0){

			delete keyIndex;

			keyIndex = 0;

		}

		this->length--;

		//Balance Calcuate

		if(this->root != 0){

			if(compare(&root, &key)!=0){

				if(compare(&root, &key)>0){

					this->balance+=1;

				}else{

					this->balance-=1;

				}

			}else{

				if(compare(&root, &(replaceIndex->key))>0){

					this->balance+=1;

				}else{

					this->balance-=1;

				}

			}

		}

	}

    return keyIndex;

}




template <typename T>

typename BinaryTree<T>::Node*	BinaryTree<T>::Search ( T key, Long (*compare)( void *, void * ) )
{
	Node*	current = this->root;

	while ( current != 0 && compare ( &(current->key), &key ) != 0 ) {
		
		if ( compare ( &(current->key), &key ) > 0 ) {
			current = current->left;
		}
		else {
			current = current->right;
		}
	}
	return current;
}





//CopyToBuffer
	// Change OK
template <typename T>

void BinaryTree<T>::CopyToBuffer(T *(*keys), Long *count){

    *count = 0;

    *keys = new T[this->length];

    this->root->CopyToBuffer(*keys, count);

}


//DeleteAllItems	
	// Change OK
template <typename T>

void BinaryTree<T>::DeleteAllItems(){

    this->root->DeleteAllItems();

    this->root = 0;

    this->length = 0;

    this->balance = 0;

}
//MakeBalance
	// change OK
template <typename T>

void BinaryTree<T>::MakeBalance(){

    Long count;

    T (*keys);

    this->CopyToBuffer(&keys, &count);

    this->DeleteAllItems();

    this->MakeTree(keys, count);

    if(keys!=0){

        delete[] keys;

        keys = 0;

    }

}



//MakeTree
	// Change OK
template <typename T>

void BinaryTree<T>::MakeTree(T (*keys), Long count){

    this->root = Node::MakeTree(keys, 0, count-1);

    this->length = count;

    this->balance = (count-1)%2;

}








#endif //__BINARYTREE_H
			