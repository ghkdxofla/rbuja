#include "FormMainPicker.h"

#include "FormLogin.h"
#include "FormMakeRResource.h"


#include <afxcmn.h>

BEGIN_MESSAGE_MAP(FormMainPicker, CDialog)
	// SideMenuButton Events
	ON_BN_CLICKED(IDC_M5B_M1SAREA, OnMainSAreaButtonClicked)
	ON_BN_CLICKED(IDC_M5B_M2RRESOURCE, OnMainRResourceButtonClicked)
	ON_BN_CLICKED(IDC_M5B_M3RVALUE, OnMainRValueButtonClicked)
	ON_BN_CLICKED(IDC_M5B_M4RER, OnMainRerButtonClicked)
	ON_BN_CLICKED(IDC_M5B_M5PICKER, OnMainPickerButtonClicked)

	ON_BN_CLICKED(IDC_M5B_S1SETTING, OnSettingButtonClicked)

	ON_BN_CLICKED(IDC_M5B_REFRESH, OnRefreshButtonClicked)

	// Buttons
	ON_BN_CLICKED(IDC_M5B_MAKPICKER, OnMakePickerButtonClicked)

	// ON_NOTIFY - LVC DoubleClicked
	ON_NOTIFY(NM_DBLCLK, IDC_M5L_PICKER, OnPickerListViewItemDoubleClicked)

	// ShowWinodw
	ON_WM_SHOWWINDOW()

	ON_WM_CLOSE()
END_MESSAGE_MAP()

FormMainPicker::FormMainPicker(CWnd *parent)
:CDialog(FormMainPicker::IDD, parent)
{
	this->pickerList = 0;
}

BOOL FormMainPicker::OnInitDialog()
{
	CDialog::OnInitDialog();

	this->pickerList = GetDlgItem(IDC_M5L_PICKER);

	// ��� ����Ʈ�� IDC_M5L_PICKER ��� �ʱ�ȭ
	((CListCtrl*)this->pickerList)->InsertColumn(0, (LPCTSTR)"��ȣ", LVCFMT_CENTER, 50);
	((CListCtrl*)this->pickerList)->InsertColumn(1, (LPCTSTR)"ID", LVCFMT_CENTER, 80);
	((CListCtrl*)this->pickerList)->InsertColumn(2, (LPCTSTR)"����", LVCFMT_CENTER, 60);
	((CListCtrl*)this->pickerList)->InsertColumn(3, (LPCTSTR)"�ڵ���", LVCFMT_CENTER, 70);
	((CListCtrl*)this->pickerList)->InsertColumn(4, (LPCTSTR)"�� ����Ʈ", LVCFMT_CENTER, 110);
	((CListCtrl*)this->pickerList)->InsertColumn(5, (LPCTSTR)"���ƿ� ��", LVCFMT_CENTER, 110);

	((CListCtrl*)this->pickerList)->SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	// ����Ʈ�� ��Ʈ�� �׸����� �� �ְ� �ϱ�
	((CListCtrl*)this->pickerList)->SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);


	return FALSE;
}

void FormMainPicker::OnShowWindow(BOOL bShow, UINT nStatus)
{
	RefreshAllData();
}

void FormMainPicker::OnOK()
{
	// Do Nothing
}

void FormMainPicker::OnCancel()
{
	// �ݱ� â�� ����.
	FormClosing formClosing(this);
	formClosing.DoModal();
}


/*

SideMenuButton Events

*/

void FormMainPicker::OnMainSAreaButtonClicked()
{
	// â�� ������ �ʰ��ϰ�
	ShowWindow(SW_HIDE);
	// �θ� â�� �������� â�� ���̰� �Ѵ�.
	GetParent()->ShowWindow(SW_SHOW);
}

void FormMainPicker::OnMainRResourceButtonClicked()
{
	// â�� ������ �ʰ��ϰ�
	ShowWindow(SW_HIDE);
	// �������� â�� �Ӽ��� �ü� â�� ���̰� �Ѵ�.
	((FormMainSArea*)GetParent())->formMainRResource->ShowWindow(SW_SHOW);
}

void FormMainPicker::OnMainRValueButtonClicked()
{
	// â�� ������ �ʰ��ϰ�
	ShowWindow(SW_HIDE);
	// �������� â�� �Ӽ��� �ü� â�� ���̰� �Ѵ�.
	((FormMainSArea*)GetParent())->formMainRValue->ShowWindow(SW_SHOW);
}

void FormMainPicker::OnMainRerButtonClicked()
{
	// â�� ������ �ʰ��ϰ�
	ShowWindow(SW_HIDE);
	// �������� â�� �Ӽ��� �ü� â�� ���̰� �Ѵ�.
	((FormMainSArea*)GetParent())->formMainRer->ShowWindow(SW_SHOW);
}

void FormMainPicker::OnMainPickerButtonClicked()
{
	// Do Nothing
}

void FormMainPicker::OnRefreshButtonClicked()
{
	RefreshAllData();
}

void FormMainPicker::OnSettingButtonClicked()
{
	FormSetting formSetting;
	formSetting.DoModal();
}






/*

			LVC

*/

void FormMainPicker::OnPickerListViewItemDoubleClicked(NMHDR* pNotifyStruct, LRESULT* result)
{
	int selectedIndex = ((CListCtrl*)(this->pickerList))->GetSelectionMark();
	if (selectedIndex != -1)
	{
		FormInfoPicker formInfoPicker(pickerList, GetParent());
		formInfoPicker.DoModal();
	}
}









/*

			Buttons

*/

void FormMainPicker::OnMakePickerButtonClicked()
{
	FormMakePicker formMakePicker(GetParent());
	formMakePicker.DoModal();
	RefreshAllData();
}









/*

			Display

*/

void FormMainPicker::RefreshAllData()
{
	DisplayPickerList();
	DisplayStatics();
}

void FormMainPicker::DisplayStatics()
{
	CString count = to_string(((FormMainSArea*)GetParent())->rBuJa->GetControlPickerLength()).c_str();
	GetDlgItem(IDC_M5S_PICKERCOUNT)->SetWindowTextA(count);
}


void FormMainPicker::DisplayPickerList()
{
	// ���� �����Ѵ�.
	((CListCtrl*)this->pickerList)->DeleteAllItems();

	// CopyToBuffer�� �̿��Ͽ� �ٽ� �߰��Ѵ�.
	Long pickerBinaryTreeLength = ((FormMainSArea*)GetParent())->rBuJa->GetControlPickerLength();
	Picker *(pickers) = 0;
	Long count;

	// �� ��� �� �迭�� �Ҵ� �����Ѵ�.
	if (pickers != 0) // rer �迭�� �Ҵ� �Ǿ�����
	{
		delete[] pickers;
		pickers = 0;
	}

	((FormMainSArea*)GetParent())->rBuJa->GetCopiedPickerBuffer(&pickers, &count);

	CString number;
	for (Long i = 0; i < pickerBinaryTreeLength; i++)
	{
		Picker current = (pickers[i]);

		number.Format("%d", i + 1);
		((CListCtrl*)this->pickerList)->InsertItem(i, number);
		((CListCtrl*)this->pickerList)->SetItemText(i, 1, (LPCTSTR)current.GetId().c_str());
		((CListCtrl*)this->pickerList)->SetItemText(i, 2, (LPCTSTR)current.GetName().c_str());
		((CListCtrl*)this->pickerList)->SetItemText(i, 3, (LPCTSTR)current.GetPhone().c_str());
		((CListCtrl*)this->pickerList)->SetItemText(i, 4, (LPCTSTR)to_string(current.GetRPoint()->GetRPointValue()).c_str());
		((CListCtrl*)this->pickerList)->SetItemText(i, 5, (LPCTSTR)to_string(current.GetLikeCount()).c_str());

	}
}


/*
/// ��ȣ �߰��� ���������� �Ұ����ϴ� �Ǵ��Ͽ� ��� �ߴ��� ///
void FormMainPicker::DisplayPickerList()
{
	// ���� �����Ѵ�.
	((CListCtrl*)this->pickerList)->DeleteAllItems();
	// �׸��� �߰��Ѵ�
	Long index = 0;
	DisplayPickerListForBinary( ((FormMainSArea*)GetParent())->rBuJa->GetPickerListRootNode(), &index );
}

void FormMainPicker::DisplayPickerListForBinary(BinaryTree<Picker>::Node* nodeLink, Long *index)
{
	if (nodeLink != 0)
	{
		DisplayPickerListForBinary(nodeLink->GetLeft(), index);

		// �о����
		// �׸� �߰��ϱ�!

		Picker* pickerLink = &(nodeLink->GetKey());
		// ��ȣ
		((CListCtrl*)this->pickerList)->InsertItem(*index, to_string(*index + 1).c_str());
		// ID
		((CListCtrl*)this->pickerList)->SetItemText(*index, 1, (LPCTSTR)pickerLink->GetId().c_str());
		// Name
		((CListCtrl*)this->pickerList)->SetItemText(*index, 2, (LPCTSTR)pickerLink->GetName().c_str());
		// Phone
		((CListCtrl*)this->pickerList)->SetItemText(*index, 3, (LPCTSTR)pickerLink->GetPhone().c_str());

		DisplayPickerListForBinary(nodeLink->GetRight(), index);
	}
}

*/






// OnClose

void FormMainPicker::OnClose()
{
	// �ݱ� â�� ����.
	FormClosing formClosing(GetParent());
	formClosing.DoModal();
}
