// LibZipcodeBook.h

#ifndef _LIBZIPCODEBOOK_H
#define _LIBZIPCODEBOOK_H

#include "LibArray.h"
#include "LibAddress - updated in 140726.h"

#include <afxwin.h>
#include <afxcmn.h>

class ZipcodeBook
{
public: // �����ڵ�� ġȯ������
	ZipcodeBook(Long capacity);
	ZipcodeBook(const ZipcodeBook& source);
	~ZipcodeBook();

	ZipcodeBook& operator=(const ZipcodeBook& source);

public: // �ڷᱸ�� �޼ҵ��
	void Create(Long capacity);
	Long Load();
	Long Load(CProgressCtrl* m_ctrPro);
	void Find(string dong, Long *(*indexes), Long *count);

public: // Get��
	Address GetAt(Long index);
	Long GetCapacity();
	Long GetLength();

private:
	Array<Address> addresses;
	Long capacity;
	Long length;

};

inline Address ZipcodeBook::GetAt(Long index)
{
	return this->addresses.GetAt(index);
}

inline int CompareDongs(void *one, void *other)
{
	return strncmp( ((Address*)one)->GetDong().c_str(), ((string*)other)->c_str(), 4 );
}

inline Long ZipcodeBook::GetCapacity() { return this->capacity; }

inline Long ZipcodeBook::GetLength() { return this->length; }


#endif 