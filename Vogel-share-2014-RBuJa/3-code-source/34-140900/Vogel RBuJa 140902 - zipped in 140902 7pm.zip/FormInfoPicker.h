//FormInfoPicker.h

#ifndef _FORMINFOPICKER_H
#define _FORMINFOPICKER_H
#include "Picker.h"
#include "resource.h"
#include <afxwin.h>

class FormInfoPicker : public CDialog
{
public:
	enum { IDD = IDD_N2_INFOPICKER };
public:
	FormInfoPicker(CWnd* pickerList, CWnd *parent = NULL);
	virtual BOOL OnInitDialog();
	virtual void OnOK(); // EnterŰ â �ڵ����� ������ ���� �������̵�

private:
	CWnd* parentPickerList;

public:
	CWnd* rRequestList;
	CWnd* rRequestToDoList;
	CWnd* areaList;

public:
	void DisplayAreaList(Picker* pickerLink);

protected:

	// ID_BUTTON_OK
	afx_msg void OnOKButtonClicked();

	afx_msg void OnClose();


	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnAssgignPickerButtonClicked();
};


#endif