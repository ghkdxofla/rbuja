// RBuJa.h
/*

������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		RBuJa.h
��������:		140804
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#ifndef _RBUJA_H
#define _RBUJA_H

#include "LibLinkedList - added in 140725.h"
#include "LibBinaryTree - added in 140725.h"

#include "AreaList.h"
#include "ControlRer.h"
#include "ControlPicker.h"
#include "ControlRResource.h"

#include "SArea.h"
#include "RResource.h"

class RBuJa
{
public:
	RBuJa();
	RBuJa(const RBuJa& source);
	~RBuJa();

	RBuJa& operator=(const RBuJa& source);

/*
public: // SArea
	SArea* RecordSArea(string sAreaId);
	Zone* GiveZone(string addressId);
	SArea* FindSArea(string sAreaId);
//*/
public: // SArea
	SArea* RecordSArea(string sAreaId, RResource* rRsourceLink = 0);
	SArea* FindSArea(string sAreaId);
	SArea* FindSAreaAndCount(Long& count, string sAreaId);

	Long CountPickersInTheSArea(string sAreaId);
	Area* RegisterAreaLinkToSArea(string sAreaId, string areaId);
	Area* UnregisterAreaLinkToSArea(string areaId);

public: // Area
	Area* RegisterArea(string araeId);
	Area* FindArea(string areaId);

public: // NewData
	Rer* RegisterNewRer(string addressAndAreaId ,string id, string pw, string name, string phone, string addressTotal);
	Picker* RegisterNewPicker(string id, string pw, string name, string phone);
	RResource* RegisterNewRResource(string id, string pw, string companyName, string companyTelephone, string CEOName, string CEOPhone, string addressTotal, string addressId);


public:
	Rer* RegisterNewRer(
		string id,
		string pw,
		string name,
		string phone,

		string addressTotal,
		string addressId,

		Long year,
		Long month,
		Long day,
		Long weekDay,
		Long hour,
		Long min,
		Long sec,

		Area* areaLink);


	Picker* RegisterNewPicker(
		string id,
		string pw,
		string name,
		string phone,

		Long year,
		Long month,
		Long day,
		Long weekDay,
		Long hour,
		Long min,
		Long sec
		);

	RResource* RegisterNewRResource(
		string id,
		string pw,
		string companyName,
		string companyTelephone,
		string CEOName,
		string CEOPhone,
		string addressTotal,
		string addressId,

		Long year,
		Long month,
		Long day,
		Long weekDay,
		Long hour,
		Long min,
		Long sec,

		Long paperValueForRer,
		Long plasticValueForRer,
		Long glassBottleValueForRer,
		Long customGroupValueForRer,

		Long clothesValueForRer,
		Long steelValueForRer,
		Long wireValueForRer,

		Long stainlessValueForRer,
		Long copperValueForRer,


		Long paperValueForPicker,
		Long plasticValueForPicker,
		Long glassBottleValueForPicker,
		Long customGroupValueForPicker,

		Long clothesValueForPicker,
		Long steelValueForPicker,
		Long wireValueForPicker,

		Long stainlessValueForPicker,
		Long copperValueForPicker
		);





public: // Find
	Rer* FindRer(string id);
	Picker* FindPicker(string id);
	RResource* FindRResource(string id);

public: // Rer
	RRequest* RerMakeRRequest( string rerId, Long RType, Long pickUpType, Date rerPickUpDate);

public: // Picker
	R* PickerReportR(
		string sAreaId, 
		string areaId, 
		string rRequestId, 

		Long paperWeight,
		Long plasticWeight,
		Long glassBottleWeight,
		Long customGroupWeight,

		Long clothesWeight,
		Long steelWeight,
		Long wireWeight,

		Long stainlessWeight,
		Long copperWeight,

		string electronics,
		string electronicsDescription);
	   
public: // RResource
	RValue* ModifyRerRValue(
		string rResourceId,

		Long paperValue,
		Long plasticValue,
		Long glassBottleValue,
		Long customGroupValue,

		Long clothesValue,
		Long steelValue,
		Long wireValue,

		Long stainlessValue,
		Long copperValue
		);

	RValue* ModifyPickerRValue(
		string rResourceId,

		Long paperValue,
		Long plasticValue,
		Long glassBottleValue,
		Long customGroupValue,

		Long clothesValue,
		Long steelValue,
		Long wireValue,

		Long stainlessValue,
		Long copperValue
		);

	//////////////////////////////////////////////////////////////
	Long RecordRerRPointValue(R *r, RValue *rerRPrice); 
	Long RecordPickerRPointValue(R *r, RValue *pickerRPrice);
	//////////////////////////////////////////////////////////////










	RValue* GetRerRValue(string rRequestId);
	RValue* GetPickerRValue(string rRequestId);

public: // Link // Area �Ҵ�
	void LinkPickerAndArea(string pickerId, string areaId);
	void LinkSAreaAndArea(string sAreaId, string areaId);
	void LinkSAreaAndRResource(string sAreaId, string RResourceId);
	void LinkSAreaAndPicker(string sAreaId, string pickerId);





public: // Save Load

	void SaveRBuJa();
	void LoadRBuJa();




	void SaveRer();
	void SaveRerForBinary(BinaryTree<Rer>::Node* rerNodeLink, FILE *RerList);//, FILE *RerRRequestIDList);
	void SavePicker();
	void SavePickerForBinary(BinaryTree<Picker>::Node* pickerNodeLink, FILE *PickerList); //, FILE *PickerRRequestToDoIDList);//, FILE *PickerRRequestIDList);
	void SaveRResouce();
	void SaveArea();
	void SaveAreaForBinary(BinaryTree<Area>::Node* areaNodeLink, FILE *AreaList, FILE *RRequestList);//, FILE *PickerRRequestIDList);
	void SaveRRequest(BinaryTree<Area>::Node* areaNodeLink, FILE *RRequestList);
	void SaveSArea();


	void LoadArea();
	void LoadRer();
	void LoadPicker();
	void LoadRResource();
	void LoadSArea();
	void LoadRRequest();











public: // Display
	void GetCopiedRerBuffer(Rer* *(rers), Long *count);
	void GetCopiedPickerBuffer(Picker* *(pickers), Long *count);
	void GetCopiedAreaBuffer(Area* *(areas), Long *count);

public:	// GetAt 2
	Long GetAreaListLength() const;
	Long GetControlRerLength() const;
	Long GetControlPickerLength() const;
	Long GetControlRResourceLength() const;

public: // SArea LinkedList Bridge Methods
	Long GetSAreaLength() const;
	SArea* GetSAreaCurrent() const;
//	SArea* GetSAreaHead() const;
	
	SArea* SAreaFirst();
	SArea* SAreaPrevious();
	SArea* SAreaNext();
	SArea* SAreaLast();

public:
	RResource* RResourceFirst();
	RResource* RResourcePrevious();
	RResource* RResourceNext();
	RResource* RResourceLast();

public: // BinaryTree Bridge Methods
	BinaryTree<Area>::Node* GetAreaListRootNode() const;
	BinaryTree<Rer>::Node* GetRerListRootNode() const;
	BinaryTree<Picker>::Node* GetPickerListRootNode() const;

private:
	AreaList* areaListLink;
	ControlRer* controlRerLink;
	ControlPicker* controlPickerLink;
	ControlRResource* controlRResourceLink;

private:
	LinkedList<SArea> sAreas;
	Long length;
	SArea* current;

/*
public:
	Long GetLength() const;
//	SArea* GetCurrent() const;

private:
	LinkedList<SArea> sAreas;
	Long length;
	SArea* current;
	//*/
};
/*
Long CompareSAreaId( void *one, void *other ); 
inline Long RBuJa::GetLength() const
{
	return this->length;
}
inline SArea* RBuJa::GetCurrent() const
{
	return this->current;
}
//*/

Long CompareSAreaIds(void *one, void *other);

inline Long RBuJa::GetAreaListLength() const
{
	return this->areaListLink->GetLength();
}

inline Long RBuJa::GetControlRerLength() const
{
	return this->controlRerLink->GetLength();
}
inline Long RBuJa::GetControlPickerLength() const
{
	return this->controlPickerLink->GetLength();
}

inline Long RBuJa::GetControlRResourceLength() const
{
	return this->controlRResourceLink->GetLength();
}





// SArea Methods

inline Long RBuJa::GetSAreaLength() const
{
	return this->length;
}
inline SArea* RBuJa::GetSAreaCurrent() const
{
	return const_cast<SArea*>(this->current);
}
/*
// ����ϰ� GetSAreaHeadA ��¼�� �ϸ鼭 �������� �ּ�ó��
inline SArea* RBuJa::GetSAreaHead() const
{
	return const_cast<SArea*>( &(this->sAreas.GetHead()->GetObject()) );
}//*/

/*
// �п����� ����ö First, Privious, Next, Last �� ���Ǹ� cpp�� �ؼ� Ȥ�� ���� �ּ�ó���ϰ�
// cpp�� ���Ǹ� �Űܵ���!!
inline SArea* RBuJa::SAreaFirst()
{
	return &(this->sAreas.First()->GetObject());
}

inline SArea* RBuJa::SAreaPrevious()
{
	return &(this->sAreas.Previous()->GetObject());
}

inline SArea* RBuJa::SAreaNext()
{
	return &(this->sAreas.Next()->GetObject());
}

inline SArea* RBuJa::SAreaLast()
{
	return &(this->sAreas.Last()->GetObject());
}
//*/


inline BinaryTree<Area>::Node* RBuJa::GetAreaListRootNode() const
{
	return const_cast<BinaryTree<Area>::Node*>(this->areaListLink->GetRootNode());
}

inline BinaryTree<Rer>::Node* RBuJa::GetRerListRootNode() const
{
	return const_cast<BinaryTree<Rer>::Node*>(this->controlRerLink->GetRootNode());
}

inline BinaryTree<Picker>::Node* RBuJa::GetPickerListRootNode() const
{
	return const_cast<BinaryTree<Picker>::Node*>(this->controlPickerLink->GetRootNode());
}


#endif
