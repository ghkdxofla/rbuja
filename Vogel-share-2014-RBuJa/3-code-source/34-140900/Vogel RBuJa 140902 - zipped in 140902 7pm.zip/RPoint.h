// RPoint.h
/*
������Ʈ��: �˺��� ( RBuJa )
�����̸�: RPoint.h
�ۼ�����: 140712
�ۼ���: ����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#ifndef _RPOINT_H
#define _RPOINT_H

#include "LibDate.h"
#include "LibLinkedList - added in 140725.h"
#include "LibDateIndexes.h"

#include "RTransaction.h"

#include <string>

using namespace std;

typedef signed long int Long;

class Rer;
class Picker;
class RReqeust;

class RPoint {

public:
	RPoint();
//	RPoint(Rer* rerLink );
//	RPoint(Picker* pickerLink); 
	RPoint(const RPoint& source);
	~RPoint();

	RPoint& operator=(const RPoint& source);

public:
	RTransaction* RecordRTransaction(RTransaction rTransaction);
	RPoint* RTransactionAffectRPointValue(RTransaction *rTransaction);			// RTransaction�� RPoint�� RPointValue�� �����Ѵ�.
//*/

public:
	Rer* GetRerLink() const;
	Long GetRPointValue() const;
	Long GetLength()	const;
	RTransaction* GetCurrent() const;

	

public:

	RTransaction* FirstForRTransactionLink();
	RTransaction* NextForRTransactionLink();
	RTransaction* PreviousForRTransactionLink();
	RTransaction* LastForRTransactionLink();


private:
/*
	Rer* rerLink;															// �ش� RPoint�� Rer �ּ�
	Picker* pickerLink;
//*/
private:
	Long rPointValue;													// RTransaction���� �ݾ׵��� ��
	
private:
	LinkedList<RTransaction> rTransactions;				// Transactinon�� �ּҵ��� �����Ѵ�.
	Long length;
	RTransaction* current;
	
private:
	DateIndexes<LinkedList<RTransaction>::Node*> dateRTransactionIndeses;
	Long lengthForDateRTransactionIndexes;
	DateIndexes<LinkedList<RTransaction>::Node*>::Node* currentForDateRTransactionIndexes;


};

inline Long RPoint::GetRPointValue() const
{
	return this->rPointValue;
}
inline Long RPoint::GetLength()	const
{
	return this->length;
}
inline RTransaction* RPoint::GetCurrent() const
{
	return this->current;
}

#endif //_RPOINT_H