//FormMakeRer.h

#ifndef _FORMMAKERER_H
#define _FORMMAKERER_H
#include "resource.h"
#include <afxwin.h>

class FormMakeRer : public CDialog
{
public:
	enum {IDD=IDD_K1_MAKERER};
public:
	FormMakeRer( CWnd *parent = NULL ) ;
	virtual BOOL OnInitDialog() ;
	virtual void OnOK(); // EnterŰ â �ڵ����� ������ ���� �������̵�

protected:
	
	// ID_BUTTON_OK
	afx_msg void OnOKButtonClicked() ;
	afx_msg void OnFindingAddressButtonclicked();
	
	afx_msg void OnClose() ;
	
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeEdit6();
	afx_msg void OnEnChangeEdit8();
};


#endif