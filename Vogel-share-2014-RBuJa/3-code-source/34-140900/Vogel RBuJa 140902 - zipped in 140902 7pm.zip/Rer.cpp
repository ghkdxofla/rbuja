// Rer.cpp
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		Rer.cpp
��������:		140627
�ۼ���:			����ȣ, �����
*/

#include "Rer.h"

Rer::Rer()
{
	this->id = "";
	this->pw = "";
	this->name = "";
	this->phone = "";

	this->addressTotal = "";
	this->addressId = "";
	this->joinDate = Date::Today();

	this->rPoint = RPoint();
	
	this->areaLink = 0;

	this->length = 0;
	this->current = 0;

	this->lengthForDateRRequestLinkIndexes = 0;
	this->currentForDateRRequestLinkIndexes = 0;
}

Rer::Rer(string id)
{
	this->id = id;
	this->pw = "";
	this->name = "";
	this->phone = "";
	
	this->addressTotal = "";
	this->addressId = "";
	this->joinDate = Date::Today();

	this->rPoint = RPoint();

	this->areaLink = 0;

	this->length = 0;
	this->current = 0;


	this->lengthForDateRRequestLinkIndexes = 0;
	this->currentForDateRRequestLinkIndexes = 0;
}

Rer::Rer(string id, string pw, string name, string phone, string addressTotal, string addressId, Area* areaLink)
{
	this->id = id;
	this->pw = pw;
	this->name = name;
	this->phone = phone;

	this->addressTotal = addressTotal;
	this->addressId = addressId;
	this->joinDate = Date::Today();

	this->areaLink = areaLink;

	this->length = 0;
	this->current = 0;

	this->lengthForDateRRequestLinkIndexes = 0;
	this->currentForDateRRequestLinkIndexes = 0;
}
//*/

Rer::Rer(
	string id,
	string pw,
	string name,
	string phone,

	string addressTotal,
	string addressId,

	Long year,
	Long month,
	Long day,
	Long weekDay,
	Long hour,
	Long min,
	Long sec,

	Area* areaLink)
{
	this->id = id;
	this->pw = pw;
	this->name = name;
	this->phone = phone;

	this->addressTotal = addressTotal;
	this->addressId = addressId;
	Date joinDate(year, month, day, weekDay, hour, min, sec);
	this->joinDate = joinDate;

	this->rPoint = RPoint();

	this->areaLink = areaLink;

	this->length = 0;
	this->current = 0;

	this->lengthForDateRRequestLinkIndexes = 0;
	this->currentForDateRRequestLinkIndexes = 0;


}






Rer::Rer(const Rer& source)
{
	this->id = source.id;
	this->pw = source.pw;
	this->name = source.name;
	this->phone = source.phone;

	this->addressTotal = source.addressTotal;
	this->addressId = source.addressId;
	this->joinDate = source.joinDate;

	this->rPoint = source.rPoint;
	
	this->areaLink = source.areaLink;

	this->length = source.length;
	this->current = source.current;

	this->lengthForDateRRequestLinkIndexes = source.lengthForDateRRequestLinkIndexes;
	this->currentForDateRRequestLinkIndexes = source.currentForDateRRequestLinkIndexes;
}

Rer::~Rer() {}

Rer& Rer::operator=(const Rer& source)
{
	this->id = source.id;
	this->pw = source.pw;
	this->name = source.name;
	this->phone = source.phone;

	this->addressTotal = source.addressTotal;
	this->addressId = source.addressId;
	this->joinDate = source.joinDate;

	this->rPoint = source.rPoint;

	this->areaLink = source.areaLink;
	
	this->length = source.length;
	this->current = source.current;

	this->lengthForDateRRequestLinkIndexes = source.lengthForDateRRequestLinkIndexes;
	this->currentForDateRRequestLinkIndexes = source.currentForDateRRequestLinkIndexes;


	return *this;
}

RRequest* Rer::RegisterRRequestLink(RRequest* rRequestLink)
{
	RRequest* newRRequestLink = this->rRequestList.AppendFromTail(rRequestLink)->GetObject();
	this->length = this->rRequestList.GetLength();
	this->current = this->rRequestList.GetCurrent()->GetObject();








	LinkedList<RRequest*>::Node* rRequestLinksNodeLink = this->rRequestList.GetCurrent();
	DateIndexes<LinkedList<RRequest*>::Node*>::Node* dateRRequestLinkIndexesNodeLink = this->currentForDateRRequestLinkIndexes;


	// ���� ���� �����̰ų�, ������ ������ ���ʷ� ���� ��
	if (dateRRequestLinkIndexesNodeLink == 0
		|| dateRRequestLinkIndexesNodeLink->GetDate()->IsNotEqual(Date::Today()))
	{
		// �� ���� ��带 �����
		this->dateRRequestLinkIndexes.AppendFromTail(rRequestLinksNodeLink, rRequestLinksNodeLink);
		this->lengthForDateRRequestLinkIndexes = this->dateRRequestLinkIndexes.GetLength();
		this->currentForDateRRequestLinkIndexes = this->dateRRequestLinkIndexes.GetCurrent();
	}
	else
	{ // ���ο� tail�� ���� ���� ġȯ��Ų��
		int length = dateRRequestLinkIndexesNodeLink->GetLength() + 1;
		*dateRRequestLinkIndexesNodeLink = DateIndexes<LinkedList<RRequest*>::Node*>::Node(dateRRequestLinkIndexesNodeLink->GetStartDateLink(), rRequestLinksNodeLink, Date::Today(), length);
	}


















	return newRRequestLink;
}
//*/



RTransaction* Rer::ReceiveRPointByRSelling(RTransactionType type, Long rPoint, string description)
{
	/*
	1. ������ �����
	2. ������ �����Ѵ�
	3. rPoint�� ����Ѵ�
	*/
	RTransaction newRTransaction(type, rPoint, description);
	RTransaction* rTransactionLink = this->rPoint.RecordRTransaction(newRTransaction);
	this->rPoint.RTransactionAffectRPointValue(rTransactionLink);
	return rTransactionLink;
}







RRequest* Rer::RRequestLinkFirst()
{
	RRequest* rRequestLink = this->rRequestList.First()->GetObject();
	return rRequestLink;
}
RRequest* Rer::RRequestLinkNext()
{
	RRequest* rRequestLink = this->rRequestList.Next()->GetObject();
	return rRequestLink;
}
RRequest* Rer::RRequestLinkPrevious()
{
	RRequest* rRequestLink = this->rRequestList.Previous()->GetObject();
	return rRequestLink;
}
RRequest* Rer::RRequestLinkLast()
{
	RRequest* rRequestLink = this->rRequestList.Last()->GetObject();
	return rRequestLink;
}

RRequest* Rer::FirstForRRequestLink()
{
	RRequest* rRequestLink = 0;
	LinkedList<RRequest*>::Node* nodeLink = this->rRequestList.First();
	if (nodeLink != 0)
	{
		rRequestLink = nodeLink->GetObject();
	}
	return rRequestLink;
}
RRequest* Rer::NextForRRequestLink()
{
	RRequest* rRequestLink = this->rRequestList.Next()->GetObject();
	return rRequestLink;
}
RRequest* Rer::PreviousForRRequestLink()
{
	RRequest* rRequestLink = this->rRequestList.Previous()->GetObject();
	return rRequestLink;
}
RRequest* Rer::LastForRRequestLink()
{
	RRequest* rRequestLink = this->rRequestList.Last()->GetObject();
	return rRequestLink;
}