#include "FormSetting.h"

#include <afxcmn.h>

BEGIN_MESSAGE_MAP(FormSetting, CDialog)


	ON_WM_CLOSE()
END_MESSAGE_MAP()

FormSetting::FormSetting(CWnd *parent)
:CDialog(FormSetting::IDD, parent)
{

}

BOOL FormSetting::OnInitDialog()
{
	CDialog::OnInitDialog();

	return FALSE;
}


// OnClose

void FormSetting::OnClose()
{
	OnOK();
}
