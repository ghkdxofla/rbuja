// ControlPicker.h
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		ControlPicker.h
��������:		140712
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#ifndef _CONTROLPICKER_H
#define _CONTROLPICKER_H

#include "LibBinaryTree - added in 140725.h"
#include "Picker.h"

class ControlPicker {

public:
	ControlPicker();
	ControlPicker(const ControlPicker& source);
	~ControlPicker();

	ControlPicker& operator=(const ControlPicker& source);

public:
	Long GetLength() const;
	BinaryTree<Picker>::Node* GetRoot() const;
public: // Library �Լ��� Bridge
	void GetCopiedPickerBuffer(Picker* *(pickers), Long *count);
	BinaryTree<Picker>::Node* GetRootNode();

public:

	Picker* RecordPicker(
		string id,
		string pw,
		string name,
		string phone);
	
	Picker* ControlPicker::RecordPicker(
		string id,
		string pw,
		string name,
		string phone,

		Long year,
		Long month,
		Long day,
		Long weekDay,
		Long hour,
		Long min,
		Long sec
		);


	Picker* FindPicker(string pickerId) ;
/*
	Picker* ModifyPicker(
		Picker* oldPickerLink,
		string oldPw,
		string newPw,
		string phone,
		RCenter* rCenterLink);
/
/*
	Picker* DeletePicker(Picker* pickerLink);


	RRequest* FindRRequestLink(Picker* pickerLink, string rRequestId);
//*/	

private:
	BinaryTree<Picker> pickers;
	Long length;
	

};

Long ComparePickerIds(void* one, void* other);


inline Long ControlPicker::GetLength() const
{
	return this->length;
}

inline void ControlPicker::GetCopiedPickerBuffer(Picker* *(pickers), Long *count)
{
	this->pickers.CopyToBuffer(pickers, count);
}

inline BinaryTree<Picker>::Node* ControlPicker::GetRootNode()
{
	return this->pickers.GetRoot();
}




inline BinaryTree<Picker>::Node* ControlPicker::GetRoot() const
{
	return const_cast<BinaryTree<Picker>::Node*>(this->pickers.GetRoot());
}








#endif //_CONTROLPICKER_H