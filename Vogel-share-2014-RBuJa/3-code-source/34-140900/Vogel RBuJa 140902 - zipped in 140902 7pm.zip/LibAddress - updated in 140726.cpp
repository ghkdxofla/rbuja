// LibAddress - updated in 140726.h.cpp

#include "LibAddress - updated in 140726.h"

Address::Address()
: zipCode(""),
siDo(""),
guGun(""),
dong(""),
ri(""),
bldg(""),
st_bunji(""),
ed_bunji(""),
seq(""),
detail(""){}

Address::Address(const Address& source)
: zipCode(source.zipCode),
siDo(source.siDo),
guGun(source.guGun),
dong(source.dong),
ri(source.ri),
bldg(source.bldg),
st_bunji(source.st_bunji),
ed_bunji(source.ed_bunji),
seq(source.seq),
detail(source.detail){}

Address::Address(
	string zipCode,
	string siDo,
	string guGun,
	string dong,
	string ri,
	string bldg,
	string st_bunji,
	string ed_bunji,
	string seq,
	string detail
)
: zipCode(zipCode),
siDo(siDo),
guGun(guGun),
dong(dong),
ri(ri),
bldg(bldg),
st_bunji(st_bunji),
ed_bunji(ed_bunji),
seq(seq),
detail(detail)
{}

Address::~Address() {}

Address& Address::operator =(const Address& source) {
	this->zipCode = source.zipCode;
	this->siDo = source.siDo;
	this->guGun = source.guGun;

	this->dong = source.dong;
	this->ri = source.ri;
	this->bldg = source.bldg;

	this->st_bunji = source.st_bunji;
	this->ed_bunji = source.ed_bunji;
	this->seq = source.seq;

	this->detail = source.detail;

	return *this;
}

bool Address::isEqual(const Address& other)
{
	bool ret = false;
	if (this->zipCode.compare(other.zipCode) == 0 &&
		this->siDo.compare(other.siDo) == 0 &&
		this->guGun.compare(other.guGun) == 0 &&

		this->dong.compare(other.dong) == 0 &&
		this->ri.compare(other.ri) == 0 &&
		this->bldg.compare(other.bldg) == 0 &&

		this->st_bunji.compare(other.st_bunji) == 0 &&
		this->ed_bunji.compare(other.ed_bunji) == 0 &&
		this->seq.compare(other.seq) == 0 &&
		
		this->detail.compare(other.detail) == 0)
	{
		ret = true;
	}

	return ret;
}
bool Address::isNotEqual(const Address& other)
{
	bool ret = true;
	if (this->zipCode.compare(other.zipCode) == 0 &&
		this->siDo.compare(other.siDo) == 0 &&
		this->guGun.compare(other.guGun) == 0 &&

		this->dong.compare(other.dong) == 0 &&
		this->ri.compare(other.ri) == 0 &&
		this->bldg.compare(other.bldg) == 0 &&

		this->st_bunji.compare(other.st_bunji) == 0 &&
		this->ed_bunji.compare(other.ed_bunji) == 0 &&
		this->seq.compare(other.seq) == 0 &&

		this->detail.compare(other.detail) == 0)
	{
		ret = false;
	}

	return ret;
}












// temp for test

Address::Address(
		string siDo,
		string guGun,
		string dong,
		string bldg)
: zipCode(""),
siDo(siDo),
guGun(guGun),

dong(dong),
ri(""),
bldg(bldg),

st_bunji(""),
ed_bunji(""),
seq(""),


detail("")
{
}