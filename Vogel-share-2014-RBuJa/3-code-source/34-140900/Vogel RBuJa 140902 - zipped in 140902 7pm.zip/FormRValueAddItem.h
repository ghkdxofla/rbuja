//FormRValueAddItem.h

#ifndef _FORMRVALUEADDITEM_H
#define _FORMRVALUEADDITEM_H
#include "resource.h"
#include <afxwin.h>

class RValue;

class FormRValueAddItem : public CDialog
{
public:
	enum { IDD = IDD_V1_ADDITEM };

public:
	FormRValueAddItem(int formType, CWnd *parent = NULL, RValue* rerRValueLink = 0, RValue* pickerRValueLink = 0);
	virtual BOOL OnInitDialog();
	virtual void OnOK(); // EnterŰ â �ڵ����� ������ ���� �������̵�

	virtual BOOL PreTranslateMessage(MSG* pMsg);

public: // Setting Type
	void SettingForSetGeneralValues();
	void SettingForSetElectronicsValues();
	void SettingForAddElectronicsItem();

private:
	int formType = -1;
	
	CWnd* generalList;
	CWnd* electronicsList;

	RValue* rerRValueLink = 0;
	RValue* pickerRValueLink = 0;

protected:

	// ID_BUTTON_OK
	afx_msg void OnOKButtonClicked();

	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
};


#endif