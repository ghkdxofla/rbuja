// ControlPicker.cpp
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		ControlPicker.cpp
��������:		140712
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#include "ControlPicker.h"

ControlPicker::ControlPicker()
{
	this->length = 0;
}

ControlPicker::ControlPicker(const ControlPicker& source)
{
	this->pickers = source.pickers;
	this->length = source.length;

}

ControlPicker::~ControlPicker() {}

ControlPicker& ControlPicker::operator=(const ControlPicker& source)
{
	this->pickers = source.pickers;
	this->length = source.length;
	return *this;
}

Picker* ControlPicker::RecordPicker(
	string id,
	string pw,
	string name,
	string phone)
{
	if( this->pickers.GetBalance() >= 1000)
	{
		this->pickers.MakeBalance();
	}
	Picker newPicker( id, pw, name, phone);
	Picker *pickerLink = &( this->pickers.Insert( newPicker, ComparePickerIds )->GetKey() );
	this->length = this->pickers.GetLength();

	return pickerLink ;
}



Picker* ControlPicker::RecordPicker(
	string id,
	string pw,
	string name,
	string phone,

	Long year,
	Long month,
	Long day,
	Long weekDay,
	Long hour,
	Long min,
	Long sec
	)
{
	if (this->pickers.GetBalance() >= 1000)
	{
		this->pickers.MakeBalance();
	}



	Picker newPicker(id, pw, name, phone, year, month, day, weekDay, hour, min, sec);
	BinaryTree<Picker>::Node* node = this->pickers.Insert(newPicker, ComparePickerIds);
	Picker* pickerLink = &(node->GetKey());
	this->length = this->pickers.GetLength();

	return pickerLink;

}



//FindPicker

Picker* ControlPicker::FindPicker( string pickerId ) 
{	
	if( this->pickers.GetBalance() >= 1000)
	{
		this->pickers.MakeBalance();
	}
	Picker *finedPickerLink = 0;
	Picker picker( pickerId );
	BinaryTree<Picker>::Node* node = this->pickers.Search( pickerId, ComparePickerIds );

	if( node !=0 )
	{
		finedPickerLink = &(node->GetKey());
	}
	return finedPickerLink;
}
//*/

/*
Picker* ControlPicker::ModifyPicker(
	Picker* oldPickerLink,
	string oldPw,
	string newPw,
	string phone,
	RCenter* rCenterLink)
{
		return 0 ;
}



// DeletePicker
Picker* ControlPicker::DeletePicker(Picker* pickerLink)
{
	if( this->pickers.GetBalance() >= 1000)
	{
		this->pickers.MakeBalance();
	}
	BinaryTree<Picker>::Node* node= this->pickers.Delete( *pickerLink, ComparePickerIds );
	if( node == 0 ) // ������ �� �Ǹ�
	{ // pickerLink���� ���̻� ��ȿ���� �����Ƿ�
		pickerLink = 0; // pickerLink���� NULL�� ġȯ
		this->length = this->pickers.GetLength();
	}
	
	return pickerLink;
}





RRequest* ControlPicker::FindRRequestLink(Picker* pickerLink, string rRequestId)
{
	RRequest *foundRRequestLink = pickerLink->FindRRequestLink(rRequestId);
	return foundRRequestLink;
}
//*/




Long ComparePickerIds(void* one, void* other) 
{
	Long ret;
	ret = (((Picker*)one)->GetId()).compare(((Picker*)other)->GetId());
	return ret;
}
