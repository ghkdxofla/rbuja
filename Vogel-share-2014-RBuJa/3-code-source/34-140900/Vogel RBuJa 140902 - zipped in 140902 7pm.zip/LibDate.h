#ifndef _LIBDATE_H
#define _LIBDATE_H

#include <string>

using namespace std;


class Date
{
public:
	Date();
	~Date();
	Date(int year,
		int month,
		int day,
		int weekDay,
		int hour,
		int min,
		int sec);
	Date& operator=(const Date& source);
	
	static Date Today();
	Date YesterDay();
	Date Tomorrow();
	Date PreviousDate(int days);
	Date NextDate(int days);

	bool IsEqual(Date other);
	bool IsNotEqual(Date other);
	bool IsLesserThan(Date other);
	bool IsGreaterThan(Date other);

	string ConvertToString();

	int GetYear() const;
	int GetMonth() const;
	int GetDay() const;

	int GetWeekDay() const;
	int GetHour() const;
	int GetMin() const;

	int GetSec() const;

private:
	int year;
	int month;
	int day;
	int weekDay;
	int hour;
	int min;
	int sec;
};
inline int Date::GetYear() const{
	return this->year;
}
inline int Date::GetMonth() const{
	return this->month;
}
inline int Date::GetDay() const{
	return this->day;
}



inline int Date::GetWeekDay() const{
	return this->weekDay;
}
inline int Date::GetHour() const
{
	return this->hour;
}
inline int Date::GetMin() const
{
	return this->min;
}

inline int Date::GetSec() const
{
	return this->sec;
}

#endif //_LIBDATE_H