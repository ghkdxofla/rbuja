//FormRValueSetValues.h

#ifndef _FORMRVALUESETVALUES_H
#define _FORMRVALUESETVALUES_H
#include "resource.h"
#include <afxwin.h>

#include <iostream>

using namespace std;

class RValue;

class FormRValueSetValues : public CDialog
{
public:
	enum { IDD = IDD_V2_SETVALUES };

public:
	FormRValueSetValues(
		string rResourceID,
		CWnd *parent = NULL
		);

	virtual BOOL OnInitDialog();
	virtual void OnOK(); // EnterŰ â �ڵ����� ������ ���� �������̵�
	virtual BOOL PreTranslateMessage(MSG* pMsg);

private:

	CWnd* generalList;
	CWnd* electronicsList;

	string rResourceID = "";

protected:

	// ID_BUTTON_OK
	afx_msg void OnOKButtonClicked();

	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
};


#endif