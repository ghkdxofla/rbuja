// R.h
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		R.h
��������:		140626
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
Ư�̻���:
	**********========weight ������ g**********========
	**********========weight ������ g**********========
	**********========weight ������ g**********========
	**********========weight ������ g**********========
	**********========weight ������ g**********========
	**********========weight ������ g**********========
	**********========weight ������ g**********========
	**********========weight ������ g**********========
	**********========weight ������ g**********========
	**********========weight ������ g**********========
	**********========weight ������ g**********========
	**********========weight ������ g**********========
	**********========weight ������ g**********========
	**********========weight ������ g**********========
*/

#ifndef _R_H
#define _R_H


#include <string>
using namespace std;

typedef signed long int Long;


//class RRequest;
class R {


public:
	R();
	R(
		Long paperWeight,
		Long plasticWeight,
		Long glassBottleWeight,
		Long customGroupWeight,

		Long clothesWeight,
		Long steelWeight,
		Long wireWeight,

		Long stainlessWeight,
		Long copperWeight,

		string electronics,
		string electronicsDescription
	);

	R(
		Long paperWeight,
		Long plasticWeight,
		Long glassBottleWeight,
		Long customGroupWeight,

		Long clothesWeight,
		Long steelWeight,
		Long wireWeight,

		Long stainlessWeight,
		Long copperWeight,

		Long totalWeight,
		string electronics,
		string electronicsDescription
		);
	//*/
	R(const R& source);
	~R();
	R& operator=(const R& source);

public:
	Long GetPaperWeight() const;
	Long GetPlasticWeight() const;
	Long GetGlassBottleWeight() const;
	Long GetCustomGroupWeight() const; // 3

	Long GetClothesWeight() const;
	Long GetSteelWeight() const;
	Long GetWireWeight() const;  // 6

	Long GetStainlessWeight() const;
	Long GetCopperWeight() const; // 8

	Long GetTotalWeight() const; // 9

	Long GetRerRPoint() const;
	Long GetPickerRPoint() const; // 11

	string GetElectronics() const;
	string GetElectronicsDescription() const; // 13

//	RRequest* GetRRequestLink() const;


private: // Link
//	RRequest* rRequestLink;

private:
	Long paperWeight; // ����
	Long plasticWeight; // �ö�ƽ
	Long glassBottleWeight; // ��
	Long customGroupWeight; // ���� = �⵿���  =   ĵ, ö ���

	Long clothesWeight; // ��
	Long steelWeight; // ö
	Long wireWeight; // ��

	Long stainlessWeight; // �����θ��� = ����
	Long copperWeight; // ���� = ��

	// 9��

	Long totalWeight;
	// 10��

//    Long rerRPoint; 
//	Long pickerRPoint;

	string electronics;
	string electronicsDescription;
	// 9��
};


inline Long R::GetPaperWeight() const
{
	return this->paperWeight;
}
inline Long R::GetPlasticWeight() const
{
	return this->plasticWeight;
}
inline Long R::GetGlassBottleWeight() const
{
	return this->glassBottleWeight;
}
inline Long R::GetCustomGroupWeight() const
{
	return this->customGroupWeight;
}






inline Long R::GetClothesWeight() const
{
	return this->clothesWeight;
}
inline Long R::GetSteelWeight() const
{
	return this->steelWeight;
}
inline Long R::GetWireWeight() const
{
	return this->wireWeight;
}
inline Long R::GetStainlessWeight() const
{
	return this->stainlessWeight;
}
inline Long R::GetCopperWeight() const
{
	return this->copperWeight;
}




inline Long R::GetTotalWeight() const 
{
	return this->totalWeight;
}








inline string R::GetElectronics() const
{
	return this->electronics;
}
inline string R::GetElectronicsDescription() const {
	return this->electronicsDescription;
}




/*
inline RRequest* R::GetRRequestLink() const
{
	return const_cast<RRequest*>(this->rRequestLink);
}
//*/
#endif //_R_H