//FormFindingAddress.h

#ifndef _FORMFINDINGADDRESS_H
#define _FORMFINDINGADDRESS_H

#include "resource.h"
#include <afxwin.h>

class FormFindingAddress : public CDialog
{
public:
	enum { IDD = IDD_F1_FINDADDRESS };
public:
	FormFindingAddress(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();

	virtual void OnOK();
	virtual void OnCancel();

public:
	CWnd* addressList;

protected:
	afx_msg void OnOKButtonClicked();

	afx_msg void OnAddressListViewItemDoubleClicked(NMHDR *pNotifyStruct, LRESULT *result);
	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
};


#endif