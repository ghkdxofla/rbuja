//FormMainRValue.h

#ifndef _FORMMAINRVALUE_H
#define _FORMMAINRVALUE_H

#include "resource.h"
#include <afxwin.h>

#include <iostream>
using namespace std;

class FormMainRValue : public CDialog
{
public:
	enum { IDD = IDD_M3_RVALUE };
public:
	FormMainRValue(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();

public: // ����� �������̵�
	virtual void OnOK(); // EnterŰ â �ڵ����� ����
	virtual void OnCancel(); // ESCŰ â �ڵ����� ����

public: // Controls
	CWnd* sAreaList;
	CWnd* generalList;
	CWnd* electronicsList;

public: // Display
	void RefreshAllData();
	void DisplaySAreaList();
	void DisplayGeneralList();
	void DisplayElectronicsList();
	void SetSelectionMarks();

protected:
	// �����찡 ���̸� �߻��Ǵ� �̺�Ʈ
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);

	// SideMenuButtons
	afx_msg void OnMainSAreaButtonClicked();
	afx_msg void OnMainRResourceButtonClicked();
	afx_msg void OnMainRValueButtonClicked();
	afx_msg void OnMainRerButtonClicked();
	afx_msg void OnMainPickerButtonClicked();
	afx_msg void OnRefreshButtonClicked();
	afx_msg void OnSettingButtonClicked();

	// Buttons
	afx_msg void OnSetGeneralRValueButtonClicked();

	afx_msg void OnSetElectronicsRValueButtonClicked();
	afx_msg void OnAddElectronicsRValueButtonClicked();
	afx_msg void OnDeleteElectronicsRValueButtonClicked();

	// LVC
	// Single
	afx_msg void OnSAreaListViewItemSingleClicked(NMHDR *pNotifyStruct, LRESULT *result);
	afx_msg void OnGeneralListViewItemSingleClicked(NMHDR *pNotifyStruct, LRESULT *result);
	afx_msg void OnElectronicsListViewItemSingleClicked(NMHDR *pNotifyStruct, LRESULT *result);
	// Double
	afx_msg void OnGeneralListViewItemDoubleClicked(NMHDR *pNotifyStruct, LRESULT *result);
	afx_msg void OnElectronicsListViewItemDoubleClicked(NMHDR *pNotifyStruct, LRESULT *result);

	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
};


#endif