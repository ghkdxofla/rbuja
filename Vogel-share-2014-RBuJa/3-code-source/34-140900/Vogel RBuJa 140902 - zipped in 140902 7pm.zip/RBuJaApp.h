#ifndef _RBuJaApp_H
#define _RBuJaApp_H

#define _WIN32_WINNT		0x0502

#include <afxwin.h>

// Win7 ��Ÿ�Ϸ� ������ϴ� ��
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' " "version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

class RBuJaApp : public CWinApp
{
public :
	BOOL InitInstance( );
};
#endif //_BUSINESSCARDBINDERAPP_H