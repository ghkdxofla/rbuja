#include "FormLoading2.h"

#include "LibZipcodeBook.h"

#include "FormLogin.h"

BEGIN_MESSAGE_MAP(FormLoading2, CDialog)
	ON_WM_SHOWWINDOW()
	ON_WM_CLOSE()
END_MESSAGE_MAP()

FormLoading2::FormLoading2(CWnd *parent)
:CDialog(FormLoading2::IDD, parent)
{

}

BOOL FormLoading2::OnInitDialog()
{
	CDialog::OnInitDialog();

	return FALSE;
}

void FormLoading2::OnOK()
{
	// Do Nothing
}

void FormLoading2::OnCancel()
{
	// Do Nothing
}







// OnClose

void FormLoading2::OnClose()
{
	// Do Nothing
}