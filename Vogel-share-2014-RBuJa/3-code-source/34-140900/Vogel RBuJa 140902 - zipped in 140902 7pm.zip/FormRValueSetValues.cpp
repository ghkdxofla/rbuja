#include "FormRValueSetValues.h"
#include "FormLogin.h"

#include "FormMainRValue.h"

#include <afxcmn.h>

BEGIN_MESSAGE_MAP(FormRValueSetValues, CDialog)

	ON_BN_CLICKED(IDC_V2B_SET, OnOKButtonClicked)
	ON_BN_CLICKED(IDC_V2B_CANCEL, OnClose)

	ON_WM_CLOSE()
END_MESSAGE_MAP()

FormRValueSetValues::FormRValueSetValues(
	string rResourceID,
	CWnd *parent)
:CDialog(FormRValueSetValues::IDD, parent)
{
	this->rResourceID = rResourceID;
}

BOOL FormRValueSetValues::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �θ� â�� LVC �ּҸ� �Ӽ����� �����Ѵ�.
	this->generalList = ((FormMainRValue*)GetParent())->GetDlgItem(IDC_M3L_GENERAULRVALUE);
	// this->electronicsList = ((FormMainRValue*)GetParent())->GetDlgItem(IDC_M3L_ELECTRONICSRVALUE);



	/// Setting - SetLimitText ///
	
	int nID = 1298;

	for (Long i = 0; i <17; i++)
	{
		((CEdit*)GetDlgItem(nID))->SetLimitText(7);
		nID++;
	}

	/// Setting - Previous Values //
	CString value = "";

	// 1�� �ü��� ����Ѵ�.
	nID = 1298;

	for(Long i = 0; i <9; i++)
	{
		// ������ �θ� â�� LVC���� �����´�.
		value = ((CListCtrl*)this->generalList)->GetItemText(i, 2);
		// �ش� nID�� Edit Control�� ����Ѵ�.
		GetDlgItem(nID)->SetWindowTextA(value);
		nID++;
	}

	// 2�� �ü��� ����Ѵ�.
	nID = 1307;

	for (Long i = 0; i < 9; i++)
	{
		// ������ �θ� â�� LVC���� �����´�.
		value = ((CListCtrl*)this->generalList)->GetItemText(i, 3);
		// �ش� nID�� Edit Control�� ����Ѵ�.
		GetDlgItem(nID)->SetWindowTextA(value);
		nID++;
	}

	// ��Ŀ�� ����
	GetDlgItem(IDC_V2E_VALUE1F)->SetFocus();
	((CEdit*)GetDlgItem(1298))->SetSel(0, -1);

	return FALSE;
}

void FormRValueSetValues::OnOK()
{
	OnOKButtonClicked();
}

BOOL FormRValueSetValues::PreTranslateMessage(MSG* pMsg)
{
	// TODO: Add your specialized code here and/or call the base class

	int nID = 1298;
	for (Long i = 0; i <17; i++)
	{
		CEdit* edit = ((CEdit*)GetDlgItem(nID));
		nID++;

		if (pMsg->message == WM_LBUTTONDOWN
			&& pMsg->hwnd == edit->m_hWnd
			&& GetFocus()->m_hWnd != edit->m_hWnd)
		{
			edit->SetFocus();
			edit->SetSel(0, -1, true);
			return true;
		}
	}

	return CDialog::PreTranslateMessage(pMsg);
}






void FormRValueSetValues::OnOKButtonClicked()
{
	CString code = "";
	CString values[9] = { "0", "0", "0", "0", "0", "0", "0", "0", "0" };
	// CString value = "";

	// 1�� �ü��� ����Ѵ�.
	int nID = 1298;

	for (Long i = 0; i <9; i++)
	{
		// ������ �θ� â�� LVC���� �����´�.
		GetDlgItem(nID)->GetWindowTextA(values[i]);

		nID++;
	}
	((FormMainSArea*)GetParent()->GetParent())->rBuJa->ModifyRerRValue(
		this->rResourceID,
		atoi(values[0].GetBuffer(0)),
		atoi(values[1].GetBuffer(0)),
		atoi(values[2].GetBuffer(0)),
		atoi(values[3].GetBuffer(0)),
		atoi(values[4].GetBuffer(0)),
		atoi(values[5].GetBuffer(0)),
		atoi(values[6].GetBuffer(0)),
		atoi(values[7].GetBuffer(0)),
		atoi(values[8].GetBuffer(0))
		);

	// 2�� �ü��� ����Ѵ�.
	nID = 1307;
	values[8] = { "0", };
	for (Long i = 0; i <9; i++)
	{
		// ������ �θ� â�� LVC���� �����´�.
		GetDlgItem(nID)->GetWindowTextA(values[i]);

		nID++;
	}
	((FormMainSArea*)GetParent()->GetParent())->rBuJa->ModifyPickerRValue(
		this->rResourceID,
		atoi(values[0].GetBuffer(0)),
		atoi(values[1].GetBuffer(0)),
		atoi(values[2].GetBuffer(0)),
		atoi(values[3].GetBuffer(0)),
		atoi(values[4].GetBuffer(0)),
		atoi(values[5].GetBuffer(0)),
		atoi(values[6].GetBuffer(0)),
		atoi(values[7].GetBuffer(0)),
		atoi(values[8].GetBuffer(0))
		);

	EndDialog(0);
}

void FormRValueSetValues::OnClose()
{
	EndDialog(0);
}