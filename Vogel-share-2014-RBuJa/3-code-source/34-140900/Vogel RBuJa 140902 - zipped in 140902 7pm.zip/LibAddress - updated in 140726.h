// LibAddress - updated in 140726.h.h

#ifndef _LIBADDRESS_H
#define _LIBADDRESS_H

#include <string>
using namespace std;

class Address {
public:
	Address();
	Address(const Address& source);
	Address(
		string zipCode,
		string siDo,
		string guGun,
		string dong,
		string ri,
		string bldg,
		string st_bunji,
		string ed_bunji,
		string seq,
		string detail
	);
	~Address();

	Address& operator =(const Address& source);

	bool isEqual(const Address& other);
	bool isNotEqual(const Address& other);

	string& GetZipCode() const;
	string& GetSiDo() const;
	string& GetGuGun() const;

	string& GetDong() const;
	string& GetRi() const;
	string& GetBldg() const;

	string& GetStBunji() const;
	string& GetEdBunji() const;
	string& GetSeq() const;

	string& GetDetail() const;


public: //temp
	// temp for test
	Address(
		string siDo,
		string guGun,
		string dong,
		string bldg);


private:
	string zipCode;
	string siDo;
	string guGun;

	string dong;
	string ri;
	string bldg;

	string st_bunji;
	string ed_bunji;
	string seq;

	string detail;
};

inline string& Address::GetZipCode() const {
	return const_cast<string&>(this->zipCode);
}

inline string& Address::GetSiDo() const {
	return const_cast<string&>(this->siDo);
}

inline string& Address::GetGuGun() const {
	return const_cast<string&>(this->guGun);
}



inline string& Address::GetDong() const {
	return const_cast<string&>(this->dong);
}

inline string& Address::GetRi() const {
	return const_cast<string&>(this->ri);
}

inline string& Address::GetBldg() const {
	return const_cast<string&>(this->bldg);
}



inline string& Address::GetStBunji() const {
	return const_cast<string&>(this->st_bunji);
}

inline string& Address::GetEdBunji() const {
	return const_cast<string&>(this->ed_bunji);
}

inline string& Address::GetSeq() const {
	return const_cast<string&>(this->seq);
}



inline string& Address::GetDetail() const {
	return const_cast<string&>(this->detail);
}

#endif // _LIBADDRESS_H