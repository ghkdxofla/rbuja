#include "RBuJaApp.h"
#include "FormLogin.h"

#define _WIN32_WINNT		0x0502

RBuJaApp rBuJaApp;
BOOL RBuJaApp::InitInstance( ){
	FormLogin formLogin;
	this->m_pMainWnd = &formLogin;
	formLogin.DoModal();
	/*
	// HWND hw = FindWindow("Main HighGUI class", "example1");
	LONG nNewStyle = GetWindowLong(formLogin, GWL_STYLE) & ~WS_SYSMENU;
	SetWindowLong(formLogin, GWL_STYLE, nNewStyle);
	SetWindowPos(formLogin, 0, 0, 0, 0, 0, SWP_NOZORDER | SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_DRAWFRAME);
	formLogin.Create(formLogin.IDD);
	formLogin.ShowWindow(SW_SHOW);
	*/
	return TRUE;
}