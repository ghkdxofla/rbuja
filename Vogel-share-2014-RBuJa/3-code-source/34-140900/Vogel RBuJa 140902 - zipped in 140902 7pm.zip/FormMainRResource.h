//FormMainRResource.h

#ifndef _FORMMAINRRESOURCE_H
#define _FORMMAINRRESOURCE_H

#include "resource.h"
#include <afxwin.h>

class FormMainRResource : public CDialog
{
public:
	enum { IDD = IDD_M2_RRESOURCE };
public:
	FormMainRResource(CWnd *parent = NULL);
	virtual BOOL OnInitDialog();

public: // ����� �������̵�
	virtual void OnOK(); // EnterŰ â �ڵ����� ����
	virtual void OnCancel(); // ESCŰ â �ڵ����� ����

public: // Display
	void DisplayRResourceList();

public:
	CWnd* rResourceList;

protected:

	// SideMenuButtons
	afx_msg void OnMainSAreaButtonClicked();
	afx_msg void OnMainRResourceButtonClicked();
	afx_msg void OnMainRValueButtonClicked();
	afx_msg void OnMainRerButtonClicked();
	afx_msg void OnMainPickerButtonClicked();
	afx_msg void OnRefreshButtonClicked();
	afx_msg void OnSettingButtonClicked();


	afx_msg void OnMakeRResourceButtonClicked();


	afx_msg void OnClose();

	DECLARE_MESSAGE_MAP()
};


#endif