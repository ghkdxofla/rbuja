#include "LibDate.h"
#include <iostream>
#include <ctime>

Date::Date() {
	this->year = 1900;
	this->month = 1;
	this->day = 1;
	this->weekDay = 1;
	this->hour = 0;
	this->min = 0;
	this->sec = 0;
}

Date::Date(int year,
	int month,
	int day,
	int weekDay,
	int hour,
	int min,
	int sec)
{
	this->year = year;
	this->month = month;
	this->day = day;
	this->weekDay = weekDay;
	this->hour = hour;
	this->min = min;
	this->sec = sec;
}

Date::~Date() {}

Date& Date::operator=(const Date& source)
{
	this->year = source.year;
	this->month = source.month;
	this->day = source.day;
	this->weekDay = source.weekDay;
	this->hour = source.hour;
	this->min = source.min;
	this->sec = source.sec;

	return *this;
}

Date Date::Today() {
	time_t timer;
	struct tm today = { 0, };
	Date today_;

	time(&timer);
	localtime_s(&today, &timer);

	today_.year = today.tm_year + 1900;
	today_.month = today.tm_mon + 1;
	today_.day = today.tm_mday;
	today_.weekDay = today.tm_wday;
	today_.hour = today.tm_hour;
	today_.min = today.tm_min;
	today_.sec = today.tm_sec;
	return today_;
}

Date Date::YesterDay() {
	struct tm yesterday = { 0, };
	Date day;
	yesterday.tm_year = this->year - 1900;
	yesterday.tm_mon = this->month - 1;
	yesterday.tm_mday = this->day - 1;

	mktime(&yesterday);
	day.year = yesterday.tm_year + 1900;
	day.month = yesterday.tm_mon + 1;
	day.day = yesterday.tm_mday;
	day.weekDay = yesterday.tm_wday;
	day.hour = yesterday.tm_hour;
	day.min = yesterday.tm_min;
	day.sec = yesterday.tm_sec;

	return day;
}

Date Date::Tomorrow() {
	struct tm tomorrow = { 0, };
	Date day;
	tomorrow.tm_year = this->year - 1900;
	tomorrow.tm_mon = this->month - 1;
	tomorrow.tm_mday = this->day + 1;

	mktime(&tomorrow);
	day.year = tomorrow.tm_year + 1900;
	day.month = tomorrow.tm_mon + 1;
	day.day = tomorrow.tm_mday;
	day.weekDay = tomorrow.tm_wday;
	day.hour = tomorrow.tm_hour;
	day.min = tomorrow.tm_min;
	day.sec = tomorrow.tm_sec;

	return day;
}

Date Date::PreviousDate(int days) {
	struct tm previousDate = { 0, };
	Date day;
	previousDate.tm_year = this->year - 1900;
	previousDate.tm_mon = this->month - 1;
	previousDate.tm_mday = this->day - days;

	mktime(&previousDate);
	day.year = previousDate.tm_year + 1900;
	day.month = previousDate.tm_mon + 1;
	day.day = previousDate.tm_mday;
	day.weekDay = previousDate.tm_wday;
	day.hour = previousDate.tm_hour;
	day.min = previousDate.tm_min;
	day.sec = previousDate.tm_sec;

	return day;
}

Date Date::NextDate(int days) {
	struct tm nextDate = { 0, };
	Date day;
	nextDate.tm_year = this->year - 1900;
	nextDate.tm_mon = this->month - 1;
	nextDate.tm_mday = this->day + days;

	mktime(&nextDate);
	day.year = nextDate.tm_year + 1900;
	day.month = nextDate.tm_mon + 1;
	day.day = nextDate.tm_mday;
	day.weekDay = nextDate.tm_wday;
	day.hour = nextDate.tm_hour;
	day.min = nextDate.tm_min;
	day.sec = nextDate.tm_sec;

	return day;
}

bool Date::IsEqual(Date other) {
	bool check = false;
	if (this->year == other.year && this->month == other.month && this->day == other.day ){
		check = true;
	}
	return check;
}

bool Date::IsNotEqual(Date other) {
	bool check = false;
	if (this->year != other.year || this->month != other.month || this->day != other.day ){
		check = true;
	}
	return check;
}

bool Date::IsLesserThan(Date other) {
	bool check = false;
	int one_;
	int other_;
	one_ = this->year * 10000 + this->month * 100 + this->day;
	other_ = other.year * 10000 + other.month * 100 + other.day;
	if (one_ < other_) {
		check = true;
	}
	return check;
}

bool Date::IsGreaterThan(Date other) {
	bool check = false;
	int one_;
	int other_;
	one_ = this->year * 10000 + this->month * 100 + this->day;
	other_ = other.year * 10000 + other.month * 100 + other.day;
	if (one_ > other_) {
		check = true;
	}
	return check;
}

string Date::ConvertToString()
{
	string year = to_string(this->year);
	string month = to_string(this->month);
	string day = to_string(this->day);
	string hour = to_string(this->hour);
	string min = to_string(this->min);
	string sec = to_string(this->sec);

	string date = year + "-" + month + "-" + day + "-" + hour + "-" + min + "-" + sec;

	return date;
}
