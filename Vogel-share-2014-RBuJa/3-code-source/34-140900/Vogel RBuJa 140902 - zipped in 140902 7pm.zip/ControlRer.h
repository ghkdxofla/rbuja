// ControlRer.h
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		ControlRer.h
��������:		140712
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#ifndef _CONTROLRER_H
#define _CONTROLRER_H

#include "LibBinaryTree - added in 140725.h"
#include "Rer.h"

typedef signed long int Long;

class Area;

class ControlRer {

public:
	ControlRer();
	ControlRer(const ControlRer& source);
	~ControlRer();

	ControlRer& operator=(const ControlRer& source);

public:
	
	Rer* RecordRer(
		string id,
		string pw,
		string name,
		string phone,
		string addressTotal,
		string addressId,
		Area* areaLink);
		
	Rer* RecordRer(
		string id,
		string pw,
		string name,
		string phone,

		string addressTotal,
		string addressId,

		Long year,
		Long month,
		Long day,
		Long weekDay,
		Long hour,
		Long min,
		Long sec,

		Area* areaLink);
	
	Rer* FindRer(string id);
	BinaryTree<Rer>::Node* FindRerNode(string id);
	/*
	Rer* ModifyRer(
		Rer* oldRerLink,
		string newPw,
		string phone,
		Address addressTotal,
		string addressId,
		Zone* zoneLink = 0);

	Rer* EraseRer(Rer* rerLink);
	//*/

public:
	void GetCopiedRerBuffer(Rer* *(rerLinks), Long *count);
	BinaryTree<Rer>::Node* GetRootNode();

	BinaryTree<Rer>::Node* GetRoot() const;






public:
	Long GetLength() const;

private:
	BinaryTree<Rer> rers;
	Long length;

};
Long CompareRerIds(void* one, void* other);

inline Long ControlRer::GetLength() const
{
	return this->length;
}

inline void ControlRer::GetCopiedRerBuffer(Rer* *(rerLinks), Long *count)
{
	this->rers.CopyToBuffer(rerLinks, count);
}

inline BinaryTree<Rer>::Node* ControlRer::GetRootNode()
{
	return this->rers.GetRoot();
}


inline BinaryTree<Rer>::Node* ControlRer::GetRoot() const
{
	return const_cast<BinaryTree<Rer>::Node*>(this->rers.GetRoot());
}







#endif //_CONTROLRER_H