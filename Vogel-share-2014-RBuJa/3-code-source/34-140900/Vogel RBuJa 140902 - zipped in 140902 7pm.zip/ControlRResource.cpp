// ControlRResource.cpp
/*
������Ʈ��:		�˺��� ( RBuJa )
�����̸�:		ControlRResource.cpp
��������:		140805
�ۼ���:			����ȣ, �����
Copyright (c) 2014�� ����ȣ, �����. All rights reserved.
*/

#include "ControlRResource.h"

ControlRResource::ControlRResource()
{
	this->length = 0;
	this->current = 0;
}

ControlRResource::ControlRResource(const ControlRResource& source)
{
	this->rResources = source.rResources;
	this->length = source.length;
	this->current = source.current;
}

ControlRResource::~ControlRResource(){}

ControlRResource& ControlRResource::operator=(const ControlRResource& source)
{
	this->rResources = source.rResources;
	this->length = source.length;
	this->current = source.current;
	
	return *this;
}


RResource* ControlRResource::RecordRResource(string id, string pw, string companyName, string companyTelephone, string CEOName, string CEOPhone, string addressTotal, string addressId)
{
	RResource newRResource(id, pw, companyName, companyTelephone, CEOName, CEOPhone, addressTotal, addressId);
	LinkedList<RResource>::Node* nodeLink =  this->rResources.AppendFromTail(newRResource);
	RResource* rResourceLink  = &(nodeLink->GetObject());
	
	this->length = this->rResources.GetLength();
	this->current = &(this->rResources.GetCurrent()->GetObject());

	return rResourceLink;
}



RResource* ControlRResource::RecordRResource(
	string id,
	string pw,
	string companyName,
	string companyTelephone,
	string CEOName,
	string CEOPhone,
	string addressTotal,
	string addressId,

	Long year,
	Long month,
	Long day,
	Long weekDay,
	Long hour,
	Long min,
	Long sec,

	Long paperValueForRer,
	Long plasticValueForRer,
	Long glassBottleValueForRer,
	Long customGroupValueForRer,

	Long clothesValueForRer,
	Long steelValueForRer,
	Long wireValueForRer,

	Long stainlessValueForRer,
	Long copperValueForRer,


	Long paperValueForPicker,
	Long plasticValueForPicker,
	Long glassBottleValueForPicker,
	Long customGroupValueForPicker,

	Long clothesValueForPicker,
	Long steelValueForPicker,
	Long wireValueForPicker,

	Long stainlessValueForPicker,
	Long copperValueForPicker

	)
{
	RResource newRResource(
		id,
		pw,
		companyName,
		companyTelephone,
		CEOName,
		CEOPhone,
		addressTotal,
		addressId,

		year,
		month,
		day,
		weekDay,
		hour,
		min,
		sec,

		paperValueForRer,
		plasticValueForRer,
		glassBottleValueForRer,
		customGroupValueForRer,

		clothesValueForRer,
		steelValueForRer,
		wireValueForRer,

		stainlessValueForRer,
		copperValueForRer,


		paperValueForPicker,
		plasticValueForPicker,
		glassBottleValueForPicker,
		customGroupValueForPicker,

		clothesValueForPicker,
		steelValueForPicker,
		wireValueForPicker,

		stainlessValueForPicker,
		copperValueForPicker
		);
	LinkedList<RResource>::Node* nodeLink = this->rResources.AppendFromTail(newRResource);
	RResource* rResourceLink = &(nodeLink->GetObject());

	this->length = this->rResources.GetLength();
	this->current = &(this->rResources.GetCurrent()->GetObject());

	return rResourceLink;
}





RResource* ControlRResource::FindRResource(string rResourceId)
{
	RResource *rResourceLink = 0;

	LinkedList<RResource>::Node* node = this->rResources.LinearSearchUnique( &rResourceId, CompareRResourceIds );
	
	if( node != 0 )
	{
		rResourceLink = &(node->GetObject());
	}

	return rResourceLink;
}


RResource* ControlRResource::First()
{
	RResource* rResourceLink = &(this->rResources.First()->GetObject());
	return rResourceLink;
	
}
RResource* ControlRResource::Previous()
{
	RResource* rResourceLink = &(this->rResources.Previous()->GetObject());
	return rResourceLink;

}
RResource* ControlRResource::Next()
{
	RResource* rResourceLink = &(this->rResources.Next()->GetObject());
	return rResourceLink;

}
RResource* ControlRResource::Last()
{
	RResource* rResourceLink = &(this->rResources.Last()->GetObject());
	return rResourceLink;

}




Long CompareRResourceIds( void* one, void* other ) 
{
	Long ret;
	ret = static_cast<RResource*>(one)->GetId().compare(*(static_cast<string*>(other)));
	return ret;
}//*/



