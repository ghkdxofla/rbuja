

//recycle clicked
function changeColor_Recycle() {
        
    document.getElementById("recycle-title").style.backgroundColor = '#4DC03D';
    document.getElementById("recycle-title").style.color = 'white';
    document.getElementById("electric-title").style.backgroundColor = '#90EE90';
    document.getElementById("electric-title").style.color = 'white';

}

//electric clicked
function changeColor_Electric() {
    
    document.getElementById("electric-title").style.backgroundColor = '#4DC03D';
    document.getElementById("electric-title").style.color = 'white';
    document.getElementById("recycle-title").style.backgroundColor = '#90EE90';
    document.getElementById("recycle-title").style.color = 'white';
    
}

//Certify frame
function changeURL_Certify() {
    document.getElementById("URLhere").src = "certify.html";
}
//Customer frame
function changeURL_Customer() {
    document.getElementById("URLhere").src = "customer.html";
}
//Mpas frame
function changeURL_Maps() {
    document.getElementById("URLhere").src = "maps.html";
}
//Calculates frame
function changeURL_Calculates() {
    document.getElementById("URLhere").src = "calculates.html";
}
//More frame
function changeURL_More() {
    document.getElementById("URLhere").src = "more.html";
}