
"use strict";

//recycle clicked
function changeColor_Recycle() {
        
    document.getElementById('recycle-title').style.backgroundColor = '#4DC03D';
    document.getElementById('recycle-title').style.color = 'white';
    document.getElementById('electric-title').style.backgroundColor = '#90EE90';
    document.getElementById('electric-title').style.color = 'black';

}

//electric clicked
function changeColor_Electric() {
    
    document.getElementById("electric-title").style.backgroundColor = '#4DC03D';
    document.getElementById("electric-title").style.color = 'white';
    document.getElementById("recycle-title").style.backgroundColor = '#90EE90';
    document.getElementById("recycle-title").style.color = 'black';
    
}

//recycle clicked in calculates
function changeColor_Recycle_Calculates() {
        
    document.getElementById("calculates-recycle-button").style.backgroundColor = '#4DC03D';
    document.getElementById("calculates-recycle-button").style.color = 'white';
    document.getElementById("calculates-electric-button").style.backgroundColor = '#90EE90';
    document.getElementById("calculates-electric-button").style.color = 'black';

}

//electric clicked in calculates
function changeColor_Electric_Calculates() {
        
    document.getElementById("calculates-electric-button").style.backgroundColor = '#4DC03D';
    document.getElementById("calculates-electric-button").style.color = 'white';
    document.getElementById("calculates-recycle-button").style.backgroundColor = '#90EE90';
    document.getElementById("calculates-recycle-button").style.color = 'black';

}


//Certify frame














function CheckHomeIs() {
    var checkHome = localStorage.getItem("cit");
    var checkButton = localStorage.getItem("whichBtn");
    localStorage.setItem("frame", "inner");

    if (checkHome !== "home"){
        if(checkButton == 1){
            changeURL_Calculates();

        }
        else if(checkButton == 2){
            changeURL_Customer();
            /*
            $("#menuIcon-Certify").removeClass("change-button-color");
            $("#menuIcon-Certify-icon").removeClass("change-button-color");
            $("#menuIcon-Customer").addClass("change-button-color");
            $("#menuIcon-Customer-icon").addClass("change-button-color");
            $("#menuIcon-Maps").removeClass("change-button-color");
            $("#menuIcon-Maps-icon").removeClass("change-button-color");
            $("#menuIcon-Calculates").removeClass("change-button-color");
            $("#menuIcon-Calculates-icon").removeClass("change-button-color");
            $("#menuIcon-Point").removeClass("change-button-color");
            $("#menuIcon-Point-icon").removeClass("change-button-color");
            $("#menuIcon-Manual").removeClass("change-button-color");
            $("#menuIcon-Manual-icon").removeClass("change-button-color");
            $("#menuIcon-Setting").removeClass("change-button-color");
            $("#menuIcon-Setting-icon").removeClass("change-button-color");
            */
        }
        else if(checkButton == 3){
            changeURL_Maps();
            /*
            $("#menuIcon-Certify").removeClass("change-button-color");
            $("#menuIcon-Certify-icon").removeClass("change-button-color");
            $("#menuIcon-Customer").removeClass("change-button-color");
            $("#menuIcon-Customer-icon").removeClass("change-button-color");
            $("#menuIcon-Maps").addClass("change-button-color");
            $("#menuIcon-Maps-icon").addClass("change-button-color");
            $("#menuIcon-Calculates").removeClass("change-button-color");
            $("#menuIcon-Calculates-icon").removeClass("change-button-color");
            $("#menuIcon-Point").removeClass("change-button-color");
            $("#menuIcon-Point-icon").removeClass("change-button-color");
            $("#menuIcon-Manual").removeClass("change-button-color");
            $("#menuIcon-Manual-icon").removeClass("change-button-color");
            $("#menuIcon-Setting").removeClass("change-button-color");
            $("#menuIcon-Setting-icon").removeClass("change-button-color");  
            */
        }
        else if(checkButton == 4){
            changeURL_Collects();
        }



    }
    localStorage.setItem("whichBtn", 0);

}

function checkFrameIs(){
     var checkFrame = localStorage.getItem("frame");
    var frameOrigin;
    if(checkFrame == "main"){
        frameOrigin = document;
    }
    else if (checkFrame == "inner"){
        frameOrigin = parent.document;
    }
    return frameOrigin;
}
















function changeURL_Certify() {
    var frameOrigin = checkFrameIs();

    if(frameOrigin.getElementById("URLhere1").style.display == 'block'){
        frameOrigin.getElementById("URLhere1").contentWindow.location.reload();

    }
    else {

        frameOrigin.getElementById("URLhere1").style.display = 'block';
        frameOrigin.getElementById("URLhere2").style.display = 'none';
        frameOrigin.getElementById("URLhere3").style.display = 'none';
        frameOrigin.getElementById("URLhere4").style.display = 'none';
        frameOrigin.getElementById("URLhere5").style.display = 'none';
        frameOrigin.getElementById("URLhere6").style.display = 'none';
        frameOrigin.getElementById("URLhere7").style.display = 'none';
        frameOrigin.getElementById("URLhere8").style.display = 'none';
        frameOrigin.getElementById("customerID").style.display = 'none';
    }
    localStorage.setItem("cit", "home");
    localStorage.setItem("frame", "main");


    


}
//Customer frame
function changeURL_Customer() {
    var frameOrigin = checkFrameIs();
    
    
    
    if(frameOrigin.getElementById("URLhere2").style.display == 'block'){
        frameOrigin.getElementById("URLhere2").contentWindow.location.reload();
        //location.reload();
    }
    else{
        frameOrigin.getElementById("URLhere1").style.display = 'none';
        frameOrigin.getElementById("URLhere2").style.display = 'block';
        frameOrigin.getElementById("URLhere3").style.display = 'none';
        frameOrigin.getElementById("URLhere4").style.display = 'none';
        frameOrigin.getElementById("URLhere5").style.display = 'none';
        frameOrigin.getElementById("URLhere6").style.display = 'none';
        frameOrigin.getElementById("URLhere7").style.display = 'none';
        frameOrigin.getElementById("URLhere8").style.display = 'none';
        frameOrigin.getElementById("customerID").style.display = 'block';

        $.ajax({
            type: "GET",
            url: "client.txt",
            dataType: "json",
            success: function(data){
               var myArray = data;
               certifyClientCustomer(myArray);
            }
        });
        localStorage.setItem("frame", "main");

                                      
    }

}
//Maps frame
function changeURL_Maps() {
    var frameOrigin = checkFrameIs();

    if(frameOrigin.getElementById("URLhere3").style.display == 'block'){
       frameOrigin.getElementById("URLhere3").contentWindow.location.reload();
        //location.reload();
    }
    else{     
        frameOrigin.getElementById("URLhere1").style.display = 'none';
        frameOrigin.getElementById("URLhere2").style.display = 'none';
        frameOrigin.getElementById("URLhere3").style.display = 'block';
        frameOrigin.getElementById("URLhere4").style.display = 'none';
        frameOrigin.getElementById("URLhere5").style.display = 'none';
        frameOrigin.getElementById("URLhere6").style.display = 'none';
        frameOrigin.getElementById("URLhere7").style.display = 'none';
        frameOrigin.getElementById("URLhere8").style.display = 'none';
        frameOrigin.getElementById("customerID").style.display = 'none';
    }
    localStorage.setItem("frame", "main");

        
}
//----------------------------popup!!!---------------------------------
//Calculates frame
function changeURL_Calculates() {
    var frameOrigin = checkFrameIs();
        
    
    frameOrigin.getElementById("URLhere1").style.display = 'block';
    frameOrigin.getElementById("URLhere2").style.display = 'none';
    frameOrigin.getElementById("URLhere3").style.display = 'none';
    frameOrigin.getElementById("popupCalculates").style.display = 'block';
    frameOrigin.getElementById("URLhere4").style.display = 'block';
    frameOrigin.getElementById("URLhere5").style.display = 'none';
    frameOrigin.getElementById("URLhere6").style.display = 'none';
    frameOrigin.getElementById("URLhere7").style.display = 'none';
    frameOrigin.getElementById("URLhere8").style.display = 'none';
    frameOrigin.getElementById("customerID").style.display = 'none';



    $.ajax({
        type: "GET",
        url: "productlist.txt",
        dataType: "json",
        success: function(data){
           var myArray = data;
           certifyProductCalculates(myArray);
        },
        complete: function(){
            $.ajax({
                type: "GET",
                url: "client.txt",
                dataType: "json",
                success: function(data){
                   var myArray = data;
                   certifyClient(myArray);
                }
           });
        }
    });
    localStorage.setItem("frame", "main");


}


function closePopupCalculates() {
    document.getElementById("popupCalculates").style.display = 'none';
    document.getElementById("URLhere4").style.display = 'none';

}

//collects frame
function changeURL_Collects() {
    var frameOrigin = checkFrameIs();

    
    frameOrigin.getElementById("URLhere1").style.display = 'block';
    frameOrigin.getElementById("URLhere2").style.display = 'none';
    frameOrigin.getElementById("URLhere3").style.display = 'none';
    frameOrigin.getElementById("popupCollects").style.display = 'block';
    frameOrigin.getElementById("URLhere4").style.display = 'none';
    frameOrigin.getElementById("URLhere5").style.display = 'none';
    frameOrigin.getElementById("URLhere6").style.display = 'none';
    frameOrigin.getElementById("URLhere7").style.display = 'none';
    frameOrigin.getElementById("URLhere8").style.display = 'block';
    frameOrigin.getElementById("customerID").style.display = 'none';
    localStorage.setItem("frame", "main");

    
}


function closePopupCollects() {
    document.getElementById("popupCollects").style.display = 'none';
    document.getElementById("URLhere8").style.display = 'none';

}

//----------------------------popup!!!---------------------------------
/*test
//More frame
function changeURL_More() {
    document.getElementById("URLhere").src = "more.html";
}
*/

//Point frame
function changeURL_Point() {
    var frameOrigin = checkFrameIs();
    if(frameOrigin.getElementById("URLhere5").style.display == 'block'){
        frameOrigin.getElementById("URLhere5").contentWindow.location.reload();
        //location.reload();
    }
    else{    
        frameOrigin.getElementById("URLhere1").style.display = 'none';
        frameOrigin.getElementById("URLhere2").style.display = 'none';
        frameOrigin.getElementById("URLhere3").style.display = 'none';
        frameOrigin.getElementById("URLhere4").style.display = 'none';
        frameOrigin.getElementById("URLhere5").style.display = 'block';
        frameOrigin.getElementById("URLhere6").style.display = 'none';
        frameOrigin.getElementById("URLhere7").style.display = 'none';
        frameOrigin.getElementById("URLhere8").style.display = 'none';
        frameOrigin.getElementById("customerID").style.display = 'none';
        localStorage.setItem("frame", "main");

    }
        
}

//Manual frame
function changeURL_Manual() {
    var frameOrigin = checkFrameIs();

    if(frameOrigin.getElementById("URLhere6").style.display == 'block'){
        frameOrigin.getElementById("URLhere6").contentWindow.location.reload();
        //location.reload();
    }
    else{    
        frameOrigin.getElementById("URLhere1").style.display = 'none';
        frameOrigin.getElementById("URLhere2").style.display = 'none';
        frameOrigin.getElementById("URLhere3").style.display = 'none';
        frameOrigin.getElementById("URLhere4").style.display = 'none';
        frameOrigin.getElementById("URLhere5").style.display = 'none';
        frameOrigin.getElementById("URLhere6").style.display = 'block';
        frameOrigin.getElementById("URLhere7").style.display = 'none';
        frameOrigin.getElementById("URLhere8").style.display = 'none';
        frameOrigin.getElementById("customerID").style.display = 'none';
        localStorage.setItem("frame", "main");

    }
        
}

//Setting frame
function changeURL_Setting() {
        var frameOrigin = checkFrameIs();

    if(frameOrigin.getElementById("URLhere7").style.display == 'block'){
        frameOrigin.getElementById("URLhere7").contentWindow.location.reload();
        //location.reload();
    }
    else{    
        frameOrigin.getElementById("URLhere1").style.display = 'none';
        frameOrigin.getElementById("URLhere2").style.display = 'none';
        frameOrigin.getElementById("URLhere3").style.display = 'none';
        frameOrigin.getElementById("URLhere4").style.display = 'none';
        frameOrigin.getElementById("URLhere5").style.display = 'none';
        frameOrigin.getElementById("URLhere6").style.display = 'none';
        frameOrigin.getElementById("URLhere7").style.display = 'block';
        frameOrigin.getElementById("URLhere8").style.display = 'none';
        frameOrigin.getElementById("customerID").style.display = 'none';
        localStorage.setItem("frame", "main");

    }
        
}

//complete clicked
function completeClicked() {
    alert("방문완료 되었습니다!");
}

//complete clicked
function outClicked() {
    alert("부재중 처리되었습니다.");
}

//
   
//function asdasfasdsadas() {
//    var i = document.getElementById("URLhere1").innerHTML;
//    return i;
//}



    