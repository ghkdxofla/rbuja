





         
        
        
        
//certify-client-list
/*
var certifyClient = new XMLHttpRequest();

var clientFile = "client.txt";


certifyClient.onreadystatechange = function () {
    if (certifyClient.readyState == 4 && certifyClient.status == 200) {
        var myArray = JSON.parse(certifyClient.responseText);
        ClientList(myArray);
        
    }
}
certifyClient.open("GET", clientFile, true);
certifyClient.send();
*/





//certify-client-function
function ClientList(arr) {
    var outRe ="";
    var outEl ="";
    var i;
    for(i = 0; i < arr.reClient.length; i++) {
        var indexStringRe = arr.reClient.indexOf(arr.reClient[i]);
        var indexNumberRe = 1 + indexStringRe;

        outRe += '<li class="all-client" id="re-client-' + 
            arr.reClient.indexOf(arr.reClient[i]) + 
            '"><div onclick="ClientInfoTransfer(this)" tabindex="-1" class="re-client-info">' +
            arr.reClient[i].name + '<br>' + 
            arr.reClient[i].cellular + '</div><div onmousedown="buttonForClosing()" class="re-client-number">' + 
            indexNumberRe + '</div><div class="all-client-button"><div class="button-background"><br></div><div onmousedown="buttonOverRe(this)" onmouseup="buttonOutRe(this)" onscroll="buttonOutRe(this)" onmouseout="buttonOutRe(this)" class="button-style-re client-calculates">계산하기</div><div onmousedown="buttonOverRe(this)" onmouseup="buttonOutRe(this)" onscroll="buttonOutRe(this)" onmouseout="buttonOutRe(this)" class="button-style-re client-customer">고객정보</div><div onmousedown="buttonOverRe(this)" onmouseup="buttonOutRe(this)" onscroll="buttonOutRe(this)" onmouseout="buttonOutRe(this)" class="button-style-re client-map">지도보기</div></div></li>';
    }
    for(i = 0; i < arr.elClient.length; i++) {
        var indexStringEl = arr.elClient.indexOf(arr.elClient[i]);
        var indexNumberEl = 1 + indexStringEl;

        outEl += '<li class="all-client" id="el-client-' + 
            arr.elClient.indexOf(arr.elClient[i]) + 
            '"><div onclick="ClientInfoTransfer(this)" tabindex="-1" class="el-client-info">' +
            arr.elClient[i].name + '<br>' + 
            arr.elClient[i].cellular + '</div><div onmousedown="buttonForClosing()" class="el-client-number">' + 
            indexNumberEl + '</div><div class="all-client-button"><div class="button-background"><br></div><div onmousedown="buttonOverEl(this)" onmouseup="buttonOutEl(this)" onscroll="buttonOutEl(this)" onmouseout="buttonOutEl(this)" class="button-style-el client-collects">수거하기</div><div onmousedown="buttonOverEl(this)" onmouseup="buttonOutEl(this)" onscroll="buttonOutEl(this)" onmouseout="buttonOutEl(this)" class="button-style-el client-customer">고객정보</div><div onmousedown="buttonOverEl(this)" onmouseup="buttonOutEl(this)" onscroll="buttonOutEl(this)" onmouseout="buttonOutEl(this)" class="button-style-el client-map">지도보기</div></div></li>';
    }
    document.getElementById('JSON-reIndicator').innerHTML = outRe;
    document.getElementById('JSON-elIndicator').innerHTML = outEl;
}


//customer-client-function
var buttonPosition;

//when certify list click, button menu will pop-up!!!!!!!!!!!!!!!
function ClientInfoTransfer(CIT) {
    var indexPosition = CIT.parentNode.getElementsByTagName("div");
    var i = indexPosition[1].innerHTML - 1;
    localStorage.setItem("cit", i);

    indexPosition[2].style.display='block';
    
    

    $(indexPosition[0]).focus();

    if(localStorage.getItem("whichBtn") == null){
        localStorage.setItem("whichBtn", 0);
    }
    

    
    indexPosition[0].addEventListener("blur", function(){
        indexPosition[2].style.display='none';
        
    
        
    });
    buttonPosition = indexPosition[2];
    return buttonPosition;
    
}

function buttonForClosing(){
        buttonPosition.style.display='none';
}
    







/*

function ClientInfoIdentifier(arr){    
    var out = "";
    var i = "";
    var indexCustomer = localStorage.getItem("cit");
    //alert(localStorage.getItem("cit"));
    i += indexCustomer;
    i *= 1;
    var checkPicker = localStorage.getItem("picker");
    if(checkPicker == null){
        checkPicker = localStorage.setItem("picker", "rePicker");
    }

    if(checkPicker == "rePicker"){
        out += '<li><span class="list-style-bold">이름: </span>' + arr.reClient[i].name + 
            '</li><li><span class="list-style-bold">번호: </span>' + arr.reClient[i].cellular
            + '</li><li><span class="list-style-bold">이메일: </span>' + 
            arr.reClient[i].emailAddress + 
            '</li><li><span class="list-style-bold">주소: </span>' + 
            arr.reClient[i].address + '</li>';
        document.getElementById('JSON-clientIndicator').innerHTML = out;

    }
    else{

        out += '<li><span class="list-style-bold">이름: </span>' + arr.elClient[i].name + 
            '</li><li><span class="list-style-bold">번호: </span>' + arr.elClient[i].cellular
            + '</li><li><span class="list-style-bold">이메일: </span>' + 
            arr.elClient[i].emailAddress + 
            '</li><li><span class="list-style-bold">주소: </span>' + 
            arr.elClient[i].address + '</li>';
        document.getElementById('JSON-clientIndicator').innerHTML = out;
    }
    
}
*/


//------------------------------------------
//------------------------------------------






















                  
                        
                                
                        
                        
                        
                        
                        
                        
                           
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        