
"use strict";

//recycle clicked
function changeColor_Recycle() {
        
    document.getElementById('recycle-title').style.backgroundColor = '#4DC03D';
    document.getElementById('recycle-title').style.color = 'white';
    document.getElementById('electric-title').style.backgroundColor = '#90EE90';
    document.getElementById('electric-title').style.color = 'black';

}

//electric clicked
function changeColor_Electric() {
    
    document.getElementById("electric-title").style.backgroundColor = '#4DC03D';
    document.getElementById("electric-title").style.color = 'white';
    document.getElementById("recycle-title").style.backgroundColor = '#90EE90';
    document.getElementById("recycle-title").style.color = 'black';
    
}

//recycle clicked in calculates
function changeColor_Recycle_Calculates() {
        
    document.getElementById("calculates-recycle-button").style.backgroundColor = '#4DC03D';
    document.getElementById("calculates-recycle-button").style.color = 'white';
    document.getElementById("calculates-electric-button").style.backgroundColor = '#90EE90';
    document.getElementById("calculates-electric-button").style.color = 'black';

}

//electric clicked in calculates
function changeColor_Electric_Calculates() {
        
    document.getElementById("calculates-electric-button").style.backgroundColor = '#4DC03D';
    document.getElementById("calculates-electric-button").style.color = 'white';
    document.getElementById("calculates-recycle-button").style.backgroundColor = '#90EE90';
    document.getElementById("calculates-recycle-button").style.color = 'black';

}


//Certify frame


function CheckHomeIs() {
    var checkHome = localStorage.getItem("cit");
    var checkButton = localStorage.getItem("whichBtn");
    if (checkHome !== "home"){
        if(checkButton == 1){
            changeURL_Calculates();

        }
        else if(checkButton == 2){
            changeURL_Customer();
            $("#menuIcon-Certify").removeClass("change-button-color");
            $("#menuIcon-Certify-icon").removeClass("change-button-color");
            $("#menuIcon-Customer").addClass("change-button-color");
            $("#menuIcon-Customer-icon").addClass("change-button-color");
            $("#menuIcon-Maps").removeClass("change-button-color");
            $("#menuIcon-Maps-icon").removeClass("change-button-color");
            $("#menuIcon-Calculates").removeClass("change-button-color");
            $("#menuIcon-Calculates-icon").removeClass("change-button-color");
            $("#menuIcon-Point").removeClass("change-button-color");
            $("#menuIcon-Point-icon").removeClass("change-button-color");
            $("#menuIcon-Manual").removeClass("change-button-color");
            $("#menuIcon-Manual-icon").removeClass("change-button-color");
            $("#menuIcon-Setting").removeClass("change-button-color");
            $("#menuIcon-Setting-icon").removeClass("change-button-color");
        }
        else if(checkButton == 3){
            changeURL_Maps();
            $("#menuIcon-Certify").removeClass("change-button-color");
            $("#menuIcon-Certify-icon").removeClass("change-button-color");
            $("#menuIcon-Customer").removeClass("change-button-color");
            $("#menuIcon-Customer-icon").removeClass("change-button-color");
            $("#menuIcon-Maps").addClass("change-button-color");
            $("#menuIcon-Maps-icon").addClass("change-button-color");
            $("#menuIcon-Calculates").removeClass("change-button-color");
            $("#menuIcon-Calculates-icon").removeClass("change-button-color");
            $("#menuIcon-Point").removeClass("change-button-color");
            $("#menuIcon-Point-icon").removeClass("change-button-color");
            $("#menuIcon-Manual").removeClass("change-button-color");
            $("#menuIcon-Manual-icon").removeClass("change-button-color");
            $("#menuIcon-Setting").removeClass("change-button-color");
            $("#menuIcon-Setting-icon").removeClass("change-button-color");            
        }
        else if(checkButton == 4){
            changeURL_Collects();
        }


        
    }
    localStorage.setItem("whichBtn", 0);

}

function CheckReadyState(){
     document.getElementById("URLhere1").contentWindow.removeEventListener("click", CheckHomeIs);
     document.getElementById("URLhere1").contentWindow.addEventListener("click", CheckHomeIs);
}



function changeURL_Certify() {
    if(document.getElementById("URLhere1").style.display == 'block'){
        document.getElementById("URLhere1").contentWindow.location.reload();
        CheckReadyState();

    }
    else {

        document.getElementById("URLhere1").style.display = 'block';
        document.getElementById("URLhere2").style.display = 'none';
        document.getElementById("URLhere3").style.display = 'none';
        document.getElementById("URLhere4").style.display = 'none';
        document.getElementById("URLhere5").style.display = 'none';
        document.getElementById("URLhere6").style.display = 'none';
        document.getElementById("URLhere7").style.display = 'none';
        document.getElementById("URLhere8").style.display = 'none';
        document.getElementById("customerID").style.display = 'none';
    }
    checkHome = localStorage.setItem("cit", "home");

    


}
//Customer frame
function changeURL_Customer() {
    if(document.getElementById("URLhere2").style.display == 'block'){
        checkHome = localStorage.setItem("cit", "home");
        document.getElementById("URLhere2").contentWindow.location.reload();
        //location.reload();
    }
    else{
        document.getElementById("URLhere1").style.display = 'none';
        document.getElementById("URLhere2").style.display = 'block';
        document.getElementById("URLhere3").style.display = 'none';
        document.getElementById("URLhere4").style.display = 'none';
        document.getElementById("URLhere5").style.display = 'none';
        document.getElementById("URLhere6").style.display = 'none';
        document.getElementById("URLhere7").style.display = 'none';
        document.getElementById("URLhere8").style.display = 'none';
        document.getElementById("customerID").style.display = 'block';

                                                                         
         var checkPicker = localStorage.getItem("picker");
        if(checkPicker == null){
            checkPicker = localStorage.setItem("picker", "rePicker");
        }
        
        $.get("client.txt", function(data, status, certifyClientCustomer){
             var arr = JSON.parse(certifyClientCustomer.responseText);
             var out = "";
             var i = "";
             var indexCustomer = localStorage.getItem("cit");
             //alert(localStorage.getItem("cit"));
             i += indexCustomer;
             i *= 1;
            if(checkPicker == "rePicker"){

                     out += '<li><span class="list-style-bold">이름: </span>' + arr.reClient[i].name + 
                        '</li><li><span class="list-style-bold">번호: </span>' + arr.reClient[i].cellular
                        + '</li><li><span class="list-style-bold">이메일: </span>' + 
                        arr.reClient[i].emailAddress + 
                        '</li><li><span class="list-style-bold">주소: </span>' + 
                        arr.reClient[i].address + '</li>';
                    var docOrigin = document.getElementById("URLhere2").contentDocument;




                    docOrigin.getElementById('JSON-clientIndicator').innerHTML = out;


            }
            else{

                     out += '<li><span class="list-style-bold">이름: </span>' + arr.elClient[i].name + 
                        '</li><li><span class="list-style-bold">번호: </span>' + arr.elClient[i].cellular
                        + '</li><li><span class="list-style-bold">이메일: </span>' + 
                        arr.elClient[i].emailAddress + 
                        '</li><li><span class="list-style-bold">주소: </span>' + 
                        arr.elClient[i].address + '</li>';
                    var docOrigin = document.getElementById("URLhere2").contentDocument;




                    docOrigin.getElementById('JSON-clientIndicator').innerHTML = out;

            }
        });
                                                                         

                                                                         

                                                                 
    }

}
//Maps frame
function changeURL_Maps() {
    if(document.getElementById("URLhere3").style.display == 'block'){
       document.getElementById("URLhere3").contentWindow.location.reload();
        //location.reload();
    }
    else{     
        document.getElementById("URLhere1").style.display = 'none';
        document.getElementById("URLhere2").style.display = 'none';
        document.getElementById("URLhere3").style.display = 'block';
        document.getElementById("URLhere4").style.display = 'none';
        document.getElementById("URLhere5").style.display = 'none';
        document.getElementById("URLhere6").style.display = 'none';
        document.getElementById("URLhere7").style.display = 'none';
        document.getElementById("URLhere8").style.display = 'none';
        document.getElementById("customerID").style.display = 'none';
    }
        
}
//----------------------------popup!!!---------------------------------
//Calculates frame
function changeURL_Calculates() {
    
    document.getElementById("URLhere1").style.display = 'block';
    document.getElementById("URLhere2").style.display = 'none';
    document.getElementById("URLhere3").style.display = 'none';
    document.getElementById("popupCalculates").style.display = 'block';
    document.getElementById("URLhere4").style.display = 'block';
    document.getElementById("URLhere5").style.display = 'none';
    document.getElementById("URLhere6").style.display = 'none';
    document.getElementById("URLhere7").style.display = 'none';
    document.getElementById("URLhere8").style.display = 'none';
    document.getElementById("customerID").style.display = 'none';
    
    
    $.get("productlist.txt", function(data, status, certifyProductCalculates){
        var arr = JSON.parse(certifyProductCalculates.responseText);
        var outList = "";

        var i;
        for(i=0; i<arr.reProduct.length; i++){

            outList += '<div class="calculates-list-style"><div class="list-product">' + arr.reProduct[i].name + '[<span>' + arr.reProduct[i].point + 
                '</span>p]</div><form class="list-amount form-signin" role="form"><input type="text" class="form-control" placeholder="수량"></form><div class="list-point"></div></div>';
        }


        document.getElementById('JSON-productIndicator').innerHTML = outList;
        


    });



    $.get("client.txt", function(data, status, certifyClient){
        var arr = JSON.parse(certifyClient.responseText);
        var outName = "";
        var i = "";
        var indexCalculates = localStorage.getItem("cit");
        i += indexCalculates;
        i *= 1;
        outName += '<span id="calculates-customer-name">' + arr.reClient[i].name + '</span> 님';
        document.getElementById("calculates-client-section").innerHTML = outName;
        alert("done!");
    });
    
}


function closePopupCalculates() {
    document.getElementById("popupCalculates").style.display = 'none';
    document.getElementById("URLhere4").style.display = 'none';

}

//collects frame
function changeURL_Collects() {
    
    document.getElementById("URLhere1").style.display = 'block';
    document.getElementById("URLhere2").style.display = 'none';
    document.getElementById("URLhere3").style.display = 'none';
    document.getElementById("popupCollects").style.display = 'block';
    document.getElementById("URLhere4").style.display = 'none';
    document.getElementById("URLhere5").style.display = 'none';
    document.getElementById("URLhere6").style.display = 'none';
    document.getElementById("URLhere7").style.display = 'none';
    document.getElementById("URLhere8").style.display = 'block';
    document.getElementById("customerID").style.display = 'none';
    
}


function closePopupCollects() {
    document.getElementById("popupCollects").style.display = 'none';
    document.getElementById("URLhere8").style.display = 'none';

}

//----------------------------popup!!!---------------------------------
/*test
//More frame
function changeURL_More() {
    document.getElementById("URLhere").src = "more.html";
}
*/

//Point frame
function changeURL_Point() {
    if(document.getElementById("URLhere5").style.display == 'block'){
        document.getElementById("URLhere5").contentWindow.location.reload();
        //location.reload();
    }
    else{    
        document.getElementById("URLhere1").style.display = 'none';
        document.getElementById("URLhere2").style.display = 'none';
        document.getElementById("URLhere3").style.display = 'none';
        document.getElementById("URLhere4").style.display = 'none';
        document.getElementById("URLhere5").style.display = 'block';
        document.getElementById("URLhere6").style.display = 'none';
        document.getElementById("URLhere7").style.display = 'none';
        document.getElementById("URLhere8").style.display = 'none';
        document.getElementById("customerID").style.display = 'none';

    }
        
}

//Manual frame
function changeURL_Manual() {
    if(document.getElementById("URLhere6").style.display == 'block'){
        document.getElementById("URLhere6").contentWindow.location.reload();
        //location.reload();
    }
    else{    
        document.getElementById("URLhere1").style.display = 'none';
        document.getElementById("URLhere2").style.display = 'none';
        document.getElementById("URLhere3").style.display = 'none';
        document.getElementById("URLhere4").style.display = 'none';
        document.getElementById("URLhere5").style.display = 'none';
        document.getElementById("URLhere6").style.display = 'block';
        document.getElementById("URLhere7").style.display = 'none';
        document.getElementById("URLhere8").style.display = 'none';
        document.getElementById("customerID").style.display = 'none';

    }
        
}

//Setting frame
function changeURL_Setting() {
    if(document.getElementById("URLhere7").style.display == 'block'){
        document.getElementById("URLhere7").contentWindow.location.reload();
        //location.reload();
    }
    else{    
        document.getElementById("URLhere1").style.display = 'none';
        document.getElementById("URLhere2").style.display = 'none';
        document.getElementById("URLhere3").style.display = 'none';
        document.getElementById("URLhere4").style.display = 'none';
        document.getElementById("URLhere5").style.display = 'none';
        document.getElementById("URLhere6").style.display = 'none';
        document.getElementById("URLhere7").style.display = 'block';
        document.getElementById("URLhere8").style.display = 'none';
        document.getElementById("customerID").style.display = 'none';

    }
        
}

//complete clicked
function completeClicked() {
    alert("방문완료 되었습니다!");
}

//complete clicked
function outClicked() {
    alert("부재중 처리되었습니다.");
}

//
   
//function asdasfasdsadas() {
//    var i = document.getElementById("URLhere1").innerHTML;
//    return i;
//}



    